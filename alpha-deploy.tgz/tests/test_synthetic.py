"""Property tests for the synthetic market generator.

These assert *statistical* ground truth, not implementation details: if vol
targeting or a correlation estimate breaks, one of these should fail before an
equity curve does. No network, no disk, no global RNG state.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from alpha.data.store import KLINE_COLUMNS
from alpha.data.synthetic import (
    SyntheticConfig,
    generate_funding,
    generate_ohlcv,
    generate_panel,
)

BARS_PER_YEAR = 365 * 24  # one hourly bar per hour


def _log_returns(df: pd.DataFrame) -> np.ndarray:
    return np.log(df["close"].to_numpy(dtype=float))[1:] - np.log(
        df["close"].to_numpy(dtype=float)
    )[:-1]


def _avg_pairwise_corr(panel: dict[str, pd.DataFrame]) -> float:
    mat = np.vstack([_log_returns(df) for df in panel.values()])
    corr = np.corrcoef(mat)
    upper = np.triu_indices(len(panel), k=1)
    return float(corr[upper].mean())


# --------------------------------------------------------------------- determinism


def test_same_seed_is_identical() -> None:
    pd.testing.assert_frame_equal(
        generate_ohlcv(SyntheticConfig(bars=500)),
        generate_ohlcv(SyntheticConfig(bars=500)),
    )
    pd.testing.assert_frame_equal(
        generate_funding(SyntheticConfig(bars=500)),
        generate_funding(SyntheticConfig(bars=500)),
    )


def test_different_seed_changes_prices() -> None:
    a = generate_ohlcv(SyntheticConfig(bars=500, seed=1))
    b = generate_ohlcv(SyntheticConfig(bars=500, seed=2))
    assert not np.allclose(a["close"].to_numpy(), b["close"].to_numpy())


# ------------------------------------------------------------------------- schema


def test_schema_dtypes_and_clock() -> None:
    cfg = SyntheticConfig(bars=300)
    df = generate_ohlcv(cfg)

    assert list(df.columns) == KLINE_COLUMNS
    assert df["ts"].dtype == np.int64
    for col in KLINE_COLUMNS[1:]:
        assert df[col].dtype == np.float64

    ts = df["ts"].to_numpy()
    assert len(ts) == cfg.bars
    assert ts[0] == cfg.start_ts
    assert np.all(np.diff(ts) == cfg.interval_ms)


def test_bar_clock_respects_a_non_default_interval() -> None:
    cfg = SyntheticConfig(bars=100, interval_ms=900_000)
    ts = generate_ohlcv(cfg)["ts"].to_numpy()
    assert np.all(np.diff(ts) == 900_000)
    assert np.all(np.diff(ts) > 0)


# ----------------------------------------------------------------- price integrity


def test_price_integrity_under_every_stress_knob() -> None:
    cfg = SyntheticConfig(
        bars=3000,
        annual_drift=0.3,
        annual_vol=0.9,
        mean_reversion=2.0,
        jump_prob=0.02,
        jump_scale=0.05,
        vol_clustering=0.9,
    )
    df = generate_ohlcv(cfg)

    open_ = df["open"].to_numpy()
    high = df["high"].to_numpy()
    low = df["low"].to_numpy()
    close = df["close"].to_numpy()

    assert np.isfinite(df[KLINE_COLUMNS].to_numpy(dtype=float)).all()
    assert (open_ > 0).all() and (high > 0).all() and (low > 0).all() and (close > 0).all()
    assert (high >= np.maximum(open_, close)).all()
    assert (low <= np.minimum(open_, close)).all()
    assert (high >= low).all()
    assert (df["volume"] > 0).all()
    assert np.allclose(df["turnover"].to_numpy(), df["volume"].to_numpy() * close)


# -------------------------------------------------------------------- statistics


def test_realised_vol_matches_config_in_the_homoskedastic_case() -> None:
    cfg = SyntheticConfig(bars=BARS_PER_YEAR, annual_vol=0.5, vol_clustering=0.0)
    realised = float(_log_returns(generate_ohlcv(cfg)).std(ddof=1) * np.sqrt(BARS_PER_YEAR))
    assert 0.4 * cfg.annual_vol <= realised <= 2.5 * cfg.annual_vol


def test_realised_vol_tracks_the_configured_level() -> None:
    for annual_vol in (0.25, 0.8):
        cfg = SyntheticConfig(bars=BARS_PER_YEAR, annual_vol=annual_vol)
        realised = float(_log_returns(generate_ohlcv(cfg)).std(ddof=1) * np.sqrt(BARS_PER_YEAR))
        assert 0.5 * annual_vol <= realised <= 2.0 * annual_vol


def test_mean_reversion_shrinks_the_price_variance() -> None:
    rw = generate_ohlcv(SyntheticConfig(bars=BARS_PER_YEAR, mean_reversion=0.0))
    ou = generate_ohlcv(SyntheticConfig(bars=BARS_PER_YEAR, mean_reversion=5.0))
    var_rw = float(np.var(np.log(rw["close"].to_numpy())))
    var_ou = float(np.var(np.log(ou["close"].to_numpy())))
    assert var_ou < 0.7 * var_rw


def test_common_factor_controls_cross_sectional_correlation() -> None:
    symbols = ["AAAUSDT", "BBBUSDT", "CCCUSDT"]
    correlated, _ = generate_panel(symbols, common_factor=0.9, bars=3000)
    independent, _ = generate_panel(symbols, common_factor=0.0, bars=3000)
    assert _avg_pairwise_corr(correlated) > 0.4
    assert abs(_avg_pairwise_corr(independent)) < 0.25


def test_jumps_fatten_the_return_tails() -> None:
    calm = generate_ohlcv(SyntheticConfig(bars=6000, jump_prob=0.0))
    jumpy = generate_ohlcv(SyntheticConfig(bars=6000, jump_prob=0.02, jump_scale=0.05))
    kurt_calm = float(pd.Series(_log_returns(calm)).kurt())
    kurt_jumpy = float(pd.Series(_log_returns(jumpy)).kurt())
    assert kurt_jumpy > kurt_calm
    assert kurt_jumpy > 3.0


# ------------------------------------------------------------------------ funding


def test_funding_schema_boundaries_and_finiteness() -> None:
    cfg = SyntheticConfig(bars=8760)
    frame = generate_funding(cfg)

    assert list(frame.columns) == ["ts", "funding_rate"]
    assert frame["ts"].dtype == np.int64
    assert frame["funding_rate"].dtype == np.float64
    assert np.isfinite(frame["funding_rate"].to_numpy()).all()

    ts = frame["ts"].to_numpy()
    assert (ts % cfg.funding_interval_ms == 0).all()
    assert np.all(np.diff(ts) == cfg.funding_interval_ms)

    last = cfg.start_ts + (cfg.bars - 1) * cfg.interval_ms
    expected = np.arange(
        -(-cfg.start_ts // cfg.funding_interval_ms), last // cfg.funding_interval_ms + 1
    )
    assert len(frame) == expected.size
    assert len(frame) > 300  # a year of 8h settlements

    # Rates are noisy draws around the mean, not a constant.
    assert abs(float(frame["funding_rate"].mean()) - cfg.funding_mean) < 0.0002
    assert float(frame["funding_rate"].std()) > 0.0
    assert generate_funding(SyntheticConfig(bars=8760, seed=99))["funding_rate"].iloc[0] != (
        frame["funding_rate"].iloc[0]
    )


def test_funding_interval_field_is_respected() -> None:
    two_hour = 2 * 3_600_000
    cfg = SyntheticConfig(bars=8760, funding_interval_ms=two_hour)
    frame = generate_funding(cfg)
    assert (frame["ts"] % two_hour == 0).all()
    assert len(frame) > len(generate_funding(SyntheticConfig(bars=8760)))


def test_empty_and_tiny_windows_are_safe() -> None:
    assert len(generate_ohlcv(SyntheticConfig(bars=0))) == 0
    assert list(generate_ohlcv(SyntheticConfig(bars=0)).columns) == KLINE_COLUMNS
    # A window ending before the first settlement of the day: funding must be empty,
    # not an invented row.
    tiny = SyntheticConfig(bars=2, start_ts=1_700_000_100_000)
    assert len(generate_funding(tiny)) == 0


# -------------------------------------------------------------------------- panel


def test_panel_returns_correlated_but_distinct_symbols() -> None:
    symbols = ["AAAUSDT", "BBBUSDT", "CCCUSDT"]
    ohlcv, funding = generate_panel(symbols)

    assert set(ohlcv) == set(symbols)
    assert set(funding) == set(symbols)
    for symbol in symbols:
        assert list(ohlcv[symbol].columns) == KLINE_COLUMNS
        assert np.all(np.diff(ohlcv[symbol]["ts"].to_numpy()) == SyntheticConfig().interval_ms)
        assert list(funding[symbol].columns) == ["ts", "funding_rate"]

    vols = [float(_log_returns(ohlcv[s]).std(ddof=1)) for s in symbols]
    assert len({round(v, 12) for v in vols}) == len(symbols)


def test_panel_is_reproducible_and_rejects_unknown_overrides() -> None:
    first, first_funding = generate_panel(["AAAUSDT", "BBBUSDT"], bars=200)
    second, second_funding = generate_panel(["AAAUSDT", "BBBUSDT"], bars=200)
    for symbol in first:
        pd.testing.assert_frame_equal(first[symbol], second[symbol])
        pd.testing.assert_frame_equal(first_funding[symbol], second_funding[symbol])

    with pytest.raises(TypeError):
        generate_panel(["AAAUSDT"], not_a_field=1)
