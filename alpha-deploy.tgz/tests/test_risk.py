"""Tests for alpha.risk.sizing, alpha.risk.limits and alpha.risk.killswitch."""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
import pytest

from alpha.risk.killswitch import KillSwitch, RiskState
from alpha.risk.limits import ExposureLimits
from alpha.risk.sizing import (
    VOL_FLOOR,
    InstrumentSpec,
    kelly_fraction,
    participation_cap,
    vol_target_scale,
    weight_to_qty,
)

DAY_MS = 86_400_000


# ------------------------------------------------------------------ InstrumentSpec
def test_round_qty_always_rounds_toward_zero() -> None:
    spec = InstrumentSpec("BTCUSDT", qty_step=0.001)
    cases = [0.0015, -0.0015, 0.0029999999, -0.0029999999, 1.9999, -1.9999, 0.0001, -0.0001]

    for qty in cases:
        rounded = spec.round_qty(qty)
        # Never rounds *up* in magnitude (allow one float ULP of slop).
        assert abs(rounded) <= abs(qty) + 1e-12, f"{qty} rounded up to {rounded}"
        # Never jumps to the next step.
        assert abs(rounded) <= abs(qty)
        assert rounded == pytest.approx(round(rounded / spec.qty_step) * spec.qty_step, abs=1e-12)
        if qty != 0.0:
            assert math.copysign(1.0, rounded) == math.copysign(1.0, qty)

    assert spec.round_qty(0.0015) == pytest.approx(0.001)
    assert spec.round_qty(-0.0015) == pytest.approx(-0.001)
    assert spec.round_qty(1.9999) == pytest.approx(1.999)


def test_normalise_enforces_min_qty_min_notional_and_max_qty() -> None:
    spec = InstrumentSpec("BTCUSDT", qty_step=0.001, min_qty=0.01, min_notional=5.0, max_qty=10.0)

    # Below min_qty.
    assert spec.normalise(0.005, 50_000.0) == 0.0
    # Above min_qty but below min_notional.
    assert spec.normalise(0.01, 100.0) == 0.0
    # Valid size passes through unchanged.
    assert spec.normalise(0.02, 50_000.0) == pytest.approx(0.02)
    # Above max_qty is clipped to max_qty, sign preserved.
    assert spec.normalise(1_000.0, 50_000.0) == pytest.approx(10.0)
    assert spec.normalise(-1_000.0, 50_000.0) == pytest.approx(-10.0)


# ------------------------------------------------------------------ vol_target_scale
def test_vol_target_scale_rejects_unusable_volatility() -> None:
    assert vol_target_scale(0.0, 0.2) == 0.0
    assert vol_target_scale(-0.1, 0.2) == 0.0
    assert vol_target_scale(float("nan"), 0.2) == 0.0
    assert vol_target_scale(float("inf"), 0.2) == 0.0
    assert vol_target_scale(-float("inf"), 0.2) == 0.0


def test_vol_target_scale_is_target_over_realised_and_capped() -> None:
    # 0.2 / 0.4 = 0.5, comfortably above the floor and below the cap.
    assert vol_target_scale(0.4, 0.2) == pytest.approx(0.5)
    # Cap binds long before the raw ratio would.
    assert vol_target_scale(0.01, 0.2) == pytest.approx(3.0)
    # risk_scale multiplies the (already capped) scale.
    assert vol_target_scale(0.2, 0.2, risk_scale=0.5) == pytest.approx(0.5)


def test_vol_floor_prevents_explosive_sizing() -> None:
    # With vol far below the floor, the raw ratio would be 0.2/1e-6 = 200000.
    # The floor pins effective vol at VOL_FLOOR, giving 0.2/0.05 = 4.
    scale = vol_target_scale(1e-6, 0.2, max_scale=1e9)
    assert scale == pytest.approx(0.2 / VOL_FLOOR)
    assert scale == pytest.approx(4.0)


# --------------------------------------------------------------------- weight_to_qty
def test_weight_to_qty_sign_and_zero_handling() -> None:
    spec = InstrumentSpec("BTCUSDT", qty_step=0.001, min_qty=0.001, min_notional=5.0)

    assert weight_to_qty(1.0, 10_000.0, 50_000.0, spec) == pytest.approx(0.2)
    assert weight_to_qty(-1.0, 10_000.0, 50_000.0, spec) == pytest.approx(-0.2)

    assert weight_to_qty(1.0, 0.0, 50_000.0, spec) == 0.0
    assert weight_to_qty(1.0, 10_000.0, 0.0, spec) == 0.0
    assert weight_to_qty(1.0, -1.0, 50_000.0, spec) == 0.0
    assert weight_to_qty(float("nan"), 10_000.0, 50_000.0, spec) == 0.0

    # contract_size override: 10_000 / (50_000 * 0.1) = 2.0
    assert weight_to_qty(1.0, 10_000.0, 50_000.0, spec, contract_size=0.1) == pytest.approx(2.0)


# ------------------------------------------------------------------ kelly_fraction
def test_kelly_fraction_known_values_and_bounds() -> None:
    # Negative edge -> flat.
    assert kelly_fraction(0.3, 1.0) == 0.0
    assert kelly_fraction(0.3, 2.0) == 0.0  # 0.3 - 0.7/2 = -0.05
    # Known positive edge: 0.5 - 0.5/3 = 1/6 with a non-binding cap.
    assert kelly_fraction(0.5, 3.0, cap=1.0) == pytest.approx(1.0 / 3.0)
    # Cap binds.
    assert kelly_fraction(0.9, 10.0, cap=0.25) == pytest.approx(0.25)
    # Degenerate inputs.
    assert kelly_fraction(0.5, 0.0) == 0.0
    assert kelly_fraction(0.0, 2.0) == 0.0
    assert kelly_fraction(1.0, 2.0) == 0.0


# ----------------------------------------------------------------- participation_cap
def test_participation_cap_passes_through_caps_and_keeps_sign() -> None:
    # Under the cap: unchanged.
    assert participation_cap(0.5, 1_000.0, 0.1, 10.0) == pytest.approx(0.5)
    # Over the cap: capped at (1000 * 0.1) / 10 = 10 units.
    assert participation_cap(100.0, 1_000.0, 0.1, 10.0) == pytest.approx(10.0)
    assert participation_cap(-100.0, 1_000.0, 0.1, 10.0) == pytest.approx(-10.0)
    # Missing liquidity/price input -> no cap can be computed, pass through.
    assert participation_cap(100.0, 0.0, 0.1, 10.0) == pytest.approx(100.0)
    assert participation_cap(100.0, 1_000.0, 0.1, 0.0) == pytest.approx(100.0)


# ------------------------------------------------------------------- ExposureLimits
def test_exposure_per_symbol_cap_is_respected() -> None:
    limits = ExposureLimits(max_symbol_weight=0.3, max_gross_leverage=100.0, max_net_exposure=100.0)
    report = limits.apply({"A": 0.9, "B": -0.9})

    assert report.weights["A"] == pytest.approx(0.3)
    assert report.weights["B"] == pytest.approx(-0.3)


def test_exposure_gross_leverage_cap_is_respected() -> None:
    limits = ExposureLimits(
        max_gross_leverage=1.0,
        max_symbol_weight=1.0,
        max_concurrent_positions=10,
        max_net_exposure=100.0,
    )
    report = limits.apply({"A": 0.5, "B": 0.5, "C": 0.5, "D": 0.5})

    assert report.gross <= 1.0 + 1e-9
    assert report.gross == pytest.approx(1.0)


def test_exposure_net_cap_is_respected() -> None:
    limits = ExposureLimits(
        max_net_exposure=0.5,
        max_symbol_weight=10.0,
        max_gross_leverage=100.0,
        max_concurrent_positions=10,
    )
    report = limits.apply({"A": 0.5, "B": 0.5})

    assert abs(report.net) <= 0.5 + 1e-9


def test_exposure_caps_concurrent_positions_per_side() -> None:
    limits = ExposureLimits(
        max_concurrent_positions=2,
        max_symbol_weight=10.0,
        max_gross_leverage=100.0,
        max_net_exposure=100.0,
    )
    report = limits.apply({"A": 0.5, "B": 0.4, "C": 0.3, "D": -0.2, "E": -0.1})

    longs = [s for s, v in report.weights.items() if v > 0]
    shorts = [s for s, v in report.weights.items() if v < 0]
    assert len(longs) <= 2
    assert len(shorts) <= 2
    # The largest convictions survive.
    assert set(longs) == {"A", "B"}
    assert set(shorts) == {"D", "E"}


def test_exposure_correlation_group_reduces_correlated_gross() -> None:
    rng = np.random.default_rng(1)
    base = rng.normal(0.0, 0.01, 200)
    returns = pd.DataFrame(
        {
            "A": base + 0.0001 * rng.normal(size=200),
            "B": base + 0.0001 * rng.normal(size=200),
            "C": base + 0.0001 * rng.normal(size=200),
            "D": rng.normal(0.0, 0.01, 200),
        }
    )
    # Sanity: the A/B/C trio really is highly correlated and D is not.
    corr = returns.corr().abs()
    assert corr.loc["A", "B"] >= 0.8
    assert corr.loc["A", "D"] < 0.8

    limits = ExposureLimits(
        max_symbol_weight=1.0,
        max_gross_leverage=10.0,
        max_net_exposure=100.0,
        max_concurrent_positions=10,
        correlation_threshold=0.8,
        correlation_group_cap=1.2,
    )
    weights = {"A": 0.5, "B": 0.5, "C": 0.5, "D": -0.3}
    report = limits.apply(weights, returns=returns)

    gross_before = sum(abs(v) for v in weights.values())
    gross_after = sum(abs(v) for v in report.weights.values())
    assert gross_after < gross_before
    # The correlated trio is capped at 1.2 in aggregate; D is untouched.
    trio = sum(abs(report.weights[s]) for s in ("A", "B", "C"))
    assert trio == pytest.approx(1.2, rel=1e-6)
    assert report.weights["D"] == pytest.approx(-0.3)


def test_exposure_gross_cap_survives_the_net_adjustment() -> None:
    """BUG (see final report): the net-exposure shift is applied *after* the
    gross-leverage cap, and a constant additive shift can increase gross
    exposure. With one big long and two small shorts the net shift re-inflates
    gross past max_gross_leverage, so a documented *hard* limit is violated.
    """
    limits = ExposureLimits(
        max_gross_leverage=1.5,
        max_net_exposure=1.0,
        max_symbol_weight=10.0,
        max_concurrent_positions=10,
    )
    report = limits.apply({"A": 1.4, "B": -0.1, "C": -0.1})

    assert report.gross <= limits.max_gross_leverage + 1e-9, (
        f"gross={report.gross:.6f} exceeds max_gross_leverage="
        f"{limits.max_gross_leverage} after the net adjustment "
        f"(adjustments={report.adjustments})"
    )


def test_exposure_net_cap_does_not_flip_a_long_into_a_short() -> None:
    """BUG (see final report): the net cap subtracts a constant shift from every
    live weight. A small long can be pushed through zero and become a short,
    inventing exposure the strategy never asked for.
    """
    limits = ExposureLimits(
        max_net_exposure=0.3,
        max_symbol_weight=10.0,
        max_gross_leverage=100.0,
        max_concurrent_positions=10,
    )
    report = limits.apply({"A": 0.5, "B": 0.1})

    assert report.weights["B"] > 0.0, (
        f"long-only book B=+0.1 became {report.weights['B']!r} after the net cap"
    )


# --------------------------------------------------------------------- KillSwitch
def test_kill_switch_does_not_halt_on_five_small_losing_days() -> None:
    switch = KillSwitch()
    switch.update_equity(100.0, 0)

    equity = 100.0
    for day in range(1, 6):
        equity *= 0.985
        switch.update_equity(equity, day * DAY_MS)
        state, multiplier, reasons = switch.evaluate(day * DAY_MS)
        assert state is RiskState.ACTIVE, f"halted on day {day}: {reasons}"
        assert multiplier == pytest.approx(1.0)
        assert reasons == []

    # ~7.3% drawdown is well inside both the reduce and the hard limits.
    assert switch.state is RiskState.ACTIVE
    assert switch.history == []


def test_kill_switch_halts_at_max_drawdown() -> None:
    # Explicit limit: this test is about the mechanism, not about whatever the
    # default happens to be this month.
    switch = KillSwitch(max_drawdown=0.20)
    switch.update_equity(100.0, 0)
    switch.update_equity(79.0, 1_000)  # -21%, beyond the 20% limit

    state, multiplier, reasons = switch.evaluate(1_000)
    assert state is RiskState.HALTED
    assert multiplier == 0.0
    assert any("drawdown" in reason for reason in reasons)


def test_kill_switch_halts_at_daily_loss_limit() -> None:
    switch = KillSwitch(target_annual_vol=0.25)
    assert switch.effective_daily_limit == pytest.approx(4.0 * 0.25 / (365**0.5), rel=1e-6)
    switch.update_equity(100.0, 0)
    switch.update_equity(94.0, 1_000)  # -6% intraday, past the ~5.2% effective limit

    state, multiplier, reasons = switch.evaluate(1_000)
    assert state is RiskState.HALTED
    assert multiplier == 0.0
    assert any("daily loss" in reason for reason in reasons)


def test_kill_switch_halts_at_rolling_loss_limit() -> None:
    switch = KillSwitch(target_annual_vol=0.25, rolling_loss_days=20)
    # 3 sigma of a 20-day move on a 25%-vol book is ~17.6%, which is the effective
    # limit — not an arbitrary round number.
    assert switch.effective_rolling_limit == pytest.approx(0.1756, abs=1e-3)
    switch.update_equity(100.0, 0)
    switch.update_equity(80.0, 25 * DAY_MS)  # -20% over >20 calendar days

    state, multiplier, reasons = switch.evaluate(25 * DAY_MS)
    assert state is RiskState.HALTED
    assert multiplier == 0.0
    assert any("20-day loss" in reason for reason in reasons)


def test_loss_limits_scale_with_the_volatility_target() -> None:
    """A 12% loss means something completely different at 25% vol than at 10% vol.

    Expressing the limits as fixed percentages was the original defect: it made a
    20-day 12% drawdown a 2-sigma event for a 25%-vol book (fires by chance roughly
    yearly) while being a 5-sigma event for a 10%-vol book. The limits now move with
    the book's own risk.
    """
    low = KillSwitch(target_annual_vol=0.10)
    high = KillSwitch(target_annual_vol=0.40)

    assert high.effective_daily_limit > low.effective_daily_limit
    assert high.effective_rolling_limit > low.effective_rolling_limit
    # Floors still apply to a very quiet book.
    assert KillSwitch(target_annual_vol=0.01).effective_daily_limit >= 0.02
    assert KillSwitch(target_annual_vol=0.01).effective_rolling_limit >= 0.05


def test_default_drawdown_stop_sits_outside_the_books_own_noise_band() -> None:
    """Regression for a real finding: a 20% drawdown stop on a 25%-vol strategy
    halted a driftless random walk after 28 days. The expected worst drawdown of a
    vol-targeted book over a year is ~1.5-2x its annual volatility, so the stop must
    be set above the vol target or it closes healthy books."""
    from alpha.config import load_settings

    cfg = load_settings().risk
    assert cfg.max_drawdown_kill >= 1.2 * cfg.target_annual_vol, (
        f"drawdown stop {cfg.max_drawdown_kill:.0%} is inside the noise band of a "
        f"{cfg.target_annual_vol:.0%}-vol book"
    )


def test_kill_switch_is_latched_and_reset_rearms_it() -> None:
    switch = KillSwitch()
    switch.update_equity(100.0, 0)
    switch.update_equity(80.0, 1_000)
    assert switch.evaluate(1_000)[0] is RiskState.HALTED

    # Even after equity recovers, the switch stays tripped until an operator resets.
    switch.update_equity(200.0, 2_000)
    state, multiplier, reasons = switch.evaluate(2_000)
    assert state is RiskState.HALTED
    assert multiplier == 0.0
    assert "kill-switch latched" in reasons

    switch.reset(operator="test")
    assert switch.state is RiskState.ACTIVE
    assert switch.peak_equity == pytest.approx(200.0)

    # A fresh, non-triggering observation is evaluated rather than latched.
    switch.update_equity(200.0, DAY_MS)
    state, _, reasons = switch.evaluate(DAY_MS)
    assert state is RiskState.ACTIVE
    assert "kill-switch latched" not in reasons
    assert any("reset by test" in record.reason for record in switch.history)


def test_kill_switch_detects_stale_data() -> None:
    switch = KillSwitch()

    assert switch.check_data_staleness(1_000, 0) == "no market data received"
    assert switch.check_data_staleness(1_000, 1_000) is None

    stale = switch.check_data_staleness(1_000 + 200_000, 1_000)
    assert stale is not None
    assert "stale" in stale

    switch.update_equity(100.0, 0)
    state, multiplier, reasons = switch.evaluate(200_000, last_data_ts=1_000)
    assert state is RiskState.HALTED
    assert multiplier == 0.0
    assert any("stale" in reason for reason in reasons)


def test_kill_switch_derisks_gradually_before_the_hard_stop() -> None:
    switch = KillSwitch()
    switch.update_equity(100.0, 0)

    equity = 100.0
    for day in range(1, 15):  # fourteen ~-1% days -> ~13% drawdown
        equity *= 0.99
        switch.update_equity(equity, day * DAY_MS)

    state, multiplier, reasons = switch.evaluate(14 * DAY_MS)
    assert state is RiskState.ACTIVE
    assert 0.0 < multiplier < 1.0
    assert any("de-risking" in reason for reason in reasons)


def test_rebalance_threshold_is_size_invariant() -> None:
    """A 10% adjustment must be treated the same on a $500 book and a $5m book.

    The original implementation compared the adjustment to total equity, so a book
    running at a fraction of full investment rebalanced on changes that were tiny
    relative to the position but large relative to nothing in particular. The rule
    is now a fraction of the position itself.
    """
    from alpha.config import load_settings
    from alpha.risk.engine import RiskEngine

    cfg = load_settings().risk
    cfg.rebalance_threshold = 0.10
    cfg.min_order_notional = 1.0
    engine = RiskEngine(cfg)

    # Small book: 100 contracts at 100 = 10,000 notional.
    assert engine.needs_rebalance("X", target_qty=90.0, current_qty=100.0, price=100.0, equity=10_000)
    assert not engine.needs_rebalance("X", target_qty=99.0, current_qty=100.0, price=100.0, equity=10_000)

    # Same relative change, 100x bigger book, 100x bigger equity: same answer.
    assert engine.needs_rebalance("X", target_qty=9_000.0, current_qty=10_000.0, price=100.0, equity=1_000_000)
    assert not engine.needs_rebalance("X", target_qty=9_900.0, current_qty=10_000.0, price=100.0, equity=1_000_000)


def test_rebalance_never_skips_a_full_close() -> None:
    """A move to flat is always worth trading: it also releases the risk budget."""
    from alpha.config import load_settings
    from alpha.risk.engine import RiskEngine

    cfg = load_settings().risk
    cfg.rebalance_threshold = 0.5
    cfg.min_order_notional = 1.0
    engine = RiskEngine(cfg)
    assert engine.needs_rebalance("X", target_qty=0.0, current_qty=1.0, price=100.0, equity=10_000)
