"""Tests for alpha.backtest.metrics.

Hand-built equity curves and return series, no network, no fixtures from disk.
"""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
import pytest

from alpha.backtest.metrics import (
    cagr,
    calmar,
    drawdown_duration_bars,
    expected_shortfall,
    hit_rate,
    max_drawdown,
    profit_factor,
    sharpe,
    sortino,
    summarize,
    tail_ratio,
    ulcer_index,
    value_at_risk,
)
from alpha.features.indicators import bars_per_year

DOCUMENTED_KEYS = {
    "initial_equity",
    "final_equity",
    "total_return",
    "cagr",
    "sharpe",
    "sortino",
    "max_drawdown",
    "max_dd_duration_bars",
    "calmar",
    "annual_vol",
    "var_95",
    "es_95",
    "tail_ratio",
    "ulcer_index",
    "bars",
}


# --------------------------------------------------------------------- drawdown
def test_max_drawdown_known_fifty_percent() -> None:
    equity = pd.Series([100.0, 150.0, 75.0, 120.0])
    # peak 150 -> trough 75 is a 50% drawdown.
    assert max_drawdown(equity) == pytest.approx(0.5)


def test_max_drawdown_edge_cases() -> None:
    assert max_drawdown(pd.Series([100.0])) == 0.0
    assert max_drawdown(pd.Series([100.0, 110.0, 120.0])) == 0.0


def test_drawdown_duration_bars_known_underwater_stretch() -> None:
    equity = pd.Series([100.0, 110.0, 105.0, 108.0, 102.0, 100.0, 115.0, 120.0])
    # Underwater at indices 2,3,4,5 (105,108,102,100) -> four consecutive bars.
    assert drawdown_duration_bars(equity) == 4

    assert drawdown_duration_bars(pd.Series([100.0, 101.0, 102.0])) == 0


# ------------------------------------------------------------------------ sharpe
def test_sharpe_ignores_nan_and_inf_and_never_divides_by_zero() -> None:
    clean = pd.Series([0.01, -0.01, 0.02, 0.03])
    dirty = pd.Series([0.01, np.nan, np.inf, -np.inf, -0.01, 0.02, 0.03])

    result = sharpe(dirty, 365.0)
    assert math.isfinite(result)
    assert result == pytest.approx(sharpe(clean, 365.0))

    # A zero-variance, zero-mean stream is well defined here: 0.0, no crash.
    assert sharpe(pd.Series([0.0] * 50), 365.0) == 0.0


def test_sharpe_of_constant_positive_returns_is_infinite_or_large() -> None:
    """A monotone-up return stream has zero volatility, so its Sharpe is +inf
    (or at least enormous) -- never 0.0.

    BUG (see final report): `sharpe` guards only with `if sd <= 0`. For a
    constant series `std(ddof=1)` should be exactly 0, but float rounding leaves
    a ~1e-18 residue for most lengths, so the guard is bypassed and the result
    explodes to ~1e17; for other lengths the residue happens to be exactly 0.0
    and the function returns 0.0. The answer is float-noise dependent: n=10
    gives 1.04e17, n=50 gives 0.0. Both are wrong.
    """
    for n in (10, 50):
        result = sharpe(pd.Series([0.01] * n), 365.0)
        assert math.isinf(result) or result > 1e6, (
            f"constant positive returns of length {n} produced Sharpe={result!r}; "
            "0.0 reports 'no edge' for a strictly increasing equity curve"
        )


# ----------------------------------------------------------------------- sortino
def test_sortino_hand_computed_two_value_example() -> None:
    returns = pd.Series([0.01, -0.005])
    bars = 1.0
    # mean = 0.0025, downside deviation = sqrt(mean([0.005**2])) = 0.005,
    # sortino = mean / dd * sqrt(1) = 0.5.
    assert sortino(returns, bars) == pytest.approx(0.5)


def test_sortino_is_infinite_when_there_is_no_downside() -> None:
    result = sortino(pd.Series([0.01, 0.02, 0.03]), 365.0)
    assert math.isinf(result)


def test_sortino_not_less_than_sharpe_when_the_left_tail_is_removed() -> None:
    rng = np.random.default_rng(3)
    # Right-skewed: many small losses, few large gains. Downside deviation is
    # small relative to total volatility, so Sortino must beat Sharpe.
    returns = pd.Series(np.concatenate([rng.normal(-0.002, 0.001, 90), rng.normal(0.06, 0.01, 10)]))

    s = sharpe(returns, 365.0)
    so = sortino(returns, 365.0)
    assert so >= s
    assert so > 0.0


# ---------------------------------------------------------------------- cagr/calmar
def test_cagr_doubling_over_exactly_one_year() -> None:
    equity = pd.Series(np.linspace(100.0, 200.0, 365))
    # n=365 bars at daily interval -> years = 365/365 = 1 -> growth 2 -> 100%.
    assert cagr(equity, bars_per_year("D")) == pytest.approx(1.0, rel=1e-9)

    assert cagr(pd.Series([100.0]), bars_per_year("D")) == 0.0


def test_calmar_is_cagr_over_max_drawdown() -> None:
    equity = pd.Series([100.0, 200.0, 100.0, 200.0])
    bars = 4.0
    assert max_drawdown(equity) == pytest.approx(0.5)
    assert cagr(equity, bars) == pytest.approx(1.0)
    assert calmar(equity, bars) == pytest.approx(2.0)
    assert calmar(equity, bars) == pytest.approx(cagr(equity, bars) / max_drawdown(equity))


# --------------------------------------------------------------------- tail risk
def test_value_at_risk_and_expected_shortfall_on_a_loss_heavy_series() -> None:
    rng = np.random.default_rng(4)
    returns = pd.Series(np.concatenate([rng.normal(-0.02, 0.005, 80), rng.normal(0.01, 0.003, 20)]))

    var = value_at_risk(returns, 0.05)
    es = expected_shortfall(returns, 0.05)

    assert var < 0.0
    assert es < 0.0
    assert es <= var  # the average of the worst 5% is at least as bad as the 5% quantile


def test_var_and_es_are_zero_for_short_series() -> None:
    short = pd.Series([-0.1, -0.2, 0.05])
    assert value_at_risk(short, 0.05) == 0.0
    assert expected_shortfall(short, 0.05) == 0.0


# --------------------------------------------------------- trade-level statistics
def test_profit_factor_hand_computed_and_empty() -> None:
    trades = pd.DataFrame({"pnl": [1.0, -0.5, 2.0, -1.0]})
    # gains 3.0 / losses 1.5 = 2.0
    assert profit_factor(trades) == pytest.approx(2.0)
    assert profit_factor(pd.DataFrame()) == 0.0
    assert profit_factor(pd.DataFrame({"pnl": [1.0, 2.0]})) == math.inf
    assert profit_factor(pd.DataFrame({"other": [1.0]})) == 0.0


def test_hit_rate_hand_computed_and_empty() -> None:
    trades = pd.DataFrame({"pnl": [1.0, -0.5, 2.0, -1.0]})
    assert hit_rate(trades) == pytest.approx(0.5)
    assert hit_rate(pd.DataFrame()) == 0.0
    assert hit_rate(pd.DataFrame({"pnl": [np.nan, np.inf]})) == 0.0


def test_tail_ratio_direction_and_short_series() -> None:
    right_skewed = pd.Series(np.concatenate([np.full(90, -0.01), np.full(10, 0.1)]))
    left_skewed = pd.Series(np.concatenate([np.full(90, 0.01), np.full(10, -0.1)]))

    assert tail_ratio(right_skewed) > 1.0
    assert tail_ratio(left_skewed) < 1.0
    assert tail_ratio(pd.Series([0.01, -0.01])) == 0.0


def test_ulcer_index_hand_computed_and_empty() -> None:
    # equity [100, 90] -> drawdowns [0, 0.1] -> RMS = sqrt(0.005).
    assert ulcer_index(pd.Series([100.0, 90.0])) == pytest.approx(math.sqrt(0.005))
    assert ulcer_index(pd.Series([100.0, 100.0])) == 0.0
    assert ulcer_index(pd.Series([], dtype=float)) == 0.0


# ---------------------------------------------------------------------- summarize
def test_summarize_returns_all_documented_keys() -> None:
    equity = pd.Series([100.0, 105.0, 103.0, 110.0])
    returns = pd.Series([0.05, -0.02, 0.07])
    metrics = summarize(equity, returns, interval="D")

    assert DOCUMENTED_KEYS.issubset(metrics)
    for key, value in metrics.items():
        assert isinstance(value, float), f"{key} is not a float: {value!r}"
        assert not math.isnan(value), f"{key} is NaN"


def test_summarize_does_not_raise_on_three_point_curve() -> None:
    equity = pd.Series([100.0, 101.0, 102.0])
    returns = pd.Series([0.01, 0.01])
    metrics = summarize(equity, returns, interval="D")

    assert set(metrics) == DOCUMENTED_KEYS
    assert metrics["bars"] == 3.0
    assert metrics["initial_equity"] == 100.0
    assert metrics["final_equity"] == 102.0


def test_summarize_adds_trade_keys_when_trades_have_fees() -> None:
    equity = pd.Series([100.0, 101.0, 102.0, 103.0])
    returns = pd.Series([0.01, 0.01, 0.01])
    trades = pd.DataFrame({"fee": [0.5, 0.25], "notional": [100.0, 200.0]})

    metrics = summarize(equity, returns, interval="D", trades=trades)

    assert metrics["trades"] == 2.0
    assert metrics["fees_total"] == pytest.approx(0.75)
    assert metrics["turnover"] == pytest.approx(300.0)
