"""Ground-truth tests for the backtest engine.

These are the tests that decide whether any other number in this repository means
anything. They use hand-built price series where the correct answer is known
exactly, so a failure is unambiguous.

The two that matter most:

1. `test_no_lookahead_fill_uses_next_bar_open` — the fill price must be the NEXT
   bar's open, not the close the decision was made on.
2. `test_cannot_profit_from_a_move_you_decide_after` — a decision taken after a
   jump must not capture that jump. If this test ever passes with a profit, the
   whole backtest is fiction and every Sharpe in the repo is worthless.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from alpha.backtest.engine import BacktestEngine
from alpha.config import Settings, load_settings
from alpha.risk.sizing import InstrumentSpec

BAR_MS = 3_600_000
START_TS = 1_700_000_000_000
PRECISE = InstrumentSpec(symbol="SYNTHUSDT", qty_step=1e-9, min_qty=0.0, min_notional=0.0, max_qty=1e9)


def base_settings(**overrides) -> Settings:
    """Settings tuned for exact arithmetic: no fees, no slippage, no caps in the way."""
    s = load_settings()
    s.risk.initial_equity = 10_000.0
    s.risk.target_annual_vol = 0.25
    s.risk.vol_lookback_bars = 10
    s.risk.max_gross_leverage = 5.0
    s.risk.max_net_exposure = 5.0
    s.risk.max_symbol_weight = 1.0
    s.risk.max_concurrent_positions = 5
    s.risk.rebalance_threshold = 0.5  # only act on position changes > 50% of equity
    s.risk.min_order_notional = 1e-6
    s.risk.max_drawdown_kill = 1.0
    s.risk.reduce_at_drawdown = 0.0
    s.risk.daily_loss_limit = 1.0
    s.risk.rolling_loss_limit = 1.0
    s.risk.max_participation = 1.0
    s.costs.taker_fee_bps = 0.0
    s.costs.maker_fee_bps = 0.0
    s.costs.slippage_bps = 0.0
    s.costs.slippage_atr_mult = 0.0
    s.costs.funding_enabled = True
    for key, value in overrides.items():
        target, _, field = key.partition("__")
        setattr(getattr(s, target), field, value)
    return s


def make_features(
    opens: np.ndarray,
    closes: np.ndarray,
    *,
    vol: float = 0.25,
    funding: np.ndarray | None = None,
    volume: float = 1e9,
) -> pd.DataFrame:
    """Minimal feature frame carrying exactly the columns the engine reads."""
    n = len(opens)
    ts = START_TS + np.arange(n, dtype=np.int64) * BAR_MS
    return pd.DataFrame(
        {
            "ts": ts,
            "open": opens.astype(float),
            "close": closes.astype(float),
            "atr": np.full(n, 0.0),
            "atr_pct": np.zeros(n),
            "vol": np.full(n, vol),
            "volume": np.full(n, volume),
            "funding_rate": funding if funding is not None else np.zeros(n),
        }
    )


def make_weights(ts: np.ndarray, values: np.ndarray, symbol: str = "SYNTHUSDT") -> pd.DataFrame:
    return pd.DataFrame({symbol: values.astype(float)}, index=ts)


def run_engine(features: pd.DataFrame, weights: pd.DataFrame, settings: Settings, warmup: int = 0):
    engine = BacktestEngine(settings, specs={"SYNTHUSDT": PRECISE})
    return engine.run(weights, {"SYNTHUSDT": features}, warmup_bars=warmup)


# --------------------------------------------------------------- no lookahead
def test_no_lookahead_fill_uses_next_bar_open() -> None:
    """A decision made on bar 0's close must fill at bar 1's OPEN."""
    n = 12
    opens = np.full(n, 100.0)
    opens[1] = 101.0  # the bar after the first decision
    closes = opens + 0.5  # close != open, so the two are distinguishable
    features = make_features(opens, closes)
    weights = make_weights(features["ts"].to_numpy(), np.ones(n))

    result = run_engine(features, weights, base_settings())

    assert len(result.trades) >= 1, "expected at least one fill"
    first = result.trades.iloc[0]
    assert first["price"] == pytest.approx(101.0), (
        "fill price must be the next bar's open (101.0), not the decision bar's close (100.5)"
    )
    assert first["ts"] == features["ts"].iloc[1], "fill must be stamped on the bar it executes in"


def test_cannot_profit_from_a_move_you_decide_after() -> None:
    """The decisive anti-lookahead test.

    Price sits at 100 for bars 0-4, jumps to 110 at bar 5, then stays. We only
    take the long signal on bar 4's close — i.e. after the information that the
    move is coming is already public. A correct simulator fills at 110 and earns
    nothing. A simulator with lookahead fills at 100 and books a fake +10%.
    """
    n = 15
    closes = np.array([100.0] * 5 + [110.0] * (n - 5))
    opens = closes.copy()
    features = make_features(opens, closes)

    w = np.zeros(n)
    w[4:] = 1.0  # signal appears on bar 4, using bar 4's close only
    weights = make_weights(features["ts"].to_numpy(), w)

    result = run_engine(features, weights, base_settings())

    final = float(result.equity_curve.iloc[-1])
    assert final == pytest.approx(10_000.0, abs=1e-6), (
        f"deciding after the jump must not capture it; got {final:,.2f} "
        f"(lookahead would give ~11,000)"
    )


def test_profits_a_move_you_are_positioned_for_before_it() -> None:
    """The mirror image: a position taken BEFORE the jump must capture it.

    Together with the previous test this brackets the engine: it is neither
    clairvoyant nor inert.
    """
    n = 15
    closes = np.array([100.0] * 5 + [110.0] * (n - 5))
    opens = closes.copy()
    features = make_features(opens, closes)

    # Held for the whole window: entered at bar 1's open (100) and never exited,
    # so the move from 100 to 110 is ours to keep.
    w = np.ones(n)
    weights = make_weights(features["ts"].to_numpy(), w)
    result = run_engine(features, weights, base_settings())

    final = float(result.equity_curve.iloc[-1])
    # 100 contracts bought at 100, marked at 110 -> +1,000 on 10,000 equity.
    assert final == pytest.approx(11_000.0, abs=1.0), f"expected ~11,000, got {final:,.2f}"


# --------------------------------------------------------------------- costs
def test_fee_is_charged_exactly_on_notional() -> None:
    n = 10
    prices = np.full(n, 100.0)
    features = make_features(prices, prices)
    w = np.ones(n)  # one entry, never exits -> exactly one fee
    weights = make_weights(features["ts"].to_numpy(), w)

    settings = base_settings(costs__taker_fee_bps=10.0)
    result = run_engine(features, weights, settings)

    # 10,000 equity / 100 price = 100 contracts; 100 * 100 = 10,000 notional;
    # 10 bps of that is exactly 10.00.
    assert result.trades.iloc[0]["notional"] == pytest.approx(10_000.0, rel=1e-9)
    assert result.fees_paid == pytest.approx(10.0, rel=1e-9)
    assert float(result.equity_curve.iloc[-1]) == pytest.approx(9_990.0, abs=1e-6)


def test_slippage_is_adverse() -> None:
    """Buys must fill above and sells below the reference price."""
    n = 10
    prices = np.full(n, 100.0)
    features = make_features(prices, prices)
    w = np.zeros(n)
    w[0:3] = 1.0
    weights = make_weights(features["ts"].to_numpy(), w)

    settings = base_settings(costs__taker_fee_bps=0.0, costs__slippage_bps=10.0)
    result = run_engine(features, weights, settings)

    buy = result.trades[result.trades["qty"] > 0]
    assert not buy.empty
    assert buy.iloc[0]["price"] > 100.0, "a buy must fill above the mid"

    # Now the sell side.
    w2 = np.zeros(n)
    w2[0:3] = 1.0
    w2[4:6] = -1.0  # flip short: close long (sell) then open short (sell)
    weights2 = make_weights(features["ts"].to_numpy(), w2)
    result2 = run_engine(features, weights2, settings)
    sells = result2.trades[result2.trades["qty"] < 0]
    assert not sells.empty
    assert (sells["price"] < 100.0).all(), "sells must fill below the mid"


def test_higher_costs_strictly_reduce_equity() -> None:
    """Same signals, more friction, less money. If this can fail, costs are not wired in."""
    n = 60
    rng = np.random.default_rng(0)
    closes = 100 * np.exp(np.cumsum(rng.normal(0, 0.004, n)))
    opens = closes.copy()
    features = make_features(opens, closes)
    w = np.where(np.arange(n) % 10 < 5, 1.0, -1.0)  # churny on purpose
    weights = make_weights(features["ts"].to_numpy(), w)

    cheap = run_engine(features, weights, base_settings(costs__taker_fee_bps=0.0, costs__slippage_bps=0.0))
    pricey = run_engine(
        features,
        weights,
        base_settings(
            costs__taker_fee_bps=20.0,
            costs__slippage_bps=20.0,
            risk__rebalance_threshold=0.0001,
        ),
    )
    assert pricey.final_equity < cheap.final_equity
    assert pricey.fees_paid > cheap.fees_paid


# ------------------------------------------------------------------- funding
def test_long_pays_positive_funding_exactly() -> None:
    n = 10
    prices = np.full(n, 100.0)
    funding = np.zeros(n)
    funding[5] = 0.001  # 10 bps settled inside bar 5
    features = make_features(prices, prices, funding=funding)
    w = np.ones(n)  # held across the settlement bar
    weights = make_weights(features["ts"].to_numpy(), w)

    result = run_engine(features, weights, base_settings())

    # 100 contracts at 100 = 10,000 notional; 10 bps = 10 USDT paid out.
    assert result.funding_paid == pytest.approx(-10.0, rel=1e-9)
    assert float(result.equity_curve.iloc[-1]) == pytest.approx(9_990.0, abs=1e-6)


def test_short_receives_positive_funding() -> None:
    n = 10
    prices = np.full(n, 100.0)
    funding = np.zeros(n)
    funding[5] = 0.001
    features = make_features(prices, prices, funding=funding)
    w = np.full(n, -1.0)  # short, held across the settlement bar
    weights = make_weights(features["ts"].to_numpy(), w)

    result = run_engine(features, weights, base_settings())
    assert result.funding_paid == pytest.approx(10.0, rel=1e-9)


def test_funding_can_be_disabled() -> None:
    n = 10
    prices = np.full(n, 100.0)
    funding = np.zeros(n)
    funding[5] = 0.001
    features = make_features(prices, prices, funding=funding)
    w = np.ones(n)
    weights = make_weights(features["ts"].to_numpy(), w)

    result = run_engine(features, weights, base_settings(costs__funding_enabled=False))
    assert result.funding_paid == 0.0


# ------------------------------------------------------------- vol targeting
def test_vol_targeting_halves_size_when_vol_doubles() -> None:
    """The core sizing invariant: twice the volatility, half the position."""
    n = 20
    prices = np.full(n, 100.0)

    calm = make_features(prices, prices, vol=0.25)
    w = np.ones(n)
    r_calm = run_engine(calm, make_weights(calm["ts"].to_numpy(), w), base_settings())

    wild = make_features(prices, prices, vol=0.50)
    r_wild = run_engine(wild, make_weights(wild["ts"].to_numpy(), w), base_settings())

    qty_calm = abs(r_calm.trades.iloc[0]["qty"])
    qty_wild = abs(r_wild.trades.iloc[0]["qty"])
    assert qty_wild == pytest.approx(qty_calm / 2, rel=0.02)


# ---------------------------------------------------------------- risk layer
def test_kill_switch_flattens_a_collapsing_book() -> None:
    """A -60% price path with a permanent long must trip the drawdown stop and flatten."""
    n = 40
    closes = 100 * np.exp(np.linspace(0, -0.9, n))
    features = make_features(closes, closes)
    weights = make_weights(features["ts"].to_numpy(), np.ones(n))

    settings = base_settings(risk__max_drawdown_kill=0.20, risk__reduce_at_drawdown=0.0)
    result = run_engine(features, weights, settings)

    assert result.halted_at is not None, "the kill-switch should have engaged"
    final_positions = result.positions.iloc[-1].abs().sum()
    # Tolerance, not bit-exact zero: a fragment below the minimum order size is
    # uncloseable, which is a property of the exchange, not of the kill-switch.
    assert final_positions == pytest.approx(0.0, abs=1e-6), "the book must be flat after a halt"
    # Equity must stop moving once halted.
    tail = result.equity_curve.iloc[-5:]
    assert tail.nunique() == 1, "no trading should happen after the halt"


def test_risk_engine_respects_gross_leverage_cap() -> None:
    n = 20
    prices = np.full(n, 100.0)
    features = make_features(prices, prices, vol=0.01)  # tiny vol -> huge raw sizing
    weights = make_weights(features["ts"].to_numpy(), np.ones(n))

    settings = base_settings(risk__max_gross_leverage=1.5, risk__target_annual_vol=2.0)
    result = run_engine(features, weights, settings)

    gross = (result.positions.abs() * prices[:, None]).div(result.equity_curve.to_numpy(), axis=0)
    assert gross.to_numpy().max() <= 1.5 + 1e-6


# -------------------------------------------------------------- determinism
def test_backtest_is_deterministic() -> None:
    n = 80
    rng = np.random.default_rng(42)
    closes = 100 * np.exp(np.cumsum(rng.normal(0, 0.005, n)))
    features = make_features(closes, closes)
    weights = make_weights(features["ts"].to_numpy(), np.sin(np.arange(n) / 5))

    a = run_engine(features, weights, base_settings())
    b = run_engine(features, weights, base_settings())

    pd.testing.assert_series_equal(a.equity_curve, b.equity_curve)
    pd.testing.assert_frame_equal(a.trades, b.trades)


def test_engine_rejects_empty_input() -> None:
    settings = base_settings()
    engine = BacktestEngine(settings)
    with pytest.raises(ValueError):
        engine.run(pd.DataFrame(), {})
