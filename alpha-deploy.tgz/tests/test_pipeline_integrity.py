"""End-to-end honesty tests.

Unit tests prove the pieces work. These prove the *system* does not manufacture
profit out of nothing, which is the failure mode that matters: a lookahead bug or
a cost-accounting mistake does not make a backtest fail, it makes it look
brilliant.

The central test is `test_no_alpha_from_a_random_walk`. We build a market in
which tomorrow's price is, by construction, unpredictable from today's, run the
full stack (features -> strategy -> risk -> engine), and assert that it does not
produce a significant profit. A correct simulator returns roughly costs and
noise. A broken one returns a beautiful equity curve.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from alpha.backtest.engine import BacktestEngine
from alpha.config import load_settings
from alpha.data.synthetic import SyntheticConfig, generate_funding, generate_ohlcv
from alpha.features.pipeline import build_features
from alpha.risk.sizing import InstrumentSpec
from alpha.strategy.base import build_strategy
from alpha.strategy.portfolio import PortfolioStrategy

START_TS = 1_700_006_400_000


def synth_panel(
    symbols: list[str] | None = None,
    *,
    bars: int = 4000,
    annual_vol: float = 0.5,
    annual_drift: float | None = None,
    mean_reversion: float = 0.0,
    jump_prob: float = 0.0,
    common_factor: float = 0.5,
    seed: int = 11,
) -> tuple[dict[str, pd.DataFrame], dict[str, pd.DataFrame]]:
    """A correlated synthetic universe, defaulting to a driftless random walk.

    `annual_drift` defaults to ``-0.5 * vol**2``, the Ito correction that makes the
    *simple* price a martingale. Without it a log-space random walk still drifts
    upward in price terms, and "the strategy made money on a random walk" would be
    a true statement about arithmetic rather than about alpha.
    """
    symbols = symbols or ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
    if annual_drift is None:
        annual_drift = -0.5 * annual_vol**2

    factor = np.random.default_rng(seed).standard_normal(bars)
    ohlcv: dict[str, pd.DataFrame] = {}
    funding: dict[str, pd.DataFrame] = {}
    vols = [0.40, 0.55, 0.70]
    for i, sym in enumerate(symbols):
        cfg = SyntheticConfig(
            symbol=sym,
            start_ts=START_TS,
            bars=bars,
            annual_vol=vols[i % len(vols)],
            annual_drift=annual_drift,
            mean_reversion=mean_reversion,
            jump_prob=jump_prob,
            common_factor=common_factor,
            seed=seed + 100 * i,
        )
        ohlcv[sym] = generate_ohlcv(cfg, market_factor=factor)
        funding[sym] = generate_funding(cfg)
    return ohlcv, funding


def run_full_stack(
    panels: dict[str, pd.DataFrame],
    fundings: dict[str, pd.DataFrame],
    *,
    params: dict | None = None,
    risk_overrides: dict | None = None,
    warmup: int = 300,
):
    settings = load_settings()
    settings.data.symbols = list(panels)
    settings.risk.max_drawdown_kill = 1.0
    settings.risk.reduce_at_drawdown = 0.0
    settings.risk.daily_loss_limit = 1.0
    settings.risk.rolling_loss_limit = 1.0
    for key, value in (risk_overrides or {}).items():
        setattr(settings.risk, key, value)

    strategy = PortfolioStrategy(params={**settings.strategy.params, **(params or {})})
    weights, features = strategy.build_weight_matrix(panels, interval="60", fundings=fundings)

    specs = {
        s: InstrumentSpec(symbol=s, qty_step=1e-8, min_qty=0.0, min_notional=0.0, max_qty=1e9)
        for s in panels
    }
    engine = BacktestEngine(settings, specs=specs)
    return engine.run(weights, features, warmup_bars=warmup), weights, features


# ------------------------------------------------------------ the core check
def test_no_alpha_from_a_random_walk() -> None:
    """The system must not turn unpredictability into profit.

    Over ~4000 hourly bars, a driftless martingale market gives a correctly
    simulated strategy an expected return of roughly minus costs. We allow a
    generous band (the sampling error on a one-year Sharpe is ~1.0) but reject the
    signature of a lookahead bug, which shows up as a Sharpe far outside anything
    a real strategy could produce.
    """
    panels, fundings = synth_panel(bars=4000, seed=11)
    result, _, _ = run_full_stack(panels, fundings)

    equity = result.equity_curve
    rets = equity.pct_change().dropna()
    ann_factor = np.sqrt(365 * 24)
    sharpe = float(rets.mean() / rets.std(ddof=1) * ann_factor) if rets.std(ddof=1) > 0 else 0.0
    total = float(equity.iloc[-1] / equity.iloc[0] - 1.0)

    assert abs(sharpe) < 3.0, (
        f"a random walk produced Sharpe {sharpe:.2f} — that is the signature of "
        f"lookahead or a cost-accounting bug, not of skill"
    )
    assert total < 0.5, f"random walk returned {total:.1%}; expected roughly minus costs"


def test_no_alpha_across_several_random_seeds() -> None:
    """One lucky seed is not evidence. Sweep seeds and check the distribution."""
    totals = []
    for seed in (1, 2, 3, 5, 8):
        panels, fundings = synth_panel(bars=2500, seed=seed)
        result, _, _ = run_full_stack(panels, fundings)
        totals.append(float(result.equity_curve.iloc[-1] / result.equity_curve.iloc[0] - 1.0))

    totals = np.array(totals)
    # The median across independent unpredictable markets must be near zero. If the
    # median is strongly positive, the "edge" is an artefact of the pipeline.
    assert abs(float(np.median(totals))) < 0.15, (
        f"median return across random seeds is {np.median(totals):.1%} — "
        f"that is systematic, not noise: {np.round(totals, 4)}"
    )


# ------------------------------------------------------- costs actually bind
def test_costs_materially_reduce_a_random_walk_result() -> None:
    panels, fundings = synth_panel(bars=3000, seed=21)

    settings = load_settings()
    settings.risk.max_drawdown_kill = 1.0
    settings.risk.reduce_at_drawdown = 0.0
    settings.risk.daily_loss_limit = 1.0
    settings.risk.rolling_loss_limit = 1.0

    strategy = PortfolioStrategy(params=settings.strategy.params)
    weights, features = strategy.build_weight_matrix(panels, interval="60", fundings=fundings)
    specs = {
        s: InstrumentSpec(symbol=s, qty_step=1e-8, min_qty=0.0, min_notional=0.0, max_qty=1e9)
        for s in panels
    }

    settings.costs.taker_fee_bps = 0.0
    settings.costs.slippage_bps = 0.0
    zero_cost = BacktestEngine(settings, specs=specs).run(weights, features, warmup_bars=300)

    settings.costs.taker_fee_bps = 20.0
    settings.costs.slippage_bps = 15.0
    settings.risk.rebalance_threshold = 0.0001  # force frequent rebalancing
    priced = BacktestEngine(settings, specs=specs).run(weights, features, warmup_bars=300)

    assert priced.fees_paid > zero_cost.fees_paid
    assert priced.final_equity < zero_cost.final_equity


# ------------------------------------------------- the sleeves do what they say
def test_trend_sleeve_makes_money_in_a_trend_and_loses_in_chop() -> None:
    """A trend follower that cannot profit from a strong trend is broken."""
    bars = 3000
    ts = START_TS + np.arange(bars, dtype=np.int64) * 3_600_000
    rng = np.random.default_rng(3)

    # Strong uptrend with mild noise.
    trend_ret = 0.0006 + rng.normal(0, 0.004, bars)
    trend_prices = 100 * np.exp(np.cumsum(trend_ret))
    trend = pd.DataFrame(
        {
            "ts": ts,
            "open": trend_prices,
            "high": trend_prices * 1.002,
            "low": trend_prices * 0.998,
            "close": trend_prices,
            "volume": 1e6,
            "turnover": trend_prices * 1e6,
        }
    )
    feats = build_features(trend, interval="60", funding=None, params={})
    signal = build_strategy("trend", {}).generate(feats)
    # Average signal over the second half must be clearly long.
    assert signal.iloc[bars // 2 :].mean() > 0.1, "trend sleeve failed to get long in an uptrend"

    # Now a mean-reverting zigzag: the trend sleeve should not be persistently long.
    chop_prices = 100 + 3 * np.sin(np.arange(bars) / 6.0) + rng.normal(0, 0.2, bars)
    chop = pd.DataFrame(
        {
            "ts": ts,
            "open": chop_prices,
            "high": chop_prices * 1.002,
            "low": chop_prices * 0.998,
            "close": chop_prices,
            "volume": 1e6,
            "turnover": chop_prices * 1e6,
        }
    )
    chop_signal = build_strategy("trend", {}).generate(build_features(chop, interval="60", params={}))
    assert abs(chop_signal.iloc[bars // 2 :].mean()) < abs(signal.iloc[bars // 2 :].mean())


def test_meanrev_sleeve_is_gated_out_of_a_trend() -> None:
    """Mean reversion must be near-flat in a strong trend — that is the whole point
    of the chop gate. Without it the sleeve is a slow bleed in every bull market."""
    bars = 2500
    ts = START_TS + np.arange(bars, dtype=np.int64) * 3_600_000
    rng = np.random.default_rng(5)
    prices = 100 * np.exp(np.cumsum(0.0008 + rng.normal(0, 0.003, bars)))
    trend = pd.DataFrame(
        {
            "ts": ts,
            "open": prices,
            "high": prices * 1.002,
            "low": prices * 0.998,
            "close": prices,
            "volume": 1e6,
            "turnover": prices * 1e6,
        }
    )
    feats = build_features(trend, interval="60", params={})
    signal = build_strategy("meanrev", {}).generate(feats)
    assert abs(signal.iloc[bars // 2 :].abs().mean()) < 0.15, (
        "mean-reversion sleeve is taking large positions inside a strong trend; "
        "the regime gate is not working"
    )


# ------------------------------------------------------------------ risk path
def test_kill_switch_bounds_realised_drawdown_in_the_full_stack() -> None:
    """The invariant that matters: whatever the strategy does, the book's realised
    drawdown cannot run far past the configured kill level.

    Written as a bound rather than as "the switch must fire", because a trend
    sleeve that correctly goes *short* into a crash should not be stopped for
    doing its job. Either it never draws down that far, or it halts and goes flat —
    both are acceptable, and both satisfy the bound.
    """
    kill_level = 0.10
    panels, fundings = synth_panel(bars=2000, annual_drift=-2.0, annual_vol=0.6, seed=31)
    result, _, _ = run_full_stack(
        panels, fundings, risk_overrides={"max_drawdown_kill": kill_level, "reduce_at_drawdown": 0.0}
    )

    equity = result.equity_curve
    peak = equity.cummax()
    realised_dd = float((1.0 - equity / peak).max())

    # Allow a small overshoot: the stop is evaluated once per bar, so one bar of
    # slippage past the level is expected and honest.
    assert realised_dd <= kill_level + 0.08, (
        f"realised drawdown {realised_dd:.1%} ran well past the {kill_level:.0%} kill level — "
        f"the risk layer is not bounding the book"
    )
    if result.halted_at is not None:
        # An economically zero residual can survive a flatten: an order below the
        # exchange's minimum size cannot be placed, so the last fragment of a
        # position is uncloseable by design. Assert "no meaningful position", not
        # bit-exact zero.
        assert result.positions.iloc[-1].abs().sum() == pytest.approx(0.0, abs=1e-6)


def test_tighter_kill_level_never_produces_a_deeper_drawdown() -> None:
    """Monotonicity: a stricter stop must not make the drawdown worse."""
    panels, fundings = synth_panel(bars=2000, annual_drift=-1.5, annual_vol=0.6, seed=41)
    loose, _, _ = run_full_stack(
        panels, fundings, risk_overrides={"max_drawdown_kill": 0.30, "reduce_at_drawdown": 0.0}
    )
    tight, _, _ = run_full_stack(
        panels, fundings, risk_overrides={"max_drawdown_kill": 0.08, "reduce_at_drawdown": 0.0}
    )

    def max_dd(res) -> float:
        eq = res.equity_curve
        return float((1.0 - eq / eq.cummax()).max())

    assert max_dd(tight) <= max_dd(loose) + 0.02


# ------------------------------------------------------- walk-forward windows
def test_walk_forward_folds_are_disjoint_and_ordered(tmp_path) -> None:
    """Regression: the test windows were cumulative, so every fold re-reported the
    previous ones' returns and the report marched upward like a strategy that never
    loses. An out-of-sample evaluation whose folds overlap is not out-of-sample.
    """
    from alpha.config import load_settings
    from alpha.runner import walk_forward

    settings = load_settings()
    panels, _ = synth_panel(bars=1600, seed=77)

    saved = {}
    for sym, frame in panels.items():
        settings.data.root = tmp_path
        from alpha.data.store import ParquetStore

        store = ParquetStore(tmp_path)
        store.save_klines(sym, "60", frame, settings.bybit.category)
        store.save_funding(sym, pd.DataFrame(columns=["ts", "funding_rate"]), settings.bybit.category)
        saved[sym] = frame

    settings.data.symbols = list(panels)
    report = walk_forward(settings, train_bars=600, test_bars=200, interval="60", optimize=False)
    table = report.folds

    assert not table.empty
    for i in range(1, len(table)):
        previous_end = pd.Timestamp(table["end"].iloc[i - 1])
        this_start = pd.Timestamp(table["start"].iloc[i])
        assert this_start > previous_end, (
            f"fold {i} starts at {this_start} but fold {i-1} ended at {previous_end}: "
            f"test windows overlap, so the evaluation is not out-of-sample"
        )

    # With disjoint windows the returns must not be a monotone staircase.
    returns = table["test_return"].to_numpy()
    assert not np.all(np.diff(returns) >= 0), (
        "every fold better than the last is the signature of overlapping windows"
    )


# ------------------------------------------------- walk-forward verdict logic
def _report(returns, sharpes=None, halted=None, train_bars=500, test_bars=500):
    """Build a WalkForwardReport from crafted fold results, to test the verdict."""
    from alpha.runner import WalkForwardReport

    n = len(returns)
    sharpes = sharpes if sharpes is not None else list(returns)
    halted = halted if halted is not None else [False] * n
    folds = pd.DataFrame(
        {
            "fold": range(n),
            "start": pd.date_range("2026-01-01", periods=n, freq="D", tz="UTC"),
            "end": pd.date_range("2026-01-02", periods=n, freq="D", tz="UTC"),
            "test_return": returns,
            "test_max_dd": [0.01] * n,
            "test_sharpe": sharpes,
            "train_sharpe": [1.0] * n,
            "halted": halted,
        }
    )
    return WalkForwardReport(
        folds=folds,
        selected_params=pd.DataFrame(),
        train_bars=train_bars,
        test_bars=test_bars,
        interval="60",
        optimized=False,
    )


def test_verdict_refuses_to_certify_on_five_lucky_folds() -> None:
    """The exact situation this roadmap item ran into.

    Five profitable folds sounds convincing and is not: five coin flips come up
    heads once in thirty-two. A harness that certifies here is a rubber stamp.
    """
    report = _report([0.012, -0.007, 0.018, 0.017, -0.005])
    status, explanation = report.verdict()
    assert status == "INSUFFICIENT"
    assert "folds" in explanation


def test_verdict_certifies_a_long_run_of_consistent_gains() -> None:
    """The detector must actually be able to fire — otherwise it proves nothing."""
    rng = np.random.default_rng(0)
    # 24 folds over 500 daily bars, mean +0.6% with modest noise: a real, stable edge.
    returns = list(rng.normal(0.006, 0.008, 24))
    report = _report(returns, train_bars=2000, test_bars=500)
    status, explanation = report.verdict()
    assert status == "CERTIFIED", explanation
    assert report.t_stat > 2.0


def test_verdict_fails_a_strategy_that_loses_out_of_sample() -> None:
    returns = [-0.004, 0.002, -0.006, 0.001, -0.003, -0.005, 0.001, -0.002, -0.004, -0.001]
    report = _report(returns, train_bars=2000, test_bars=500)
    status, _ = report.verdict()
    assert status == "FAILED"


def test_verdict_flags_folds_killed_by_the_risk_limits() -> None:
    """A halted fold is flat: 0.00% return, 0.00 Sharpe. Reporting those as results
    is how a walk-forward silently becomes meaningless."""
    returns = [0.0] * 6 + [0.01, 0.012]
    report = _report(returns, halted=[True] * 6 + [False, False], train_bars=500, test_bars=500)
    assert report.halted_folds == 6
    status, explanation = report.verdict()
    assert status == "INSUFFICIENT"
    assert "kill-switch" in explanation


def test_verdict_needs_both_enough_folds_and_enough_time() -> None:
    # Plenty of folds, but each is tiny, so the out-of-sample period is short.
    report = _report([0.004] * 10, train_bars=200, test_bars=24)
    assert report.n_folds == 10
    assert report.oos_days < 120
    status, explanation = report.verdict()
    assert status == "INSUFFICIENT"
    assert "out-of-sample days" in explanation
