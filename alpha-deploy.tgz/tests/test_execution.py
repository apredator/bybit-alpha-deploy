"""Execution-layer tests.

The first two tests in this file are regression tests for bugs that were found by
actually *running* the agent, not by reading the code — which is the point:
execution paths only fail when exercised.

  1. `PaperBroker` did not implement `flatten`, so the kill-switch path crashed
     with an AttributeError at the exact moment it was needed. A broker that
     cannot flatten is not a broker.
  2. The agent's staleness check compared a fixed 180s limit against an hourly bar,
     so every cycle tripped "stale market data" and the kill-switch engaged
     immediately, every time. A safety check that always fires is worse than none:
     it teaches the operator to disable it.
"""

from __future__ import annotations

import numpy as np
import pytest

from alpha.config import load_settings
from alpha.execution.broker import Broker, make_client_id, plan_orders, validate_order
from alpha.execution.paper import PaperBroker
from alpha.portfolio import PortfolioLedger
from alpha.risk.sizing import InstrumentSpec
from alpha.types import Order, OrderStatus, OrderType, Side

SPEC = InstrumentSpec(symbol="BTCUSDT", qty_step=0.001, min_qty=0.001, min_notional=5.0, max_qty=1000)


# ------------------------------------------------------------------ planning
def test_plan_orders_no_change_is_no_orders() -> None:
    assert plan_orders("BTCUSDT", 1.0, 1.0, SPEC, 50_000, ts=1) == []
    assert plan_orders("BTCUSDT", 0.0, 0.0, SPEC, 50_000, ts=1) == []


def test_plan_orders_increase_is_a_single_order() -> None:
    orders = plan_orders("BTCUSDT", 0.0, 1.0, SPEC, 50_000, ts=1)
    assert len(orders) == 1
    assert orders[0].side is Side.BUY
    assert orders[0].qty == pytest.approx(1.0)
    assert orders[0].reduce_only is False


def test_plan_orders_reduction_is_reduce_only() -> None:
    """Shrinking a position must never be able to open a new one."""
    orders = plan_orders("BTCUSDT", 2.0, 1.0, SPEC, 50_000, ts=1)
    assert len(orders) == 1
    assert orders[0].side is Side.SELL
    assert orders[0].reduce_only is True
    assert orders[0].qty == pytest.approx(1.0)


def test_plan_orders_full_close_is_reduce_only() -> None:
    orders = plan_orders("BTCUSDT", 1.5, 0.0, SPEC, 50_000, ts=1)
    assert len(orders) == 1
    assert orders[0].reduce_only is True
    assert orders[0].qty == pytest.approx(1.5)


def test_plan_orders_flip_is_two_orders_close_first() -> None:
    """A flip must be close-then-open, never one oversized order crossing zero.

    One order that crosses zero is the classic way to end up with twice the
    intended size, because the closing and opening halves have different risk
    meaning and only the closing half may be reduce-only.
    """
    orders = plan_orders("BTCUSDT", 1.0, -0.5, SPEC, 50_000, ts=1)
    assert len(orders) == 2, "flip must be split into a close and an open"
    close, open_ = orders
    assert close.side is Side.SELL and close.reduce_only is True
    assert close.qty == pytest.approx(1.0)
    assert open_.side is Side.SELL and open_.reduce_only is False
    assert open_.qty == pytest.approx(0.5)


def test_plan_orders_respects_exchange_step() -> None:
    orders = plan_orders("BTCUSDT", 0.0, 0.0019, SPEC, 50_000, ts=1)
    # Rounds toward zero to 0.001, never up to 0.002.
    assert orders[0].qty == pytest.approx(0.001)


def test_client_ids_are_deterministic_and_unique_per_intent() -> None:
    """Idempotency: the same intent must produce the same id (so a retry is a no-op),
    while different intents must not collide."""
    a = make_client_id("live", "BTCUSDT", 1.0, 100)
    b = make_client_id("live", "BTCUSDT", 1.0, 100)
    assert a == b

    different_ts = make_client_id("live", "BTCUSDT", 1.0, 101)
    different_qty = make_client_id("live", "BTCUSDT", 2.0, 100)
    different_sym = make_client_id("live", "ETHUSDT", 1.0, 100)
    assert len({a, different_ts, different_qty, different_sym}) == 4


def test_retrying_a_flip_produces_the_same_client_ids() -> None:
    first = plan_orders("BTCUSDT", 1.0, -0.5, SPEC, 50_000, ts=7)
    second = plan_orders("BTCUSDT", 1.0, -0.5, SPEC, 50_000, ts=7)
    assert [o.client_id for o in first] == [o.client_id for o in second]


# -------------------------------------------------------------- validation
def test_validate_order_rejects_below_min_notional() -> None:
    order = Order(symbol="BTCUSDT", side=Side.BUY, qty=0.001)
    assert validate_order(order, SPEC, price=100.0, equity=10_000, max_leverage=2.0) is not None


def test_validate_order_rejects_non_positive_qty() -> None:
    order = Order(symbol="BTCUSDT", side=Side.BUY, qty=0.0)
    assert validate_order(order, SPEC, price=50_000, equity=10_000, max_leverage=2.0) is not None


def test_validate_order_rejects_unaligned_qty() -> None:
    order = Order(symbol="BTCUSDT", side=Side.BUY, qty=0.0015)
    assert validate_order(order, SPEC, price=50_000, equity=10_000, max_leverage=2.0) is not None


def test_validate_order_rejects_excessive_leverage_but_allows_reduce_only() -> None:
    big = Order(symbol="BTCUSDT", side=Side.BUY, qty=1.0)  # 50,000 on 10,000 equity
    assert validate_order(big, SPEC, price=50_000, equity=10_000, max_leverage=2.0) is not None

    # The same size is fine when it is closing risk rather than opening it.
    big.reduce_only = True
    assert validate_order(big, SPEC, price=50_000, equity=10_000, max_leverage=2.0) is None


def test_validate_order_accepts_a_sane_order() -> None:
    order = Order(symbol="BTCUSDT", side=Side.BUY, qty=0.1)
    assert validate_order(order, SPEC, price=50_000, equity=10_000, max_leverage=2.0) is None


# ------------------------------------------------------------ broker contract
def test_paper_broker_implements_the_full_broker_interface() -> None:
    """Regression: PaperBroker was missing `flatten`, so the kill-switch path —
    the one path that must never fail — crashed with AttributeError."""
    assert issubclass(PaperBroker, Broker)
    for method in ("account_state", "positions", "mark_prices", "submit", "cancel_all", "flatten", "reconcile"):
        assert callable(getattr(PaperBroker, method, None)), f"PaperBroker.{method} missing"


def test_paper_broker_flatten_closes_everything() -> None:
    settings = load_settings()
    settings.costs.taker_fee_bps = 0.0
    settings.costs.slippage_bps = 0.0

    marks = {"BTCUSDT": 50_000.0, "ETHUSDT": 3_000.0}
    broker = PaperBroker(settings, lambda syms: {s: marks[s] for s in syms if s in marks})
    broker.ledger.apply_fill("BTCUSDT", 0.5, 50_000.0)
    broker.ledger.apply_fill("ETHUSDT", -2.0, 3_000.0)

    assert broker.positions()

    orders = broker.flatten(["BTCUSDT", "ETHUSDT"])
    assert len(orders) == 2
    assert all(o.reduce_only for o in orders), "an emergency exit must never open risk"
    assert all(o.status is OrderStatus.FILLED for o in orders)
    assert broker.positions() == {}, "flatten must leave the book empty"


def test_paper_broker_honours_reduce_only() -> None:
    """A reduce-only order that would increase exposure must be dropped, exactly
    as the exchange would drop it."""
    settings = load_settings()
    broker = PaperBroker(settings, lambda syms: {"BTCUSDT": 50_000.0})
    broker.ledger.apply_fill("BTCUSDT", 0.5, 50_000.0)

    # Long 0.5, and someone sends a reduce-only BUY: that increases the position.
    order = Order(symbol="BTCUSDT", side=Side.BUY, qty=0.5, reduce_only=True, order_type=OrderType.MARKET)
    broker.submit([order])

    assert broker.ledger.qty("BTCUSDT") == pytest.approx(0.5), "reduce-only must not add exposure"
    assert order.status is OrderStatus.CANCELLED


def test_paper_broker_is_deterministic_and_charges_costs() -> None:
    settings = load_settings()
    settings.costs.taker_fee_bps = 10.0
    settings.costs.slippage_bps = 0.0
    broker = PaperBroker(settings, lambda syms: {"BTCUSDT": 50_000.0})
    broker.ledger.cash = 10_000.0

    order = Order(symbol="BTCUSDT", side=Side.BUY, qty=0.1)
    broker.submit([order])

    expected_fee = 0.1 * 50_000.0 * 10.0 / 1e4
    assert order.fee == pytest.approx(expected_fee)
    assert broker.ledger.fees_paid == pytest.approx(expected_fee)


# ------------------------------------------------------- agent staleness bug
def test_agent_scales_staleness_limit_to_the_bar_interval() -> None:
    """Regression: a fixed 180s staleness limit against an hourly bar meant every
    cycle reported 'stale market data' and the kill-switch engaged instantly."""
    from alpha.live.agent import TradingAgent

    settings = load_settings()
    settings.data.interval = "60"
    settings.risk.max_data_staleness_s = 180
    broker = PaperBroker(settings, lambda syms: {})

    agent = TradingAgent(settings, broker, rest=None)  # type: ignore[arg-type]
    # 3600s bar * 2.5 = 9000s, comfortably above one bar.
    assert agent.risk.kill_switch.max_data_staleness_s >= 3600
    assert agent.risk.kill_switch.check_data_staleness(
        ts=10_000_000, last_data_ts=10_000_000 - 3_600_000
    ) is None, "a one-bar-old candle is normal, not stale"


def test_agent_still_detects_a_genuinely_dead_feed() -> None:
    from alpha.live.agent import TradingAgent

    settings = load_settings()
    settings.data.interval = "60"
    broker = PaperBroker(settings, lambda syms: {})
    agent = TradingAgent(settings, broker, rest=None)  # type: ignore[arg-type]

    limit = agent.risk.kill_switch.max_data_staleness_s
    # Three bars without a new close is a dead feed, not a quiet market.
    assert agent.risk.kill_switch.check_data_staleness(
        ts=10_000_000_000, last_data_ts=10_000_000_000 - int(limit * 1000) - 1
    ) is not None


def test_ledger_marks_and_records_funding() -> None:
    ledger = PortfolioLedger(cash=10_000.0)
    ledger.apply_fill("BTCUSDT", 0.1, 50_000.0)
    assert ledger.equity({"BTCUSDT": 50_000.0}) == pytest.approx(10_000.0)
    assert ledger.equity({"BTCUSDT": 51_000.0}) == pytest.approx(10_100.0)

    paid = ledger.apply_funding("BTCUSDT", 0.001, 50_000.0)
    assert paid == pytest.approx(-5.0)  # 0.1 * 50,000 * 0.001
    assert ledger.funding_paid == pytest.approx(-5.0)


# --------------------------------------------------- live data-quality gate
class _FakeREST:
    """Minimal Bybit REST stand-in: enough for `build_signals` to run offline."""

    def __init__(self, bars_by_symbol, funding=None):
        self.bars_by_symbol = bars_by_symbol
        self.funding = funding if funding is not None else []
        self.cfg = type("C", (), {"category": "linear"})()

    def klines(self, symbol, interval="60", limit=1000, **kwargs):
        return self.bars_by_symbol.get(symbol, [])

    def funding_history(self, symbol, **kwargs):
        return self.funding


def _bars(n=400, price=100.0, seed=0, bad_from=None):
    """Bybit-shaped rows: [start, open, high, low, close, volume, turnover], newest first."""
    rng = np.random.default_rng(seed)
    close = price + np.cumsum(rng.normal(0, 0.3, n))
    rows = []
    for i in range(n):
        t = 1_700_000_000_000 + i * 3_600_000
        c = float(close[i])
        o = c - float(rng.normal(0, 0.1))
        hi = max(o, c) + 0.2
        lo = min(o, c) - 0.2
        if bad_from is not None and i >= bad_from:
            c = price * 12.0  # a close far outside anything nearby
        rows.append([str(t), str(o), str(hi), str(lo), str(c), "10.0", str(c * 10)])
    return list(reversed(rows))  # Bybit returns newest first


def _agent(settings, bars_by_symbol, tmp_path=None):
    """Build an agent whose state files land in a temp dir.

    Test isolation matters here: the agent writes a status/heartbeat file on every
    cycle, and pointing that at the repository by default meant running the test
    suite clobbered the real deployment's `data/live_status.json` — which then made
    `alpha health` report on a state that no live process had ever produced.
    """
    from alpha.live.agent import TradingAgent

    if tmp_path is not None:
        settings.data.root = tmp_path / "raw"
    broker = PaperBroker(settings, lambda syms: {"BTCUSDT": 100.0, "ETHUSDT": 100.0})
    status = (tmp_path / "live_status.json") if tmp_path is not None else None
    return TradingAgent(settings, broker, _FakeREST(bars_by_symbol), status_path=status)


def test_agent_trades_a_clean_feed(tmp_path) -> None:
    settings = load_settings()
    settings.data.symbols = ["BTCUSDT"]
    agent = _agent(settings, {"BTCUSDT": _bars(seed=1)}, tmp_path)

    panels, weights = agent.build_signals()

    assert "BTCUSDT" in panels
    assert agent.quality_rejections == {}


def test_agent_refuses_a_symbol_with_corrupt_closes(tmp_path) -> None:
    """The whole point of the QC work: cleaning data is not a licence to trade it.

    A repaired bar is an estimate. Sizing a real position on an estimated price is
    how a bad feed becomes a bad position, so the symbol is skipped outright.
    """
    settings = load_settings()
    settings.data.symbols = ["BTCUSDT"]
    settings.data.max_bad_bar_fraction = 0.02
    # Corrupt the most recent 12% of bars.
    agent = _agent(settings, {"BTCUSDT": _bars(n=400, seed=2, bad_from=350)}, tmp_path)

    panels, weights = agent.build_signals()

    assert panels == {}, "a symbol with corrupt closes must not reach the strategy"
    assert "BTCUSDT" in agent.quality_rejections
    assert "corrupt close" in agent.quality_rejections["BTCUSDT"]


def test_agent_refuses_a_symbol_whose_wicks_are_unreliable(tmp_path) -> None:
    """Clamped wicks are tolerable in small numbers. Past a threshold the ATR — and
    therefore every position size and stop — is built on noise."""
    settings = load_settings()
    settings.data.symbols = ["BTCUSDT"]
    settings.data.max_wick_fraction = 0.05

    rows = _bars(n=400, seed=3)
    # Blow out the high of ~30% of bars while leaving closes coherent.
    for i in range(0, 120):
        rows[i][2] = str(float(rows[i][4]) * 4.0)
    agent = _agent(settings, {"BTCUSDT": rows}, tmp_path)

    panels, _ = agent.build_signals()

    assert panels == {}
    assert "wick" in agent.quality_rejections["BTCUSDT"]


def test_agent_stands_aside_entirely_when_every_symbol_is_untrusted(tmp_path) -> None:
    settings = load_settings()
    settings.data.symbols = ["BTCUSDT", "ETHUSDT"]
    agent = _agent(
        settings,
        {
            "BTCUSDT": _bars(n=400, seed=4, bad_from=340),
            "ETHUSDT": _bars(n=400, seed=5, bad_from=340),
        },
        tmp_path,
    )

    cycle = agent.run_once()

    assert cycle.skipped.startswith("every symbol failed the data-quality gate")
    assert len(agent.quality_rejections) == 2


def test_agent_keeps_trading_the_symbols_it_can_trust(tmp_path) -> None:
    """One bad symbol must not take the whole book offline."""
    settings = load_settings()
    settings.data.symbols = ["BTCUSDT", "ETHUSDT"]
    agent = _agent(
        settings,
        {"BTCUSDT": _bars(n=400, seed=6), "ETHUSDT": _bars(n=400, seed=7, bad_from=300)},
        tmp_path,
    )

    panels, _ = agent.build_signals()

    assert "BTCUSDT" in panels
    assert "ETHUSDT" not in panels
    assert "ETHUSDT" in agent.quality_rejections
