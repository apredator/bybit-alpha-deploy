"""Tests for alpha.data.validation.

All frames are synthetic and offline. `clean_ohlcv` is checked against its two
hard guarantees: the clock is never altered and no repaired row is left
physically impossible.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from alpha.data.validation import (
    QualityReport,
    clean_ohlcv,
    detect_gaps,
    hampel_mask,
    range_mask,
    structural_mask,
)

HOUR_MS = 3_600_000


def _clean_frame(n: int = 120, seed: int = 11) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    ts = np.arange(n, dtype=np.int64) * HOUR_MS
    close = 100.0 + np.cumsum(rng.normal(0.0, 0.5, n))
    open_ = close + rng.normal(0.0, 0.2, n)
    high = np.maximum(open_, close) + rng.uniform(0.05, 0.4, n)
    low = np.minimum(open_, close) - rng.uniform(0.05, 0.4, n)
    return pd.DataFrame(
        {
            "ts": ts,
            "open": open_,
            "high": high,
            "low": low,
            "close": close,
            "volume": rng.uniform(1.0, 10.0, n),
        }
    )


# ------------------------------------------------------------------ structural_mask
def test_structural_mask_flags_impossible_candles_and_passes_clean_data() -> None:
    clean = pd.DataFrame(
        {"open": [10.0], "high": [11.0], "low": [9.0], "close": [10.0], "volume": [1.0]}
    )
    assert not structural_mask(clean).any()

    crossed = pd.DataFrame(
        {"open": [10.0], "high": [9.0], "low": [10.0], "close": [10.0], "volume": [1.0]}
    )
    assert structural_mask(crossed).tolist() == [True]

    non_positive = pd.DataFrame(
        {"open": [10.0, -1.0], "high": [11.0, 1.0], "low": [9.0, -2.0], "close": [10.0, 1.0],
         "volume": [1.0, 1.0]}
    )
    assert structural_mask(non_positive).tolist() == [False, True]

    with_nan = pd.DataFrame(
        {"open": [10.0], "high": [11.0], "low": [9.0], "close": [np.nan], "volume": [1.0]}
    )
    assert structural_mask(with_nan).tolist() == [True]

    negative_volume = pd.DataFrame(
        {"open": [10.0], "high": [11.0], "low": [9.0], "close": [10.0], "volume": [-1.0]}
    )
    assert structural_mask(negative_volume).tolist() == [True]

    # high below the open/close body is equally impossible.
    bad_body = pd.DataFrame(
        {"open": [10.0], "high": [10.5], "low": [9.0], "close": [11.0], "volume": [1.0]}
    )
    assert structural_mask(bad_body).tolist() == [True]


# --------------------------------------------------------------------- hampel_mask
def test_hampel_mask_flags_a_single_spike_but_not_noise() -> None:
    rng = np.random.default_rng(2)
    log_price = np.log(100.0) + rng.normal(0.0, 0.005, 200)
    log_price[100] += np.log(11.0)  # a +1000% print

    mask = hampel_mask(log_price, window=24, n_sigma=6.0)
    assert mask.sum() == 1
    assert bool(mask[100])

    calm = np.log(100.0) + rng.normal(0.0, 0.005, 200)
    assert not hampel_mask(calm, window=24, n_sigma=6.0).any()


# ---------------------------------------------------------------------- range_mask
def test_range_mask_flags_implausible_bar() -> None:
    wide = pd.DataFrame(
        {"open": [110.0], "high": [200.0], "low": [100.0], "close": [110.0], "volume": [1.0]}
    )
    assert range_mask(wide, max_range_frac=0.35).tolist() == [True]

    normal = pd.DataFrame(
        {"open": [110.0], "high": [111.0], "low": [109.0], "close": [110.0], "volume": [1.0]}
    )
    assert range_mask(normal, max_range_frac=0.35).tolist() == [False]


# --------------------------------------------------------------------- detect_gaps
def test_detect_gaps_flags_a_missing_bar_and_passes_a_regular_series() -> None:
    regular = np.arange(10, dtype=np.int64) * HOUR_MS
    assert not detect_gaps(regular, HOUR_MS).any()

    with_hole = np.delete(regular, 5)
    gaps = detect_gaps(with_hole, HOUR_MS)
    assert gaps.sum() == 1
    assert bool(gaps[5])

    assert not detect_gaps(np.array([0], dtype=np.int64), HOUR_MS).any()


# --------------------------------------------------------------------- clean_ohlcv
def test_clean_ohlcv_repairs_corrupt_bar_without_moving_the_clock() -> None:
    frame = _clean_frame()
    bad_index = 50
    frame.loc[bad_index, ["open", "high", "low", "close"]] = [1000.0, 1001.0, 999.0, 1000.0]

    cleaned, report = clean_ohlcv(frame, symbol="TEST", expected_ms=HOUR_MS)

    # The clock is preserved exactly: same rows, still strictly increasing.
    assert len(cleaned) == len(frame)
    assert cleaned["ts"].is_monotonic_increasing
    assert cleaned["ts"].is_unique
    assert cleaned["ts"].tolist() == frame["ts"].tolist()

    # The corrupt bar is marked and only it was repaired.
    assert bool(cleaned["is_bad"].iloc[bad_index])
    assert report.repaired == int(cleaned["is_bad"].sum())
    assert report.repaired == 1
    assert report.bad_fraction == report.repaired / report.rows
    assert report.bad_fraction == pytest.approx(1.0 / len(frame))
    assert report.rows == len(frame)

    # Every row is physically possible after repair.
    prices = cleaned[["open", "high", "low", "close"]].to_numpy(dtype=float)
    assert np.isfinite(prices).all()
    assert (prices > 0).all()
    assert (cleaned["high"] >= np.maximum(cleaned["open"], cleaned["close"])).all()
    assert (cleaned["low"] <= np.minimum(cleaned["open"], cleaned["close"])).all()

    # The fake print is gone and the repaired bar has no volume.
    assert cleaned["close"].iloc[bad_index] != 1000.0
    assert cleaned["volume"].iloc[bad_index] == 0.0


def test_clean_ohlcv_reports_zero_repairs_for_a_clean_frame() -> None:
    frame = _clean_frame()
    cleaned, report = clean_ohlcv(frame, symbol="CLEAN", expected_ms=HOUR_MS)

    assert report.repaired == 0
    assert report.bad_fraction == 0.0
    assert report.structural == 0
    assert report.spikes == 0
    assert report.range_outliers == 0
    assert not cleaned["is_bad"].any()
    assert len(cleaned) == len(frame)


def test_clean_ohlcv_structural_repair_of_a_crossed_candle() -> None:
    frame = _clean_frame()
    bad_index = 30
    # Physically impossible: high < low, with the body inside the wrong range.
    frame.loc[bad_index, ["open", "high", "low", "close"]] = [100.0, 90.0, 110.0, 100.0]

    cleaned, report = clean_ohlcv(frame, symbol="CROSSED", expected_ms=HOUR_MS)

    assert len(cleaned) == len(frame)
    assert report.structural >= 1
    assert bool(cleaned["is_bad"].iloc[bad_index])
    assert report.repaired == int(cleaned["is_bad"].sum())
    prices = cleaned[["open", "high", "low", "close"]].to_numpy(dtype=float)
    assert (prices > 0).all()
    assert (cleaned["high"] >= np.maximum(cleaned["open"], cleaned["close"])).all()
    assert (cleaned["low"] <= np.minimum(cleaned["open"], cleaned["close"])).all()


def test_clean_ohlcv_empty_frame_does_not_raise() -> None:
    empty = pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])
    cleaned, report = clean_ohlcv(empty, symbol="EMPTY")

    assert isinstance(report, QualityReport)
    assert cleaned.empty
    assert report.rows == 0
    assert report.repaired == 0
    assert report.bad_fraction == 0.0


def test_quality_report_bad_fraction_is_safe_when_rows_is_zero() -> None:
    assert QualityReport(symbol="X").bad_fraction == 0.0


# --------------------------------------------------- wick vs close distinction
def test_a_corrupt_wick_does_not_destroy_a_good_close() -> None:
    """Regression for a real finding on the exchange feed.

    SOLUSDT arrived with a perfectly coherent close path but wild high/low on ~19%
    of bars (`open=100.35, close=99.73, low=39.12`). Collapsing the whole bar — the
    original behaviour — threw away the return observation to fix a wick, and
    reported a 20% corruption rate for a series whose returns were spotless.
    """
    frame = _clean_frame(n=200, seed=3)
    original_close = frame["close"].to_numpy(dtype=float).copy()

    # Corrupt the wicks of 30 bars, leaving open/close untouched.
    bad_idx = np.arange(20, 50)
    frame.loc[bad_idx, "high"] = frame.loc[bad_idx, "close"] * 3.0
    frame.loc[bad_idx, "low"] = frame.loc[bad_idx, "close"] * 0.2

    cleaned, report = clean_ohlcv(frame, symbol="WICKS", expected_ms=HOUR_MS)

    # The close path must survive byte-for-byte: these are real observations.
    np.testing.assert_allclose(cleaned["close"].to_numpy(dtype=float), original_close)

    assert report.wick_repairs == len(bad_idx)
    assert report.repaired == 0, "no bar had a corrupt close, so none should be discarded"
    assert report.bad_fraction == 0.0
    assert report.wick_fraction == pytest.approx(len(bad_idx) / len(frame))
    assert not cleaned["is_bad"].any()

    # And the repaired bars are physically possible again.
    assert (cleaned["high"] >= np.maximum(cleaned["open"], cleaned["close"])).all()
    assert (cleaned["low"] <= np.minimum(cleaned["open"], cleaned["close"])).all()


def test_wick_clamping_bounds_the_span_to_something_plausible() -> None:
    frame = _clean_frame(n=200, seed=4)
    idx = 100
    frame.loc[idx, "high"] = frame.loc[idx, "close"] * 50.0
    frame.loc[idx, "low"] = frame.loc[idx, "close"] * 0.02

    cleaned, _ = clean_ohlcv(frame, symbol="SPAN", expected_ms=HOUR_MS)

    original_span = ((frame["high"] - frame["low"]) / frame["close"]).median()
    fixed_span = (cleaned.loc[idx, "high"] - cleaned.loc[idx, "low"]) / cleaned.loc[idx, "close"]
    assert fixed_span < original_span * 20, "the clamped span must return to a sane range"


def test_clean_close_path_is_preserved_exactly_for_untouched_bars() -> None:
    """Bars that are fine must pass through the validator unchanged."""
    frame = _clean_frame(n=150, seed=5)
    cleaned, report = clean_ohlcv(frame, symbol="PRISTINE", expected_ms=HOUR_MS)

    assert report.repaired == 0
    assert report.wick_repairs == 0
    for col in ("open", "high", "low", "close", "volume"):
        np.testing.assert_allclose(
            cleaned[col].to_numpy(dtype=float), frame[col].to_numpy(dtype=float)
        )


def test_close_spike_with_a_normal_wick_is_still_a_discarded_bar() -> None:
    """The distinction must not become a loophole: a bad close is still fatal to the bar."""
    frame = _clean_frame(n=120, seed=6)
    idx = 60
    # A close an order of magnitude away, with an internally consistent body.
    frame.loc[idx, ["open", "high", "low", "close"]] = [1000.0, 1000.0, 1000.0, 1000.0]

    cleaned, report = clean_ohlcv(frame, symbol="SPIKE", expected_ms=HOUR_MS)

    assert report.repaired == 1
    assert bool(cleaned["is_bad"].iloc[idx])
    assert cleaned["close"].iloc[idx] != 1000.0
    assert cleaned["volume"].iloc[idx] == 0.0


def test_wick_repair_is_idempotent() -> None:
    """Cleaning clean data must be a no-op, or every reload would rewrite history."""
    frame = _clean_frame(n=200, seed=7)
    frame.loc[30:60, "high"] = frame.loc[30:60, "close"] * 4.0

    once, first = clean_ohlcv(frame, symbol="IDEM", expected_ms=HOUR_MS)
    twice, second = clean_ohlcv(once.drop(columns=["is_bad"]), symbol="IDEM", expected_ms=HOUR_MS)

    assert first.wick_repairs > 0
    assert second.repaired == 0
    assert second.wick_repairs == 0
    np.testing.assert_allclose(
        once["high"].to_numpy(dtype=float), twice["high"].to_numpy(dtype=float)
    )
