"""Tests for alpha.features.indicators.

Every case is hand-computable and offline. The assertions describe what the
implementation really does, not what a textbook "should" do: where the two
differ (the EMA warm-up seed is the clearest example) the test says so in a
comment rather than silently encoding a wrong expectation.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from alpha.features.indicators import (
    adx,
    atr,
    bars_per_year,
    donchian,
    efficiency_ratio,
    ema,
    parkinson_vol,
    realized_vol,
    true_range,
    zscore,
)


# --------------------------------------------------------------------------- ema
def test_ema_is_nan_until_warmup_then_matches_recursive_formula() -> None:
    series = pd.Series(np.arange(1.0, 21.0))
    span = 5
    result = ema(series, span)
    alpha = 2.0 / (span + 1)

    # min_periods=span masks the first span-1 outputs.
    assert result.iloc[: span - 1].isna().all()
    assert result.iloc[span - 1 :].notna().all()

    # pandas ewm(adjust=False) seeds y_0 = x_0 and runs the recursion from the
    # very first point; min_periods only *hides* the warm-up. Rebuild it by hand.
    recursive = [float(series.iloc[0])]
    for x in series.iloc[1:]:
        recursive.append(alpha * float(x) + (1.0 - alpha) * recursive[-1])
    recursive_arr = np.asarray(recursive)

    assert np.allclose(result.iloc[span - 1 :].to_numpy(), recursive_arr[span - 1 :])

    # The first *visible* value is NOT the simple mean of the first `span`
    # points, which is the naive expectation. It is the recursive value seeded
    # at x_0. Assert the true behaviour explicitly.
    first_visible = result.iloc[span - 1]
    assert not np.isclose(first_visible, series.iloc[:span].mean())
    assert np.isclose(first_visible, recursive_arr[span - 1])


def test_ema_of_constant_series_is_the_constant() -> None:
    series = pd.Series([7.5] * 12)
    result = ema(series, 4)
    assert np.allclose(result.dropna().to_numpy(), 7.5)


# --------------------------------------------------------------------------- atr
def test_true_range_hand_computed_including_a_gap() -> None:
    high = pd.Series([10.0, 12.0, 15.0, 20.0])
    low = pd.Series([8.0, 9.0, 10.0, 19.5])
    close = pd.Series([9.0, 11.0, 11.0, 19.8])

    tr = true_range(high, low, close)

    # bar 0: no previous close -> high-low
    # bar 1: max(3, |12-9|, |9-9|) = 3
    # bar 2: max(5, |15-11|, |10-11|) = 5
    # bar 3 (gap up): max(0.5, |20-11|, |19.5-11|) = 9
    assert tr.tolist() == pytest.approx([2.0, 3.0, 5.0, 9.0])


def test_atr_is_positive_and_converges_to_constant_range() -> None:
    n = 60
    constant_range = 2.0
    low = pd.Series([100.0] * n)
    high = low + constant_range
    close = low + constant_range / 2.0

    result = atr(high, low, close, period=14)

    assert result.iloc[:13].isna().all()
    assert (result.dropna() > 0).all()
    # TR is constant (high-low is the max of the three candidates), and an
    # exponential mean of a constant is that constant.
    assert result.iloc[-1] == pytest.approx(constant_range)

    rng = np.random.default_rng(0)
    noisy_close = pd.Series(100.0 + np.cumsum(rng.normal(0.0, 1.0, n)))
    noisy_high = noisy_close + rng.uniform(0.1, 2.0, n)
    noisy_low = noisy_close - rng.uniform(0.1, 2.0, n)
    noisy_atr = atr(noisy_high, noisy_low, noisy_close, period=14)
    assert (noisy_atr.dropna() > 0).all()


# ----------------------------------------------------------------------- donchian
def test_donchian_upper_lower_match_brute_force_over_previous_bars() -> None:
    rng = np.random.default_rng(1)
    n = 80
    lookback = 12
    high = pd.Series(rng.uniform(50.0, 150.0, n))
    low = high - rng.uniform(0.1, 3.0, n)

    upper, lower = donchian(high, low, lookback)

    assert upper.iloc[:lookback].isna().all()
    assert lower.iloc[:lookback].isna().all()

    for t in (lookback, 20, 41, 63, n - 1):
        # The channel at bar t is the max/min over [t-lookback, t-1].
        assert upper.iloc[t] == pytest.approx(high.iloc[t - lookback : t].max())
        assert lower.iloc[t] == pytest.approx(low.iloc[t - lookback : t].min())


def test_donchian_never_includes_the_current_bar() -> None:
    high = pd.Series(np.arange(10.0, 21.0))
    low = high - 1.0
    lookback = 3

    baseline_upper, baseline_lower = donchian(high, low, lookback)

    spiked_high = high.copy()
    spiked_high.iloc[7] = 1000.0
    spiked_low = low.copy()
    spiked_low.iloc[7] = -1000.0
    spiked_upper, spiked_lower = donchian(spiked_high, spiked_low, lookback)

    # Bar 7's own extreme must not leak into its channel ...
    assert spiked_upper.iloc[7] == pytest.approx(baseline_upper.iloc[7])
    assert spiked_lower.iloc[7] == pytest.approx(baseline_lower.iloc[7])
    # ... but it must show up on the very next bar.
    assert spiked_upper.iloc[8] == pytest.approx(1000.0)
    assert spiked_lower.iloc[8] == pytest.approx(-1000.0)


# ------------------------------------------------------------------------- zscore
def test_zscore_of_constant_window_is_nan_not_inf_or_zero() -> None:
    constant = pd.Series([5.0] * 10)
    result = zscore(constant, 5)
    assert result.isna().all()
    assert not np.isinf(result.to_numpy(dtype=float)).any()


def test_zscore_standardises_the_window() -> None:
    rng = np.random.default_rng(2)
    series = pd.Series(rng.normal(0.0, 1.0, 50))
    lookback = 20
    result = zscore(series, lookback)

    t = len(series) - 1
    window = series.iloc[t - lookback + 1 : t + 1]
    standardised = (window - window.mean()) / window.std(ddof=0)

    # By construction the standardised window has mean 0 and population std 1,
    # and the zscore value at t is its last element.
    assert abs(standardised.mean()) < 1e-12
    assert abs(standardised.std(ddof=0) - 1.0) < 1e-12
    assert result.iloc[t] == pytest.approx(standardised.iloc[-1])


# ---------------------------------------------------------------------------- adx
def test_adx_stays_bounded_and_prefers_trend_over_chop() -> None:
    n = 80
    trend_close = pd.Series(np.arange(100.0, 100.0 + n))
    trend = adx(trend_close + 1.0, trend_close - 1.0, trend_close, 14).dropna()

    zigzag_close = pd.Series(100.0 + np.tile([0.0, 1.0, 0.0, -1.0], n // 4))
    chop = adx(zigzag_close + 1.0, zigzag_close - 1.0, zigzag_close, 14).dropna()

    for values in (trend, chop):
        assert len(values) > 0
        assert (values >= 0.0).all()
        assert (values <= 100.0).all()

    assert trend.mean() > 50.0
    assert chop.mean() < 50.0
    assert trend.mean() > chop.mean()


# -------------------------------------------------------------- efficiency ratio
def test_efficiency_ratio_is_one_for_a_line_and_zero_for_a_round_trip() -> None:
    line = pd.Series(np.arange(100.0))
    er_line = efficiency_ratio(line, 10).dropna()
    assert len(er_line) > 0
    assert np.allclose(er_line.to_numpy(), 1.0)

    period = 4
    zigzag = pd.Series(100.0 + np.tile([0.0, 1.0, 0.0, -1.0], 25))
    er_zig = efficiency_ratio(zigzag, period).dropna()
    # net move over the window is exactly zero; the path length is not.
    assert len(er_zig) > 0
    assert np.allclose(er_zig.to_numpy(), 0.0)


# ----------------------------------------------------------- volatility estimators
def test_vol_estimators_nan_in_warmup_then_finite_positive() -> None:
    rng = np.random.default_rng(3)
    n = 120
    lookback = 20
    ret = rng.normal(0.0, 0.01, n)
    close = pd.Series(100.0 * np.exp(np.cumsum(ret)))
    high = close * np.exp(0.01)
    low = close * np.exp(-0.01)

    rv = realized_vol(close, lookback, 365.0)
    pv = parkinson_vol(high, low, lookback, 365.0)

    # min_periods = max(10, lookback // 4) = 10.
    assert rv.iloc[:10].isna().all()
    assert pv.iloc[:9].isna().all()  # hl exists from bar 0, so one bar earlier
    assert rv.iloc[15:].notna().all()
    assert pv.iloc[15:].notna().all()
    assert (rv.iloc[15:] > 0).all()
    assert (pv.iloc[15:] > 0).all()


def test_parkinson_vol_reacts_faster_than_realized_vol_to_intraday_stress() -> None:
    """A regime change in the *intraday range* while the close path stays calm.

    The close-to-close estimator barely notices (returns are unchanged); the
    high/low estimator jumps immediately, which is the documented reason it is
    used for sizing.
    """
    rng = np.random.default_rng(7)
    n = 80
    calm_close = pd.Series(100.0 * np.exp(np.cumsum(rng.normal(0.0, 0.0005, n))))

    half_range = np.full(n, 0.0005)
    half_range[40:] = 0.03  # intraday range widens 60x at bar 40
    high = calm_close * np.exp(half_range)
    low = calm_close * np.exp(-half_range)

    rv = realized_vol(calm_close, 20, 365.0)
    pv = parkinson_vol(high, low, 20, 365.0)

    jump_pv = pv.iloc[45] / pv.iloc[35]
    jump_rv = rv.iloc[45] / rv.iloc[35]

    assert pv.iloc[40] > 5.0 * pv.iloc[39]
    assert abs(rv.iloc[40] / rv.iloc[39] - 1.0) < 0.5
    assert jump_pv > 5.0 * max(jump_rv, 1.0)
    assert pv.iloc[45] > rv.iloc[45]


# ------------------------------------------------------------------- bars_per_year
def test_bars_per_year_known_mapping_and_default() -> None:
    assert bars_per_year("1") == 365 * 24 * 60
    assert bars_per_year("5") == 365 * 24 * 12
    assert bars_per_year("60") == 365 * 24
    assert bars_per_year("240") == 365 * 6
    assert bars_per_year("D") == 365

    # Unknown intervals fall back to hourly (8760), not zero or a crash.
    assert bars_per_year("not-an-interval") == 365 * 24
    assert bars_per_year("") == 365 * 24
