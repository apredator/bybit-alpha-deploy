"""Vectorised indicators.

Two rules apply to every function here, and they are what separate a backtest
you can trust from one that flatters you:

1. **No lookahead.** An indicator value at bar ``t`` may only use data up to and
   including the close of bar ``t``. Channels and breakouts additionally use
   ``.shift(1)`` so that "the highest high of the last N bars" never contains the
   bar being traded.
2. **No silent NaN filling.** Warm-up NaNs propagate; the backtester skips them
   explicitly instead of pretending the strategy was flat-but-informed.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

# Crypto trades 24/7/365.
BARS_PER_YEAR = {
    "1": 365 * 24 * 60,
    "3": 365 * 24 * 20,
    "5": 365 * 24 * 12,
    "15": 365 * 24 * 4,
    "30": 365 * 24 * 2,
    "60": 365 * 24,
    "120": 365 * 12,
    "240": 365 * 6,
    "360": 365 * 4,
    "720": 365 * 2,
    "D": 365,
}


def bars_per_year(interval: str) -> float:
    return float(BARS_PER_YEAR.get(interval, 365 * 24))


def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False, min_periods=span).mean()


def sma(series: pd.Series, window: int) -> pd.Series:
    return series.rolling(window, min_periods=window).mean()


def true_range(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    prev_close = close.shift(1)
    return pd.concat(
        [(high - low), (high - prev_close).abs(), (low - prev_close).abs()], axis=1
    ).max(axis=1)


def atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    """Wilder's ATR (smoothed true range)."""
    tr = true_range(high, low, close)
    return tr.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0.0)
    loss = (-delta).clip(lower=0.0)
    avg_gain = gain.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0.0, np.nan)
    out = 100.0 - (100.0 / (1.0 + rs))
    return out.where(avg_loss != 0.0, 100.0)


def donchian(high: pd.Series, low: pd.Series, lookback: int) -> tuple[pd.Series, pd.Series]:
    """Breakout channel built from **previous** bars only (shifted by one)."""
    upper = high.rolling(lookback, min_periods=lookback).max().shift(1)
    lower = low.rolling(lookback, min_periods=lookback).min().shift(1)
    return upper, lower


def zscore(series: pd.Series, lookback: int) -> pd.Series:
    mean = series.rolling(lookback, min_periods=lookback).mean()
    std = series.rolling(lookback, min_periods=lookback).std(ddof=0)
    return (series - mean) / std.replace(0.0, np.nan)


def realized_vol(close: pd.Series, lookback: int, ann: float) -> pd.Series:
    """Close-to-close annualised volatility of log returns."""
    log_ret = np.log(close / close.shift(1))
    return log_ret.rolling(lookback, min_periods=max(10, lookback // 4)).std(ddof=0) * np.sqrt(ann)


def parkinson_vol(high: pd.Series, low: pd.Series, lookback: int, ann: float) -> pd.Series:
    """High/low range estimator — ~5x more efficient than close-to-close, and it
    reacts faster to intraday stress, which is exactly when sizing matters."""
    hl = np.log(high / low.replace(0.0, np.nan)) ** 2
    factor = 1.0 / (4.0 * np.log(2.0))
    return np.sqrt(hl.rolling(lookback, min_periods=max(10, lookback // 4)).mean() * factor * ann)


def adx(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    """Average Directional Index — the regime filter (trending vs chopping)."""
    up_move = high.diff()
    down_move = -low.diff()
    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)

    tr = true_range(high, low, close)
    atr_s = tr.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    plus_di = 100.0 * pd.Series(plus_dm, index=high.index).ewm(
        alpha=1.0 / period, adjust=False, min_periods=period
    ).mean() / atr_s.replace(0.0, np.nan)
    minus_di = 100.0 * pd.Series(minus_dm, index=high.index).ewm(
        alpha=1.0 / period, adjust=False, min_periods=period
    ).mean() / atr_s.replace(0.0, np.nan)
    dx = 100.0 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0.0, np.nan)
    return dx.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()


def efficiency_ratio(close: pd.Series, lookback: int) -> pd.Series:
    """Kaufman efficiency ratio: |net move| / sum(|moves|).

    ~1 means a clean trend, ~0 means chop. Cheap and very interpretable.
    """
    net = (close - close.shift(lookback)).abs()
    path = close.diff().abs().rolling(lookback, min_periods=lookback).sum()
    return net / path.replace(0.0, np.nan)


def rolling_slope(series: pd.Series, lookback: int) -> pd.Series:
    """Normalised OLS slope over `lookback` bars, in % of price per bar."""
    x = np.arange(lookback, dtype=float)
    x_mean = x.mean()
    x_var = ((x - x_mean) ** 2).sum()

    def _slope(window: np.ndarray) -> float:
        y = window
        if np.isnan(y).any():
            return np.nan
        return float(((x - x_mean) * (y - y.mean())).sum() / x_var)

    slope = series.rolling(lookback, min_periods=lookback).apply(_slope, raw=True)
    return slope / series.replace(0.0, np.nan)


def rolling_corr(a: pd.Series, b: pd.Series, lookback: int) -> pd.Series:
    return a.rolling(lookback, min_periods=lookback).corr(b)


def relative_strength(close: pd.Series, benchmark: pd.Series, lookback: int) -> pd.Series:
    """Momentum of `close` minus momentum of `benchmark` (cross-sectional alpha)."""
    return np.log(close / close.shift(lookback)) - np.log(benchmark / benchmark.shift(lookback))


def supertrend_direction(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 10, mult: float = 3.0) -> pd.Series:
    """Supertrend direction (+1 long / -1 short). A robust stop-and-reverse filter."""
    atr_s = atr(high, low, close, period).bfill()
    hl2 = (high + low) / 2.0
    upper = (hl2 + mult * atr_s).to_numpy()
    lower = (hl2 - mult * atr_s).to_numpy()
    close_a = close.to_numpy()
    n = len(close_a)
    final_upper = np.full(n, np.nan)
    final_lower = np.full(n, np.nan)
    direction = np.ones(n)

    for i in range(1, n):
        if np.isnan(upper[i]) or np.isnan(lower[i]):
            direction[i] = direction[i - 1]
            continue
        final_upper[i] = min(upper[i], final_upper[i - 1]) if close_a[i - 1] <= (final_upper[i - 1] if not np.isnan(final_upper[i - 1]) else upper[i]) else upper[i]
        final_lower[i] = max(lower[i], final_lower[i - 1]) if close_a[i - 1] >= (final_lower[i - 1] if not np.isnan(final_lower[i - 1]) else lower[i]) else lower[i]
        if close_a[i] > (final_upper[i] if not np.isnan(final_upper[i]) else upper[i]):
            direction[i] = 1
        elif close_a[i] < (final_lower[i] if not np.isnan(final_lower[i]) else lower[i]):
            direction[i] = -1
        else:
            direction[i] = direction[i - 1]
    return pd.Series(direction, index=close.index, name="supertrend_dir")
