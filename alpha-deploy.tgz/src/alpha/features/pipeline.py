"""Feature pipeline: raw OHLCV (+ funding) -> a per-symbol feature frame.

Every column added here is causal: it is computable at the close of the bar it
is stamped on. The backtester then executes on the *next* bar, so there is no
path from future information into a fill.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from alpha.data.loader import INTERVAL_MS
from alpha.features.indicators import (
    adx,
    atr,
    bars_per_year,
    donchian,
    efficiency_ratio,
    ema,
    parkinson_vol,
    realized_vol,
    rolling_slope,
    rsi,
    zscore,
)


def build_features(
    ohlcv: pd.DataFrame,
    *,
    interval: str = "60",
    funding: pd.DataFrame | None = None,
    params: dict | None = None,
) -> pd.DataFrame:
    """Attach the full feature set to a copy of `ohlcv`.

    Parameters come from `strategy.params` so research and live share one source
    of truth — the classic bug is a live bot with different lookbacks than the
    backtest that justified it.
    """
    p = dict(params or {})
    fast = int(p.get("trend_fast", 48))
    slow = int(p.get("trend_slow", 200))
    breakout = int(p.get("breakout_lookback", 96))
    atr_len = int(p.get("atr_lookback", 48))
    mr_len = int(p.get("mr_lookback", 96))
    regime_len = int(p.get("regime_lookback", 200))
    carry_len = int(p.get("carry_lookback", 21))

    ann = bars_per_year(interval)
    df = ohlcv.copy().sort_values("ts").reset_index(drop=True)

    close, high, low = df["close"], df["high"], df["low"]

    df["ret"] = np.log(close / close.shift(1))
    df["atr"] = atr(high, low, close, atr_len)
    df["atr_pct"] = df["atr"] / close

    # Two independent volatility estimates, and the risk layer uses the LARGER.
    #
    # Parkinson (high/low range) is statistically efficient but it is only as good
    # as the high and low it is built from — and on a real feed the wicks are the
    # least trustworthy field, which we measured directly (one symbol arrived with
    # ~19% of its ranges corrupt). Close-to-close volatility ignores wicks entirely
    # and cannot be inflated or deflated by them.
    #
    # Taking the maximum is the conservative choice and it costs almost nothing:
    # when both are healthy they agree, and when one is broken the other keeps the
    # sizer honest. Trusting the efficient estimator alone means a bad wick can
    # silently mis-size the whole book.
    vol_window = max(regime_len // 2, 24)
    df["vol_parkinson"] = parkinson_vol(high, low, vol_window, ann)
    df["vol_cc"] = realized_vol(close, vol_window, ann)
    df["vol"] = np.fmax(df["vol_parkinson"], df["vol_cc"])

    df["ema_fast"] = ema(close, fast)
    df["ema_slow"] = ema(close, slow)
    df["ema_spread"] = (df["ema_fast"] - df["ema_slow"]) / close
    df["ema_slope"] = rolling_slope(df["ema_slow"], max(fast, 24))

    df["dc_upper"], df["dc_lower"] = donchian(high, low, breakout)
    df["breakout_pos"] = np.where(
        close > df["dc_upper"], 1.0, np.where(close < df["dc_lower"], -1.0, 0.0)
    )
    # How far through the channel we are, in [-1, 1].
    channel = (df["dc_upper"] - df["dc_lower"]).replace(0.0, np.nan)
    df["dc_position"] = (2.0 * (close - df["dc_lower"]) / channel - 1.0).clip(-1.0, 1.0)

    df["zscore"] = zscore(close, mr_len)
    df["rsi"] = rsi(close, max(mr_len // 4, 14))
    df["adx"] = adx(high, low, close, max(regime_len // 10, 14))
    df["er"] = efficiency_ratio(close, regime_len)
    df["trend_ma"] = ema(close, regime_len)

    # --- funding ---------------------------------------------------------
    # Bybit does NOT settle funding every 8h on every symbol: BTC is 8h, ETH is
    # usually 2h, SOL is usually 1h, and the schedule is not guaranteed. A hard
    # coded "every 8h" assumption silently understates the funding cost of the
    # fastest-settling symbols, so instead we attribute every settlement to the
    # bar it falls into, exactly, using a cumulative sum.
    bar_ms = INTERVAL_MS.get(interval, 3_600_000)
    if funding is not None and not funding.empty:
        fts = np.asarray(sorted(funding["ts"].unique()), dtype=np.int64)
        frates = (
            funding.drop_duplicates("ts").sort_values("ts")["funding_rate"].to_numpy(dtype=float)
        )
        cum = np.concatenate([[0.0], np.cumsum(frates)])
        bar_ts = df["ts"].to_numpy(dtype=np.int64)
        hi = np.searchsorted(fts, bar_ts, side="right")
        lo = np.searchsorted(fts, bar_ts - bar_ms, side="right")
        df["funding_rate"] = cum[hi] - cum[lo]  # sum of settlements inside this bar
    else:
        df["funding_rate"] = 0.0

    bars_per_day = 86_400_000.0 / bar_ms
    settle_per_day = float((df["funding_rate"] != 0.0).sum()) / max(len(df), 1) * bars_per_day
    settle_per_day = settle_per_day if settle_per_day > 0 else 3.0
    funding_ma = df["funding_rate"].rolling(carry_len, min_periods=max(3, carry_len // 3)).mean()
    # Per-bar mean rate * settlements per day * 365 -> annualised funding yield.
    df["funding_ma"] = funding_ma / max(bars_per_day / settle_per_day, 1.0)
    df["funding_annual"] = df["funding_ma"] * settle_per_day * 365.0
    df["funding_cum_30d"] = df["funding_rate"].rolling(int(30 * bars_per_day), min_periods=10).sum()

    # A single interpretable "trend on / trend off" gate in [0, 1]:
    # ADX above threshold AND a clean price path (efficiency ratio high).
    adx_thr = float(p.get("adx_threshold", 22.0))
    df["trend_regime"] = (
        (df["adx"].fillna(0.0) > adx_thr).astype(float) * 0.5
        + df["er"].fillna(0.0).clip(0.0, 1.0) * 0.5
    ).clip(0.0, 1.0)
    df["chop_regime"] = 1.0 - df["trend_regime"]

    df["bar_index"] = np.arange(len(df), dtype=np.int64)
    return df


def feature_columns() -> list[str]:
    return [
        "ret", "atr", "atr_pct", "vol", "vol_parkinson", "vol_cc",
        "ema_fast", "ema_slow", "ema_spread",
        "ema_slope", "dc_upper", "dc_lower", "breakout_pos", "dc_position", "zscore",
        "rsi", "adx", "er", "trend_ma", "funding_rate", "funding_ma", "funding_annual",
        "funding_cum_30d", "trend_regime", "chop_regime",
    ]
