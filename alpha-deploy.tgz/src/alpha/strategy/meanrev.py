"""Mean-reversion sleeve: fade stretched moves, but only in a ranging regime.

Short-horizon reversal is the complement of trend following: it earns a steady
drip in chop and gets run over in a breakout. Hence the hard `chop_regime` gate
and the hysteresis band (enter at |z| > entry, exit only at |z| < exit) — without
hysteresis the position churns and fees eat the whole edge.

The loop is explicit rather than vectorised because hysteresis is stateful; a
`for` over a few hundred thousand bars is ~milliseconds and keeps the logic
auditable, which matters more here than saving 40 ms.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from alpha.strategy.base import Strategy


class MeanReversion(Strategy):
    name = "meanrev"

    def generate(self, features: pd.DataFrame) -> pd.Series:
        entry_z = float(self.params.get("mr_entry_z", 1.6))
        exit_z = float(self.params.get("mr_exit_z", 0.35))
        max_hold = int(self.params.get("mr_max_hold", 48))

        z = features["zscore"].to_numpy(dtype=float)
        chop = features["chop_regime"].to_numpy(dtype=float)
        atr_pct = features["atr_pct"].to_numpy(dtype=float)
        rsi = features["rsi"].to_numpy(dtype=float)
        n = len(z)

        out = np.zeros(n, dtype=float)
        pos = 0.0
        held = 0
        for i in range(n):
            zi = z[i]
            if not np.isfinite(zi):
                out[i] = 0.0
                continue

            if pos == 0.0:
                if zi <= -entry_z and chop[i] > 0.5:
                    # Oversold in a range -> buy the dip. RSI confirms we are not
                    # catching a genuine breakdown.
                    pos = min(1.0, (abs(zi) - entry_z) / entry_z + 0.5) * (1.0 if rsi[i] < 55 else 0.4)
                    held = 0
                elif zi >= entry_z and chop[i] > 0.5:
                    pos = -min(1.0, (abs(zi) - entry_z) / entry_z + 0.5) * (1.0 if rsi[i] > 45 else 0.4)
                    held = 0
            else:
                held += 1
                # Time stop: if the stretch has not resolved, the regime changed.
                if abs(zi) < exit_z or held > max_hold or chop[i] < 0.35:
                    pos = 0.0

            out[i] = pos

        # Risk-normalise: a mean-reversion position in a high-vol symbol is far
        # riskier than the same weight in a calm one.
        scale = np.clip(0.02 / np.where(np.isfinite(atr_pct) & (atr_pct > 0), atr_pct, 0.02), 0.25, 1.5)
        return self._clean(pd.Series(out * scale, index=features.index))
