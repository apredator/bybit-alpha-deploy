"""Funding-carry sleeve: get paid the perpetual swap's funding rate.

The clean, delta-neutral version of this trade hedges the perp with spot (or
with a dated future) and pockets funding with no price risk. This sleeve runs on
perps alone, so it is **directional by construction** — it takes the side that
receives funding and accepts the price risk that comes with it.

That is a genuinely weaker trade, so the sleeve is constrained on three axes:
  * only act on extreme funding (rolling quantile + absolute floor),
  * never fight a strong opposing trend,
  * scale with conviction instead of taking a full unit.

Being explicit about this limitation is the point: a carry sleeve sold as "free
yield" is how desks blow up. On a real book, enable `hedge_with_spot` and treat
this as the funding leg of a basis trade.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from alpha.strategy.base import Strategy


class FundingCarry(Strategy):
    name = "carry"

    def generate(self, features: pd.DataFrame) -> pd.Series:
        f = features
        min_annual = float(self.params.get("carry_min_annual", 0.05))
        quantile = float(self.params.get("carry_quantile", 0.80))
        lookback = int(self.params.get("carry_quantile_lookback", 720))

        funding = f["funding_annual"].fillna(0.0)

        # Adaptive threshold: "extreme" relative to this symbol's own recent regime.
        rolling_thr = funding.abs().rolling(lookback, min_periods=lookback // 5).quantile(quantile)
        threshold = np.maximum(rolling_thr.fillna(min_annual), min_annual)

        # Positive funding -> longs pay shorts -> we want to be short.
        direction = -np.sign(funding)
        conviction = ((funding.abs() / threshold.replace(0.0, np.nan)) - 1.0).clip(0.0, 1.0)
        signal = direction * (0.25 + 0.75 * conviction.fillna(0.0))

        # Trend veto: do not short a market that is ripping, however juicy the
        # funding looks. This alone removes the worst tail of the strategy.
        slope = f["ema_slope"].fillna(0.0)
        against = np.sign(slope) * np.sign(signal) < 0
        signal = signal.where(~against, signal * 0.2)

        return self._clean(signal)
