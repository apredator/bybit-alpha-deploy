"""Strategy interface.

A strategy answers exactly one question: *what fraction of equity do I want in
this symbol right now, and with which sign?* It never decides leverage, never
decides contract counts, and never touches an exchange. That separation is what
makes the risk layer able to override any strategy at any moment.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import numpy as np
import pandas as pd


class Strategy(ABC):
    name: str = "base"

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        self.params = dict(params or {})

    @abstractmethod
    def generate(self, features: pd.DataFrame) -> pd.Series:
        """Return a target-weight series in [-1, 1], same index as `features`."""

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.name})"

    @staticmethod
    def _clean(signal: pd.Series) -> pd.Series:
        """Clip to [-1, 1] and treat warm-up as flat rather than as a NaN trade."""
        return pd.Series(
            np.nan_to_num(signal.to_numpy(dtype=float), nan=0.0, posinf=0.0, neginf=0.0),
            index=signal.index,
            name="signal",
        ).clip(-1.0, 1.0)


def build_strategy(name: str, params: dict[str, Any] | None = None) -> Strategy:
    """Factory — the only place that maps a config string to a class."""
    params = params or {}
    registry: dict[str, type[Strategy]] = {}
    from alpha.strategy.carry import FundingCarry
    from alpha.strategy.ensemble import RegimeEnsemble
    from alpha.strategy.meanrev import MeanReversion
    from alpha.strategy.trend import TrendFollowing

    registry = {
        "trend": TrendFollowing,
        "meanrev": MeanReversion,
        "carry": FundingCarry,
        "ensemble": RegimeEnsemble,
    }
    key = name.lower()
    if key not in registry:
        raise ValueError(f"unknown strategy '{name}'. Available: {sorted(registry)}")
    return registry[key](params)
