"""Trend-following sleeve: trade with the prevailing drift, size by conviction.

Why this is the backbone of any systematic crypto book: time-series momentum is
one of the few anomalies that has survived decades and dozens of markets, and it
is *long convexity* — many small losses, few large wins. Its known weakness is
whipsaw in ranging markets, which is exactly what `trend_regime` gates out.

Deliberately capped at a single directional unit; leverage comes from the risk
layer's vol targeting, not from this file.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from alpha.strategy.base import Strategy


class TrendFollowing(Strategy):
    name = "trend"

    def generate(self, features: pd.DataFrame) -> pd.Series:
        f = features
        # Standardise the fast/slow EMA spread by volatility so a "strong" signal
        # means the same thing in calm and in violent markets.
        denom = (f["atr_pct"] * 2.0).replace(0.0, np.nan)
        momentum = np.tanh((f["ema_spread"] / denom).fillna(0.0))

        # Breakout confirmation: only add conviction when price is actually making
        # new extremes, not merely above a moving average.
        breakout = f["breakout_pos"].fillna(0.0)

        raw = 0.65 * momentum + 0.35 * breakout

        # Gate: no trend trades in chop (low ADX / low efficiency ratio).
        gate = f["trend_regime"].fillna(0.0)
        signal = raw * (0.35 + 0.65 * gate)

        # Never fight a sharply falling long-term slope with a long, or vice versa.
        slope = f["ema_slope"].fillna(0.0)
        veto = np.sign(slope) * np.sign(signal)
        signal = signal.where(veto >= 0, signal * 0.25)

        return self._clean(signal)
