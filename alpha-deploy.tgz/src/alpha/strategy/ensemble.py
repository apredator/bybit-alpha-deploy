"""Regime ensemble: blend the sleeves with weights that depend on the regime.

Two separate ideas live here, and they are easy to confuse:

1. **Blend** — a static weighted sum of the sleeves. Diversification across
   uncorrelated-ish return streams is the closest thing to a free lunch in this
   business.
2. **Regime switch** — the *effective* weight of each sleeve moves with the
   measured regime. Trend following and mean reversion are mirror images of each
   other (trend wants persistence, MR wants reversal); running both at full size
   all the time means paying fees for them to cancel out.

That second point is the difference between a 0.6 Sharpe book and a 1.2 Sharpe
book, so it is implemented explicitly rather than left to chance.
"""

from __future__ import annotations

import pandas as pd

from alpha.strategy.base import Strategy, build_strategy

DEFAULT_WEIGHTS = {"trend": 1.0, "meanrev": 0.7, "carry": 0.5}
#: How strongly the regime tilts the book. 1.0 = full tilt, 0.0 = static blend.
DEFAULT_TILT = 1.0


class RegimeEnsemble(Strategy):
    name = "ensemble"

    def __init__(self, params: dict | None = None) -> None:
        super().__init__(params)
        weights = self.params.get("sleeve_weights") or DEFAULT_WEIGHTS
        self.sleeve_weights: dict[str, float] = {k: float(v) for k, v in weights.items()}
        self.tilt = float(self.params.get("regime_tilt", DEFAULT_TILT))
        self.sleeves: dict[str, Strategy] = {
            key: build_strategy(key, self.params) for key in self.sleeve_weights
        }

    def generate(self, features: pd.DataFrame) -> pd.Series:
        if not self.sleeves:
            return self._clean(pd.Series(0.0, index=features.index))

        trend_w = features["trend_regime"].fillna(0.5)
        chop_w = 1.0 - trend_w

        # Trend sleeve scales up when the market trends; MR does the opposite.
        # Carry is regime-agnostic (it is paid by funding, not by price action).
        regime_multiplier = {
            "trend": 1.0 + self.tilt * (trend_w - 0.5) * 2.0,
            "meanrev": 1.0 + self.tilt * (chop_w - 0.5) * 2.0,
            "carry": pd.Series(1.0, index=features.index),
        }

        total_w = sum(self.sleeve_weights.values())
        if total_w <= 0:
            return self._clean(pd.Series(0.0, index=features.index))

        acc = pd.Series(0.0, index=features.index)
        for key, sleeve in self.sleeves.items():
            raw = sleeve.generate(features)
            mult = regime_multiplier.get(key, pd.Series(1.0, index=features.index))
            acc = acc + self.sleeve_weights[key] * raw * mult

        return self._clean(acc / total_w)

    def sleeve_signals(self, features: pd.DataFrame) -> pd.DataFrame:
        """Per-sleeve signals — used by research to attribute P&L honestly."""
        return pd.DataFrame({k: s.generate(features) for k, s in self.sleeves.items()})
