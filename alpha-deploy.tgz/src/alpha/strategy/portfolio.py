"""Portfolio layer: turn per-symbol signals into a cross-sectional weight matrix.

Running the same strategy on five correlated majors and equal-weighting them does
not give you five bets — it gives you one oversized beta bet. Two adjustments fix
most of that:

* **Cross-sectional demeaning** (optional): subtract the cross-sectional average
  signal, which removes the common "everything is long crypto" factor and leaves
  relative-value exposure. Most of a naive crypto book's risk is this one factor.
* **Inverse-vol scaling**: allocate risk, not notional. A 20%-vol alt and a 60%-vol
  alt should not receive the same weight.

The output is a wide frame `[ts x symbol]` of target weights in [-1, 1], which is
exactly what the risk layer expects.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from alpha.features.pipeline import build_features
from alpha.strategy.base import Strategy, build_strategy


class PortfolioStrategy:
    def __init__(
        self,
        strategy: Strategy | None = None,
        *,
        params: dict | None = None,
        demean: bool = True,
        inverse_vol: bool = True,
        max_weight: float = 1.0,
    ) -> None:
        self.strategy = strategy or build_strategy((params or {}).get("name", "ensemble"), params)  # type: ignore[arg-type]
        self.params = dict(params or {})
        self.demean = demean
        self.inverse_vol = inverse_vol
        self.max_weight = max_weight

    def build_weight_matrix(
        self,
        panels: dict[str, pd.DataFrame],
        *,
        interval: str = "60",
        fundings: dict[str, pd.DataFrame] | None = None,
    ) -> tuple[pd.DataFrame, dict[str, pd.DataFrame]]:
        """Return `(weights[ts x symbol], features_by_symbol)`.

        Features are returned as well so research can attribute every trade back
        to the inputs that produced it — no black boxes in the audit trail.
        """
        fundings = fundings or {}
        raw: dict[str, pd.Series] = {}
        feats: dict[str, pd.DataFrame] = {}

        for symbol, ohlcv in panels.items():
            if ohlcv.empty:
                continue
            f = build_features(
                ohlcv, interval=interval, funding=fundings.get(symbol), params=self.params
            )
            feats[symbol] = f
            sig = self.strategy.generate(f)
            raw[symbol] = pd.Series(sig.to_numpy(), index=f["ts"].to_numpy(), name=symbol)

        if not raw:
            return pd.DataFrame(), feats

        matrix = pd.DataFrame(raw).sort_index()

        if self.inverse_vol:
            inv = {}
            for symbol, f in feats.items():
                vol = f.set_index("ts")["vol"].reindex(matrix.index).ffill()
                safe = vol.where(vol > 1e-6)
                # Cap the risk multiplier so a quiet period cannot create a huge position.
                inv[symbol] = (1.0 / safe).clip(upper=float(np.nanmedian(1.0 / safe)) * 3.0)
            inv_df = pd.DataFrame(inv).reindex(columns=matrix.columns)
            weight_scale = inv_df.div(inv_df.mean(axis=1).replace(0.0, np.nan), axis=0)
            weight_scale = weight_scale.clip(upper=2.0).fillna(1.0)
            matrix = matrix * weight_scale

        if self.demean:
            # Remove the common crypto factor: long BTC + long ETH + long SOL
            # becomes "long the strongest vs the weakest".
            matrix = matrix.sub(matrix.mean(axis=1), axis=0)

        matrix = matrix.clip(-self.max_weight, self.max_weight).fillna(0.0)

        # Poor man's gross control: if the book is bigger than 1 unit of gross per
        # symbol on average, scale the whole row down. Full sizing is the risk
        # layer's job; this just keeps the matrix in a sane range.
        gross = matrix.abs().sum(axis=1).replace(0.0, np.nan)
        scale = (len(matrix.columns) / gross).clip(upper=1.0).fillna(1.0)
        matrix = matrix.mul(scale, axis=0)

        return matrix, feats
