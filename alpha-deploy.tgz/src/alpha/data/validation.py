"""Market-data quality control.

Exchange REST snapshots are not clean. Real feeds contain, at a low but non-zero
rate: crossed candles (`high < low`), zero prices, duplicated timestamps, stale
prints repeated for hours, and full-blown spikes where a single bar prints a price
an order of magnitude away from its neighbours.

Why this file matters more than any strategy
--------------------------------------------
One bad bar with an absurd range destroys an ATR estimate for the next ~50 bars
(Wilder smoothing), which inflates volatility, which makes the vol-targeting
sizer shrink — or, worse, a fake *low* volatility estimate makes it lever up onto
the fake print. A single corrupt candle can silently turn a -5% year into a -80%
one, and nothing in the P&L tells you why.

The approach is deliberately conservative:
  * **Structural** checks catch the physically impossible (crossed, non-positive).
  * **Hampel filter** on log price catches spikes: a value more than N robust
    standard deviations (MAD) from its rolling median is an outlier, regardless of
    how the market "really" moved.
  * **Range** checks catch bars whose high-low span is impossible for the symbol.
  * **Gap** detection reports missing bars; gaps are reported, never interpolated,
    because inventing prices is how you invent alpha.

Repair policy — two different defects, two different remedies
------------------------------------------------------------
The two failure modes are not the same thing and must not be treated the same:

* **A corrupt *close*** (a spike in the price path). The whole bar is
  untrustworthy, so its OHLC is collapsed onto the last good close and volume is
  zeroed. The clock is preserved; only the fake print is removed.
* **A corrupt *wick*** (`high`/`low` far outside anything the close path implies,
  while `open`/`close` are perfectly consistent). Throwing the entire bar away
  here — the previous behaviour — destroys a perfectly good return observation to
  fix a high/low that the ATR uses. Instead the wick is *clamped* into a plausible
  band around the bar's own open/close, preserving the close path.

That distinction matters: on real feeds, and on the simulated feed used here,
wick corruption is an order of magnitude more common than close corruption. A
validator that discards the whole bar reports a 20% corruption rate on a series
whose actual returns are spotless, and the operator learns to ignore it.

Every action is logged and counted — if a symbol needs more than a fraction of a
percent of bar-level repairs, the feed is the problem and the symbol should be
dropped.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from alpha.log import get_logger

log = get_logger("alpha.data.qc")

PRICE_COLUMNS = ("open", "high", "low", "close")


@dataclass
class QualityReport:
    symbol: str
    rows: int = 0
    structural: int = 0
    spikes: int = 0
    range_outliers: int = 0
    duplicates: int = 0
    gaps: int = 0
    #: Bars whose close path was untrustworthy and were collapsed entirely.
    repaired: int = 0
    #: Bars whose close was fine but whose high/low was clamped.
    wick_repairs: int = 0
    details: list[str] = field(default_factory=list)

    @property
    def bad_fraction(self) -> float:
        """Share of bars with a corrupt *close* — the number that decides tradability."""
        return self.repaired / self.rows if self.rows else 0.0

    @property
    def wick_fraction(self) -> float:
        """Share of bars with a clamped wick. Tolerable, but it degrades ATR."""
        return self.wick_repairs / self.rows if self.rows else 0.0

    def summary(self) -> str:
        return (
            f"{self.symbol}: {self.rows} bars, bars repaired {self.repaired} "
            f"({self.bad_fraction:.4%}), wicks clamped {self.wick_repairs} "
            f"({self.wick_fraction:.3%}) [structural={self.structural} "
            f"spikes={self.spikes} range={self.range_outliers} dupes={self.duplicates} "
            f"gaps={self.gaps}]"
        )


def structural_mask(df: pd.DataFrame) -> np.ndarray:
    """Physically impossible candles."""
    px = df[list(PRICE_COLUMNS)].to_numpy(dtype=float)
    bad = ~np.isfinite(px).all(axis=1)
    bad |= (px <= 0).any(axis=1)
    high = df["high"].to_numpy(dtype=float)
    low = df["low"].to_numpy(dtype=float)
    open_ = df["open"].to_numpy(dtype=float)
    close = df["close"].to_numpy(dtype=float)
    bad |= high < low
    bad |= high < np.maximum(open_, close) - 1e-12
    bad |= low > np.minimum(open_, close) + 1e-12
    if "volume" in df:
        bad |= df["volume"].to_numpy(dtype=float) < 0
    return bad


def hampel_mask(log_price: np.ndarray, window: int = 24, n_sigma: float = 6.0) -> np.ndarray:
    """Robust spike detector on log prices.

    Uses the rolling median and the MAD. The MAD is scaled by 1.4826 so it is
    comparable to a standard deviation for Gaussian data, but — unlike a rolling
    std — it is not itself dragged upward by the very outlier we are hunting.
    """
    s = pd.Series(log_price)
    med = s.rolling(window, center=True, min_periods=max(3, window // 3)).median()
    mad = (s - med).abs().rolling(window, center=True, min_periods=max(3, window // 3)).median()
    sigma = 1.4826 * mad
    # Floor the threshold so a perfectly flat stretch does not flag everything.
    floor = 0.002  # 0.2% in log space
    threshold = np.maximum(n_sigma * sigma.to_numpy(dtype=float), floor)
    deviation = np.abs(log_price - med.to_numpy(dtype=float))
    return deviation > threshold


def range_mask(df: pd.DataFrame, max_range_frac: float = 0.35) -> np.ndarray:
    """Bars whose high-low span is implausible for a liquid perpetual."""
    high = df["high"].to_numpy(dtype=float)
    low = df["low"].to_numpy(dtype=float)
    ref = df["close"].to_numpy(dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        span = np.where(ref > 0, (high - low) / ref, np.inf)
    return ~np.isfinite(span) | (span > max_range_frac)


def detect_gaps(ts: np.ndarray, expected_ms: int) -> np.ndarray:
    """Indices where the clock skipped more than one bar."""
    if len(ts) < 2:
        return np.zeros(len(ts), dtype=bool)
    deltas = np.diff(ts)
    gaps = np.zeros(len(ts), dtype=bool)
    gaps[1:] = deltas > expected_ms * 1.5
    return gaps


def clamp_wick_bounds(
    df: pd.DataFrame,
    flagged: np.ndarray,
    *,
    max_range_frac: float = 0.35,
    window: int = 168,
    k: float = 2.0,
    floor_frac: float = 0.002,
) -> tuple[pd.Series, pd.Series]:
    """Plausible upper/lower bounds for a bar's wicks, from its own open/close.

    Two things make this robust, and both were needed in practice:

    * The reference span comes from a rolling median over **unflagged bars only**.
      A plain rolling median is contaminated when the corrupt bars come in a
      cluster — which is exactly how a bad feed delivers them — and the resulting
      bound is then too loose to fix anything.
    * The bound is additionally capped so the repaired bar cannot exceed
      `max_range_frac`. Without that hard cap, a clamped bar could still be flagged
      by the very predicate that triggered the repair, so cleaning would not be
      idempotent and every reload would rewrite the data.
    """
    open_ = df["open"].to_numpy(dtype=float)
    close_ = df["close"].to_numpy(dtype=float)
    span = (df["high"] - df["low"]).to_numpy(dtype=float)
    price = np.maximum(close_, 1e-12)

    clean_span = pd.Series(np.where(flagged, np.nan, span))
    ref = clean_span.rolling(window, min_periods=max(8, window // 8)).median()
    ref = ref.bfill().ffill().fillna(0.0).to_numpy(dtype=float)

    top = np.maximum(open_, close_)
    bot = np.minimum(open_, close_)
    body = top - bot

    # Never allow the repaired bar to breach the range predicate.
    room = np.maximum(price * max_range_frac - body, 0.0) / 2.0
    allowed = np.minimum(np.maximum(ref * k, price * floor_frac), np.maximum(room, 0.0))
    return pd.Series(top + allowed), pd.Series(bot - allowed)


def clean_ohlcv(
    df: pd.DataFrame,
    symbol: str = "?",
    *,
    expected_ms: int = 3_600_000,
    hampel_window: int = 24,
    hampel_sigma: float = 6.0,
    max_range_frac: float = 0.35,
    wick_k: float = 2.0,
    repair: bool = True,
) -> tuple[pd.DataFrame, QualityReport]:
    """Validate and (optionally) repair an OHLCV frame.

    Returns the frame plus a report. A boolean `is_bad` column marks the bars whose
    close was destroyed; wick-only repairs are counted in the report but do not
    mark the bar, because its price path is still valid.
    """
    report = QualityReport(symbol=symbol, rows=len(df))
    if df.empty:
        return df.copy(), report

    out = df.sort_values("ts").reset_index(drop=True).copy()
    report.rows = len(out)

    report.duplicates = int(out["ts"].duplicated().sum())
    if report.duplicates:
        out = out.drop_duplicates(subset="ts", keep="last").reset_index(drop=True)

    structural = structural_mask(out)
    log_price = np.log(out["close"].to_numpy(dtype=float).clip(min=1e-12))
    spikes = hampel_mask(log_price, window=hampel_window, n_sigma=hampel_sigma)
    rng = range_mask(out, max_range_frac=max_range_frac)
    gaps = detect_gaps(out["ts"].to_numpy(dtype=np.int64), expected_ms)

    # A bar is only truly "bad" if its *close* is untrustworthy. A wide range on an
    # otherwise consistent bar is a wick problem, and repair for it is far cheaper.
    bar_bad = structural | spikes
    wick_bad = rng & ~bar_bad

    report.structural = int(structural.sum())
    report.spikes = int(spikes.sum())
    report.range_outliers = int(rng.sum())
    report.gaps = int(gaps.sum())
    report.repaired = int(bar_bad.sum())
    report.wick_repairs = int(wick_bad.sum())

    if report.gaps:
        report.details.append(f"{report.gaps} gap(s) in the time index (not interpolated)")

    out["is_bad"] = bar_bad
    if not repair:
        return out, report

    # --- repair 1: corrupt closes -> collapse onto the last good close ----------
    if bar_bad.any():
        good_close = pd.Series(np.where(bar_bad, np.nan, out["close"].to_numpy(dtype=float)))
        good_close = good_close.ffill().bfill()
        for col in PRICE_COLUMNS:
            values = out[col].to_numpy(dtype=float).copy()
            values[bar_bad] = good_close.to_numpy(dtype=float)[bar_bad]
            out[col] = values
        out.loc[bar_bad, "volume"] = 0.0
        if "turnover" in out:
            out.loc[bar_bad, "turnover"] = 0.0
        for idx in np.flatnonzero(bar_bad)[:5]:
            report.details.append(
                f"repaired bar at ts={int(out['ts'].iloc[idx])} "
                f"(close was {float(df['close'].iloc[idx]):.6g})"
            )

    # --- repair 2: corrupt wicks -> clamp, keep the close path ------------------
    if wick_bad.any():
        # Bounds are computed after the close repair so a collapsed bar cannot
        # inflate the rolling median span.
        upper, lower = clamp_wick_bounds(
            out, wick_bad, max_range_frac=max_range_frac, k=wick_k
        )
        high = out["high"].to_numpy(dtype=float).copy()
        low = out["low"].to_numpy(dtype=float).copy()
        high[wick_bad] = np.minimum(high[wick_bad], upper.to_numpy()[wick_bad])
        low[wick_bad] = np.maximum(low[wick_bad], lower.to_numpy()[wick_bad])
        out["high"] = high
        out["low"] = low
        for idx in np.flatnonzero(wick_bad)[:5]:
            report.details.append(
                f"clamped wick at ts={int(out['ts'].iloc[idx])} "
                f"(high/low were {float(df['high'].iloc[idx]):.6g}/{float(df['low'].iloc[idx]):.6g})"
            )

    if report.bad_fraction > 0.01 or report.wick_fraction > 0.10:
        log.warning(
            "high rate of data defects — treat this symbol's feed as suspect",
            extra={
                "extra_fields": {
                    "symbol": symbol,
                    "bad_fraction": round(report.bad_fraction, 5),
                    "wick_fraction": round(report.wick_fraction, 5),
                }
            },
        )
    return out, report


def clean_panel(
    panels: dict[str, pd.DataFrame], *, expected_ms: int = 3_600_000
) -> tuple[dict[str, pd.DataFrame], list[QualityReport]]:
    cleaned: dict[str, pd.DataFrame] = {}
    reports: list[QualityReport] = []
    for symbol, df in panels.items():
        frame, report = clean_ohlcv(df, symbol=symbol, expected_ms=expected_ms)
        cleaned[symbol] = frame.drop(columns=["is_bad"], errors="ignore")
        reports.append(report)
        log.info(report.summary())
    return cleaned, reports
