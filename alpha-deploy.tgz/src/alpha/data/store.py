"""Local parquet store for market data.

Layout::

    <root>/klines/<category>/<symbol>/<interval>.parquet
    <root>/funding/<category>/<symbol>.parquet

Parquet (not CSV, not a database) because a year of 1m candles for a few symbols
is ~a few million rows: pandas reads it in milliseconds and it stays diffable.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

KLINE_COLUMNS = ["ts", "open", "high", "low", "close", "volume", "turnover"]


class ParquetStore:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------- paths
    def kline_path(self, symbol: str, interval: str, category: str = "linear") -> Path:
        return self.root / "klines" / category / symbol / f"{interval}.parquet"

    def funding_path(self, symbol: str, category: str = "linear") -> Path:
        return self.root / "funding" / category / f"{symbol}.parquet"

    # ------------------------------------------------------------------ klines
    def save_klines(self, symbol: str, interval: str, df: pd.DataFrame, category: str = "linear") -> Path:
        if df.empty:
            raise ValueError("refusing to write an empty kline frame")
        path = self.kline_path(symbol, interval, category)
        path.parent.mkdir(parents=True, exist_ok=True)
        df = df.sort_values("ts").drop_duplicates(subset="ts", keep="last").reset_index(drop=True)
        df.to_parquet(path, index=False, compression="zstd")
        return path

    def load_klines(self, symbol: str, interval: str, category: str = "linear") -> pd.DataFrame:
        path = self.kline_path(symbol, interval, category)
        if not path.exists():
            return pd.DataFrame(columns=KLINE_COLUMNS)
        df = pd.read_parquet(path)
        return df.sort_values("ts").reset_index(drop=True)

    def upsert_klines(self, symbol: str, interval: str, df: pd.DataFrame, category: str = "linear") -> pd.DataFrame:
        """Merge new candles into what we already have, newest row wins per timestamp."""
        existing = self.load_klines(symbol, interval, category)
        merged = df if existing.empty else pd.concat([existing, df], ignore_index=True)
        merged = merged.sort_values("ts").drop_duplicates(subset="ts", keep="last").reset_index(drop=True)
        self.save_klines(symbol, interval, merged, category)
        return merged

    def coverage(self, symbol: str, interval: str, category: str = "linear") -> tuple[int, int] | None:
        df = self.load_klines(symbol, interval, category)
        if df.empty:
            return None
        return int(df["ts"].min()), int(df["ts"].max())

    # ----------------------------------------------------------------- funding
    def save_funding(self, symbol: str, df: pd.DataFrame, category: str = "linear") -> Path:
        path = self.funding_path(symbol, category)
        path.parent.mkdir(parents=True, exist_ok=True)
        df = df.sort_values("ts").drop_duplicates(subset="ts", keep="last").reset_index(drop=True)
        df.to_parquet(path, index=False, compression="zstd")
        return path

    def load_funding(self, symbol: str, category: str = "linear") -> pd.DataFrame:
        path = self.funding_path(symbol, category)
        if not path.exists():
            return pd.DataFrame(columns=["ts", "funding_rate"])
        return pd.read_parquet(path).sort_values("ts").reset_index(drop=True)

    def upsert_funding(self, symbol: str, df: pd.DataFrame, category: str = "linear") -> pd.DataFrame:
        existing = self.load_funding(symbol, category)
        merged = df if existing.empty else pd.concat([existing, df], ignore_index=True)
        merged = merged.sort_values("ts").drop_duplicates(subset="ts", keep="last").reset_index(drop=True)
        self.save_funding(symbol, merged, category)
        return merged

    # ---------------------------------------------------------------------- qc
    def qc_path(self, symbol: str, interval: str, category: str = "linear") -> Path:
        return self.root / "qc" / category / f"{symbol}_{interval}.json"

    def save_qc(self, symbol: str, interval: str, payload: dict, category: str = "linear") -> None:
        """Record what the feed looked like *at ingestion*, before cleaning.

        This matters because the stored candles are already repaired, so a quality
        report run on them is necessarily clean. Without this manifest the preflight
        would always pass and silently hide a bad upstream feed.
        """
        path = self.qc_path(symbol, interval, category)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {**payload, "symbol": symbol, "interval": interval}
        path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")

    def load_qc(self, symbol: str, interval: str, category: str = "linear") -> dict | None:
        path = self.qc_path(symbol, interval, category)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def inventory(self) -> pd.DataFrame:
        """Everything we have on disk — handy for `alpha data status`."""
        rows = []
        for path in sorted(self.root.rglob("*.parquet")):
            rel = path.relative_to(self.root)
            try:
                df = pd.read_parquet(path)
            except Exception:  # noqa: BLE001 - a corrupt cache file shouldn't kill the CLI
                rows.append({"dataset": str(rel.parent), "file": rel.name, "rows": -1})
                continue
            rows.append(
                {
                    "dataset": str(rel.parent),
                    "file": rel.name,
                    "rows": len(df),
                    "start": pd.to_datetime(df["ts"].min(), unit="ms", utc=True) if "ts" in df and len(df) else None,
                    "end": pd.to_datetime(df["ts"].max(), unit="ms", utc=True) if "ts" in df and len(df) else None,
                }
            )
        return pd.DataFrame(rows)
