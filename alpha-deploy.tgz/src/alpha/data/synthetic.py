"""Deterministic synthetic market data with known statistical properties.

Why generate prices instead of using the feed
---------------------------------------------
The exchange snapshot available here returns corrupt/simulated candles, which is
exactly the situation in which you *cannot* validate a strategy: if the data is a
random walk with the wrong vol, a backtest that "works" tells you nothing, and a
backtest that fails tells you even less. A generator with parameters you control
turns every downstream claim into a falsifiable one:

* vol targeting is only correct if realised vol matches the configured
  ``annual_vol`` — so we can assert that directly instead of eyeballing an equity
  curve;
* a sizer that ignores fat tails shows up as a drawdown far worse than the one a
  Gaussian simulation predicts, so ``jump_prob`` gives us a known ground truth to
  break it against;
* a cross-sectional book that silently trades one bet three times looks fine on
  i.i.d. symbols — ``common_factor`` makes the shared exposure explicit and
  measurable.

Everything is driven by ``numpy.random.default_rng(cfg.seed)``: no global RNG
state, no wall clock, no network. The same config yields byte-identical frames on
any machine, which is what makes a failing test reproducible.
"""

from __future__ import annotations

import zlib
from dataclasses import dataclass, fields, replace

import numpy as np
import pandas as pd

from alpha.data.store import KLINE_COLUMNS

_MS_PER_YEAR = 365.0 * 24.0 * 3_600_000.0
# The stationary anchor is a *slow* random walk: if it moved with the same vol as
# the price, mean reversion would not shrink long-horizon variance at all and the
# knob would be a lie. 10% of the shock keeps the anchor visibly trending while
# letting the OU pull actually bite.
_ANCHOR_SHARE = 0.1
# GARCH(1,1) split of the persistence: mostly lagged variance, a little lagged shock.
_GARCH_ALPHA = 0.15
_GARCH_BETA = 0.85
# Per-symbol vol ladder as multipliers of ``annual_vol`` (0.5 -> 0.40/0.55/0.75).
_VOL_LADDER = (0.8, 1.1, 1.5)
_FUNDING_NOISE = 0.0002
_BASE_VOLUME = 500.0


@dataclass
class SyntheticConfig:
    """Knobs for the generator. Every field has a default so ``SyntheticConfig()`` is valid.

    ``mean_reversion`` is in per-year units: 0 is a pure driftless random walk,
    and higher values pull the log price back toward a slowly drifting anchor.
    ``vol_clustering`` in [0, 1) is GARCH persistence — at 0 returns are
    homoskedastic, which is the regime in which a vol model *must* measure the
    configured vol exactly; above 0 the realised vol becomes path dependent and
    vol-targeting bugs surface.

    ``common_factor`` is the loading on a shared market shock, so the pairwise
    return correlation between two symbols is roughly ``common_factor ** 2``
    (0 = independent books, 1 = one trade wearing three tickers). It only has an
    effect in :func:`generate_panel`, where the shared shock exists.
    """

    symbol: str = "SYNTHUSDT"
    start_ts: int = 1_700_000_000_000
    bars: int = 8760
    interval_ms: int = 3_600_000
    start_price: float = 100.0
    annual_drift: float = 0.0
    annual_vol: float = 0.5
    mean_reversion: float = 0.0
    jump_prob: float = 0.0
    jump_scale: float = 0.03
    vol_clustering: float = 0.0
    funding_mean: float = 0.0001
    seed: int = 7
    funding_interval_ms: int = 8 * 3_600_000
    common_factor: float = 0.5


def _conditional_variance(z: np.ndarray, per_bar_var: float, persistence: float) -> np.ndarray:
    """GARCH(1,1) conditional variance per bar, normalised to the configured vol.

    The recursion is written out by hand rather than vectorised because it is
    genuinely sequential; 8760 steps is microseconds, and keeping it explicit
    makes the unconditional-variance identity auditable. We set
    ``omega = (1 - phi) * per_bar_var`` with ``alpha + beta = phi`` so the
    *unconditional* variance is exactly the requested per-bar variance no matter
    how strong the clustering is. Otherwise a "0.5 annual vol" symbol would
    actually carry a different vol depending on a persistence knob, and the vol
    target would be sized off a number that means nothing.
    """
    n = z.size
    if persistence <= 0.0 or n == 0:
        return np.full(n, per_bar_var, dtype=float)
    phi = min(float(persistence), 0.999)
    alpha = _GARCH_ALPHA * phi
    beta = _GARCH_BETA * phi
    omega = (1.0 - phi) * per_bar_var
    out = np.empty(n, dtype=float)
    sig2_prev = per_bar_var
    eps2_prev = per_bar_var
    for i in range(n):
        sig2 = omega + alpha * eps2_prev + beta * sig2_prev
        out[i] = sig2
        eps2_prev = sig2 * z[i] * z[i]
        sig2_prev = sig2
    return out


def _empty_ohlcv() -> pd.DataFrame:
    frame = pd.DataFrame({col: pd.Series(dtype="float64") for col in KLINE_COLUMNS})
    frame["ts"] = frame["ts"].astype("int64")
    return frame[KLINE_COLUMNS]


def generate_ohlcv(cfg: SyntheticConfig, *, market_factor: np.ndarray | None = None) -> pd.DataFrame:
    """Simulate one OHLCV series matching the store's schema.

    The log price is decomposed as ``anchor + deviation``: the anchor is a slow
    random walk carrying the drift and a small share of the shock, the deviation
    is an AR(1)/OU process that reverts toward it. Written as returns this is
    ``r_i = mu*dt - 0.5*sig2_i + shock_i - (1 - phi) * dev_{i-1}``, which makes
    the ground truth checkable: at ``mean_reversion == 0`` (``phi == 1``) the
    reversion term vanishes and the series is an exact random walk, so any
    "alpha" a strategy finds there is pure noise.

    ``market_factor`` is an optional shared standard-normal shock; with
    ``cfg.common_factor`` it induces cross-sectional correlation (used by
    :func:`generate_panel`). Passing it here for a single symbol only changes the
    noise stream, never the marginal distribution.

    The OHLC envelope is built so that ``high >= max(open, close)`` and
    ``low <= min(open, close)`` by construction, with strictly positive prices.
    That is not cosmetic: one crossed candle poisons the ATR and every
    volatility-scaled size downstream, so the generator must never emit a bar the
    QC layer would have to repair.
    """
    n = int(cfg.bars)
    if n <= 0:
        return _empty_ohlcv()

    rng = np.random.default_rng(cfg.seed)
    dt = cfg.interval_ms / _MS_PER_YEAR
    per_bar_var = (float(cfg.annual_vol) ** 2) * dt

    if market_factor is not None:
        factor = np.asarray(market_factor, dtype=float)
        if factor.size != n:
            raise ValueError(f"market_factor has {factor.size} rows, expected {n}")
        common = float(np.clip(cfg.common_factor, 0.0, 0.999))
        idio_scale = float(np.sqrt(max(1.0 - common * common, 0.0)))
        z = common * factor + idio_scale * rng.standard_normal(n)
    else:
        z = rng.standard_normal(n)

    cond_var = _conditional_variance(z, per_bar_var, float(cfg.vol_clustering))
    shock = np.sqrt(cond_var) * z

    # Jumps are added to the *return*, so they fatten the tails of the return
    # distribution without breaking the OHLC envelope built below.
    if cfg.jump_prob > 0.0:
        hit = rng.random(n) < float(cfg.jump_prob)
        shock = shock + hit * rng.standard_normal(n) * float(cfg.jump_scale)

    phi = float(np.exp(-float(cfg.mean_reversion) * dt)) if cfg.mean_reversion > 0.0 else 1.0
    one_minus_phi = 1.0 - phi
    dev_scale = 1.0 - _ANCHOR_SHARE
    drift_bar = float(cfg.annual_drift) * dt
    ret = np.empty(n, dtype=float)
    dev = 0.0
    for i in range(n):
        ret[i] = drift_bar - 0.5 * cond_var[i] + shock[i] - one_minus_phi * dev
        dev = phi * dev + dev_scale * shock[i]

    close = np.exp(np.log(float(cfg.start_price)) + np.cumsum(ret))
    open_ = np.empty(n, dtype=float)
    open_[0] = float(cfg.start_price)
    open_[1:] = close[:-1]

    # Intraday wicks: half-range draws scaled by the bar's own conditional vol so
    # quiet bars print small ranges and volatile bars print wide ones.
    scale = np.sqrt(cond_var)
    high = np.maximum(open_, close) * np.exp(np.abs(rng.standard_normal(n)) * 0.7 * scale)
    low = np.minimum(open_, close) * np.exp(-np.abs(rng.standard_normal(n)) * 0.7 * scale)

    rel_vol = scale / np.sqrt(per_bar_var) if per_bar_var > 0.0 else np.ones(n)
    volume = (
        _BASE_VOLUME
        * rel_vol
        * np.exp(0.4 * rng.standard_normal(n))
        * (1.0 + 4.0 * np.abs(ret))
    )

    ts = int(cfg.start_ts) + np.arange(n, dtype=np.int64) * int(cfg.interval_ms)
    frame = pd.DataFrame(
        {
            "ts": ts,
            "open": open_,
            "high": high,
            "low": low,
            "close": close,
            "volume": volume,
            "turnover": volume * close,
        },
        columns=KLINE_COLUMNS,
    )
    frame["ts"] = frame["ts"].astype("int64")
    for col in KLINE_COLUMNS[1:]:
        frame[col] = frame[col].astype("float64")
    return frame


def generate_funding(cfg: SyntheticConfig) -> pd.DataFrame:
    """Settlement-rate series stamped on the bar clock's window.

    Rates land exactly on multiples of ``funding_interval_ms`` (the condition the
    feature pipeline's cumulative-sum attribution relies on) and only inside the
    kline window, so joining funding to klines never invents a rate before the
    first bar or after the last. ``funding_interval_ms`` exists because Bybit is
    not uniform: BTC settles every 8h, ETH often 2h, SOL 1h. Hard-coding 8h
    silently understates the carry cost of the fastest symbols, so the schedule
    is a parameter, not a constant.
    """
    step = int(cfg.funding_interval_ms)
    if step <= 0:
        raise ValueError("funding_interval_ms must be positive")
    if int(cfg.bars) <= 0:
        return pd.DataFrame(
            {
                "ts": np.empty(0, dtype=np.int64),
                "funding_rate": np.empty(0, dtype=np.float64),
            }
        )

    first = int(cfg.start_ts)
    last = first + (int(cfg.bars) - 1) * int(cfg.interval_ms)
    k_first = -(-first // step)  # ceil: first multiple at or after the first bar
    k_last = last // step
    if k_last < k_first:
        ts = np.empty(0, dtype=np.int64)
        rates = np.empty(0, dtype=np.float64)
    else:
        ts = np.arange(k_first, k_last + 1, dtype=np.int64) * step
        # A dedicated stream: reuse of the price seed would correlate funding with
        # returns for no modelling reason and make carry tests depend on price.
        rng = np.random.default_rng([int(cfg.seed), 0x5EED])
        rates = float(cfg.funding_mean) + _FUNDING_NOISE * rng.standard_normal(ts.size)
    return pd.DataFrame({"ts": ts.astype("int64"), "funding_rate": rates.astype("float64")})


def generate_panel(
    symbols: list[str], **overrides
) -> tuple[dict[str, pd.DataFrame], dict[str, pd.DataFrame]]:
    """Build ``(ohlcv_by_symbol, funding_by_symbol)`` for a correlated universe.

    Every symbol shares one market-factor stream but gets its own seed derived
    from its name and its own rung on the vol ladder, so the panel is
    *correlated but distinct* — the regime in which a portfolio optimiser's
    diversification estimate is actually being tested. With ``common_factor=0``
    the symbols are independent and a cross-sectional strategy has no shared
    exposure to hide behind.

    Seeds come from ``zlib.crc32`` rather than ``hash()``: CPython randomises
    string hashing per process, so ``hash()`` would make the same symbol generate
    different prices on every run and break reproducibility.
    """
    valid = {f.name for f in fields(SyntheticConfig)}
    unknown = sorted(set(overrides) - valid)
    if unknown:
        raise TypeError(f"unknown SyntheticConfig field(s): {', '.join(unknown)}")

    base = replace(SyntheticConfig(), **overrides)
    factor = np.random.default_rng([int(base.seed), 0xFACE]).standard_normal(int(base.bars))

    ohlcv: dict[str, pd.DataFrame] = {}
    funding: dict[str, pd.DataFrame] = {}
    for i, symbol in enumerate(symbols):
        seed = (int(base.seed) + zlib.crc32(symbol.encode("utf-8"))) % (2**32)
        cfg = replace(
            base,
            symbol=symbol,
            annual_vol=float(base.annual_vol) * _VOL_LADDER[i % len(_VOL_LADDER)],
            seed=seed,
        )
        ohlcv[symbol] = generate_ohlcv(cfg, market_factor=factor)
        funding[symbol] = generate_funding(cfg)
    return ohlcv, funding
