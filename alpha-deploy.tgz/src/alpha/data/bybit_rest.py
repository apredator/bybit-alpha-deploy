"""Bybit V5 REST client (sync).

Deliberately dependency-light: `httpx` + `hashlib`/`hmac`. Everything the agent
needs is here — public candles/funding/instrument specs, and the signed private
endpoints for account, positions and orders.

Design notes
------------
* Retries use exponential backoff and only fire on transport errors, 5xx and
  Bybit's "system busy" codes. A rejected order is **never** silently retried —
  that is how you end up with double fills.
* Rate-limit responses (retCode 10006) are retried with a backoff, since getting
  banned by the exchange is a real operational risk.
* Every private call carries a unique `orderLinkId`/timestamp, and order
  placement is idempotent by `orderLinkId` (the exchange deduplicates for us).
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
import uuid
from typing import Any, Self

import httpx
from tenacity import (
    RetryCallState,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential_jitter,
)

from alpha.config import BybitConfig
from alpha.log import get_logger

log = get_logger("alpha.bybit")

#: Bybit business codes that are worth retrying (transient, not our fault).
RETRYABLE_CODES = {10002, 10006, 10016, 10018, 30034, 130101}
#: Codes meaning "duplicate orderLinkId" — harmless, means our order already landed.
DUPLICATE_ORDER_CODES = {110072, 110075}


class BybitError(RuntimeError):
    def __init__(self, code: int, message: str, endpoint: str, payload: Any = None) -> None:
        super().__init__(f"Bybit error {code} on {endpoint}: {message}")
        self.code = code
        self.message = message
        self.endpoint = endpoint
        self.payload = payload


class RateLimited(BybitError):
    pass


def _retry_predicate(exc: BaseException) -> bool:
    if isinstance(exc, RateLimited):
        return True
    if isinstance(exc, BybitError):
        return exc.code in RETRYABLE_CODES
    return isinstance(exc, (httpx.TransportError, httpx.TimeoutException))


def _log_retry(state: RetryCallState) -> None:
    exc = state.outcome.exception() if state.outcome else None
    log.warning("retrying bybit call", extra={"extra_fields": {"attempt": state.attempt_number, "err": str(exc)}})


class BybitREST:
    """Thin, well-behaved wrapper over the Bybit V5 REST API."""

    def __init__(self, cfg: BybitConfig, client: httpx.Client | None = None) -> None:
        self.cfg = cfg
        self._client = client or httpx.Client(
            base_url=cfg.rest_url,
            timeout=cfg.timeout_s,
            headers={"User-Agent": "bybit-alpha/0.1"},
        )
        self._owns_client = client is None

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    # ------------------------------------------------------------------ plumbing
    def _sign(self, timestamp: str, payload: str) -> str:
        msg = f"{timestamp}{self.cfg.api_key.get_secret_value()}{self.cfg.recv_window}{payload}"
        return hmac.new(
            self.cfg.api_secret.get_secret_value().encode(),
            msg.encode(),
            hashlib.sha256,
        ).hexdigest()

    def _auth_headers(self, timestamp: str, payload: str) -> dict[str, str]:
        return {
            "X-BAPI-API-KEY": self.cfg.api_key.get_secret_value(),
            "X-BAPI-TIMESTAMP": timestamp,
            "X-BAPI-RECV-WINDOW": str(self.cfg.recv_window),
            "X-BAPI-SIGN": self._sign(timestamp, payload),
        }

    @staticmethod
    def _parse(resp: httpx.Response, endpoint: str) -> dict[str, Any]:
        try:
            body = resp.json()
        except ValueError as exc:  # non-JSON body usually means a proxy/CDN error page
            raise BybitError(-1, f"non-JSON response ({resp.status_code}): {resp.text[:200]}", endpoint) from exc
        code = int(body.get("retCode", -1))
        if code != 0:
            msg = str(body.get("retMsg", ""))
            if code in RETRYABLE_CODES:
                raise RateLimited(code, msg, endpoint, body)
            raise BybitError(code, msg, endpoint, body)
        return body

    @retry(
        retry=retry_if_exception_type((BybitError, httpx.TransportError, httpx.TimeoutException)),
        stop=stop_after_attempt(5),
        wait=wait_exponential_jitter(initial=0.5, max=15),
        reraise=True,
        before_sleep=_log_retry,
    )
    def _request(
        self,
        method: str,
        endpoint: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        signed: bool = False,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {}
        if signed:
            if not self.cfg.has_credentials:
                raise BybitError(-1, "private endpoint requires API credentials", endpoint)
            timestamp = str(int(time.time() * 1000))
            if method.upper() == "GET":
                payload = "&".join(f"{k}={v}" for k, v in sorted((params or {}).items()))
                headers = self._auth_headers(timestamp, payload)
                resp = self._client.request(method, endpoint, params=params, headers=headers)
            else:
                payload = json.dumps(body or {}, separators=(",", ":"))
                headers = self._auth_headers(timestamp, payload)
                headers["Content-Type"] = "application/json"
                resp = self._client.request(method, endpoint, content=payload, headers=headers)
        else:
            resp = self._client.request(method, endpoint, params=params)

        if resp.status_code >= 500:
            raise httpx.TransportError(f"server error {resp.status_code}")
        return self._parse(resp, endpoint)

    # ------------------------------------------------------------------- public
    def server_time_ms(self) -> int:
        body = self._request("GET", "/v5/market/time")
        return int(body["result"]["timeSecond"]) * 1000

    def klines(
        self,
        symbol: str,
        interval: str = "60",
        *,
        start_ms: int | None = None,
        end_ms: int | None = None,
        limit: int = 1000,
    ) -> list[list[str]]:
        """Raw candles, newest first. Bybit caps `limit` at 1000."""
        params: dict[str, Any] = {
            "category": self.cfg.category,
            "symbol": symbol,
            "interval": interval,
            "limit": min(limit, 1000),
        }
        if start_ms is not None:
            params["start"] = int(start_ms)
        if end_ms is not None:
            params["end"] = int(end_ms)
        return self._request("GET", "/v5/market/kline", params=params)["result"]["list"]

    def funding_history(
        self, symbol: str, *, start_ms: int | None = None, end_ms: int | None = None, limit: int = 200
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"category": self.cfg.category, "symbol": symbol, "limit": min(limit, 200)}
        if start_ms is not None:
            params["startTime"] = int(start_ms)
        if end_ms is not None:
            params["endTime"] = int(end_ms)
        return self._request("GET", "/v5/market/funding/history", params=params)["result"]["list"]

    def instruments_info(self, symbol: str) -> dict[str, Any]:
        body = self._request(
            "GET",
            "/v5/market/instruments-info",
            params={"category": self.cfg.category, "symbol": symbol},
        )
        items = body["result"]["list"]
        if not items:
            raise BybitError(-1, f"unknown symbol {symbol}", "/v5/market/instruments-info")
        return items[0]

    def ticker(self, symbol: str) -> dict[str, Any]:
        body = self._request(
            "GET", "/v5/market/tickers", params={"category": self.cfg.category, "symbol": symbol}
        )
        items = body["result"]["list"]
        return items[0] if items else {}

    # ------------------------------------------------------------------ private
    def wallet_balance(self, account_type: str = "UNIFIED") -> dict[str, Any]:
        return self._request(
            "GET", "/v5/account/wallet-balance", params={"accountType": account_type}, signed=True
        )["result"]

    def positions(self, symbol: str | None = None, settle_coin: str = "USDT") -> list[dict[str, Any]]:
        params: dict[str, Any] = {"category": self.cfg.category, "settleCoin": settle_coin}
        if symbol:
            params["symbol"] = symbol
        return self._request("GET", "/v5/position/list", params=params, signed=True)["result"]["list"]

    def open_orders(self, symbol: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"category": self.cfg.category}
        if symbol:
            params["symbol"] = symbol
        return self._request("GET", "/v5/order/realtime", params=params, signed=True)["result"]["list"]

    def set_leverage(self, symbol: str, leverage: float, *, margin_mode: int = 0) -> dict[str, Any]:
        body = {
            "category": self.cfg.category,
            "symbol": symbol,
            "buyLeverage": str(leverage),
            "sellLeverage": str(leverage),
            **({"tradeMode": margin_mode} if margin_mode else {}),
        }
        return self._request("POST", "/v5/position/set-leverage", body=body, signed=True)["result"]

    def place_order(
        self,
        *,
        symbol: str,
        side: str,
        qty: float,
        order_type: str = "Market",
        price: float | None = None,
        reduce_only: bool = False,
        client_id: str | None = None,
        time_in_force: str = "IOC",
    ) -> dict[str, Any]:
        """Place an order. `client_id` is the idempotency key — reuse it on retry."""
        client_id = client_id or f"alpha-{uuid.uuid4().hex[:20]}"
        body: dict[str, Any] = {
            "category": self.cfg.category,
            "symbol": symbol,
            "side": side,
            "orderType": order_type,
            "qty": _fmt_qty(qty),
            "orderLinkId": client_id,
            "reduceOnly": reduce_only,
        }
        if order_type == "Limit":
            if price is None:
                raise ValueError("limit order requires a price")
            body["price"] = _fmt_price(price)
            body["timeInForce"] = time_in_force
        try:
            result = self._request("POST", "/v5/order/create", body=body, signed=True)["result"]
        except BybitError as exc:
            if exc.code in DUPLICATE_ORDER_CODES:
                # Our previous attempt actually landed. Return the known id instead of
                # firing a second order — this is the whole point of orderLinkId.
                log.warning(
                    "duplicate orderLinkId; treating as already accepted",
                    extra={"extra_fields": {"client_id": client_id, "symbol": symbol}},
                )
                return {"orderId": "", "orderLinkId": client_id, "duplicate": True}
            raise
        result.setdefault("orderLinkId", client_id)
        return result

    def cancel_order(self, *, symbol: str, order_id: str | None = None, client_id: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"category": self.cfg.category, "symbol": symbol}
        if order_id:
            body["orderId"] = order_id
        if client_id:
            body["orderLinkId"] = client_id
        return self._request("POST", "/v5/order/cancel", body=body, signed=True)["result"]

    def cancel_all(self, symbol: str) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v5/order/cancel-all",
            body={"category": self.cfg.category, "symbol": symbol},
            signed=True,
        )["result"]

    def set_trading_stop(
        self,
        *,
        symbol: str,
        take_profit: float | None = None,
        stop_loss: float | None = None,
        trailing_stop: float | None = None,
        position_idx: int = 0,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "category": self.cfg.category,
            "symbol": symbol,
            "positionIdx": position_idx,
            "tpslMode": "Full",
        }
        if take_profit is not None:
            body["takeProfit"] = _fmt_price(take_profit)
        if stop_loss is not None:
            body["stopLoss"] = _fmt_price(stop_loss)
        if trailing_stop is not None:
            body["trailingStop"] = _fmt_price(trailing_stop)
        return self._request("POST", "/v5/position/trading-stop", body=body, signed=True)["result"]

    def closed_pnl(self, *, symbol: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"category": self.cfg.category, "limit": min(limit, 100)}
        if symbol:
            params["symbol"] = symbol
        return self._request("GET", "/v5/position/closed-pnl", params=params, signed=True)["result"]["list"]


def _fmt_qty(qty: float) -> str:
    return f"{abs(qty):.8f}".rstrip("0").rstrip(".")


def _fmt_price(price: float) -> str:
    return f"{price:.8f}".rstrip("0").rstrip(".")
