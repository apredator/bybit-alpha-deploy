"""Market data ingestion: paginated history downloads with a local cache.

The loader is the only place that talks to Bybit for research data. Everything
downstream (features, backtest) reads plain DataFrames, which keeps the
simulator fast and makes offline/CI runs possible.
"""

from __future__ import annotations

import datetime as dt
import time
from dataclasses import dataclass

import pandas as pd

from alpha.config import DataConfig
from alpha.data.bybit_rest import BybitREST
from alpha.data.store import KLINE_COLUMNS, ParquetStore
from alpha.data.validation import clean_ohlcv
from alpha.log import get_logger

log = get_logger("alpha.data")

INTERVAL_MS = {
    "1": 60_000,
    "3": 180_000,
    "5": 300_000,
    "15": 900_000,
    "30": 1_800_000,
    "60": 3_600_000,
    "120": 7_200_000,
    "240": 14_400_000,
    "360": 21_600_000,
    "720": 43_200_000,
    "D": 86_400_000,
}
FUNDING_INTERVAL_MS = 8 * 3_600_000  # Bybit settles funding every 8h


@dataclass
class DownloadReport:
    symbol: str
    fetched: int
    total: int
    first_ts: int | None
    last_ts: int | None
    up_to_date: bool


def _to_frame(rows: list[list[str]]) -> pd.DataFrame:
    """Bybit returns [start, open, high, low, close, volume, turnover], newest first."""
    if not rows:
        return pd.DataFrame(columns=KLINE_COLUMNS)
    df = pd.DataFrame(rows, columns=KLINE_COLUMNS)
    for col in KLINE_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    # In Bybit's kline payload index 6 is turnover, but for `linear` it is quote volume;
    # keep it as float and never assume more than that.
    return df.dropna(subset=["ts", "open", "high", "low", "close"]).astype({"ts": "int64"})


class MarketDataLoader:
    def __init__(self, rest: BybitREST, store: ParquetStore, cfg: DataConfig) -> None:
        self.rest = rest
        self.store = store
        self.cfg = cfg

    # ------------------------------------------------------------------ klines
    def download_klines(
        self,
        symbol: str,
        *,
        interval: str | None = None,
        start_ms: int | None = None,
        end_ms: int | None = None,
        force: bool = False,
    ) -> DownloadReport:
        interval = interval or self.cfg.interval
        step = INTERVAL_MS[interval]
        now_ms = int(time.time() * 1000)
        end_ms = end_ms or now_ms
        if start_ms is None:
            start_ms = end_ms - self.cfg.history_days * 86_400_000

        existing = self.store.load_klines(symbol, interval, self.rest.cfg.category)
        if not existing.empty and not force:
            have_first, have_last = int(existing["ts"].min()), int(existing["ts"].max())
            # Only fetch the gap; the last stored candle is usually still forming.
            start_ms = min(start_ms, have_first) if have_first > start_ms else have_last + step
            if start_ms >= end_ms:
                return DownloadReport(symbol, 0, len(existing), have_first, have_last, True)

        fetched: list[pd.DataFrame] = []
        cursor = end_ms
        total_new = 0
        # Walk backwards through history: Bybit returns newest-first and caps at 1000/req.
        while cursor > start_ms:
            batch = self.rest.klines(symbol, interval, start_ms=start_ms, end_ms=cursor, limit=1000)
            frame = _to_frame(batch)
            if frame.empty:
                break
            oldest = int(frame["ts"].min())
            fetched.append(frame)
            total_new += len(frame)
            log.info(
                "downloaded klines",
                extra={
                    "extra_fields": {
                        "symbol": symbol,
                        "rows": len(frame),
                        "oldest": _iso(oldest),
                    }
                },
            )
            if oldest <= start_ms or len(frame) < 1000:
                break
            cursor = oldest - 1
            time.sleep(0.12)  # stay well inside the public rate limit

        if not fetched:
            merged = existing
        else:
            new = pd.concat(fetched, ignore_index=True)
            merged = self.store.upsert_klines(symbol, interval, new, self.rest.cfg.category)

        # Never persist a candle that would corrupt the ATR and the sizer downstream.
        cleaned, report = clean_ohlcv(
            merged, symbol=symbol, expected_ms=step, repair=True
        )
        if report.repaired or report.wick_repairs:
            log.warning("data quality", extra={"extra_fields": {"detail": report.summary()}})
            self.store.save_klines(symbol, interval, cleaned.drop(columns=["is_bad"], errors="ignore"), self.rest.cfg.category)
        self.store.save_qc(
            symbol,
            interval,
            {
                "checked_at_ms": int(time.time() * 1000),
                "rows": report.rows,
                "bad_bars": report.repaired,
                "bad_fraction": round(report.bad_fraction, 6),
                "clamped_wicks": report.wick_repairs,
                "wick_fraction": round(report.wick_fraction, 6),
                "structural": report.structural,
                "spikes": report.spikes,
                "range_outliers": report.range_outliers,
                "duplicates": report.duplicates,
                "gaps": report.gaps,
            },
            self.rest.cfg.category,
        )
        merged = cleaned.drop(columns=["is_bad"], errors="ignore")

        return DownloadReport(
            symbol=symbol,
            fetched=total_new,
            total=len(merged),
            first_ts=int(merged["ts"].min()) if not merged.empty else None,
            last_ts=int(merged["ts"].max()) if not merged.empty else None,
            up_to_date=False,
        )

    # ----------------------------------------------------------------- funding
    def download_funding(self, symbol: str, *, days: int | None = None, force: bool = False) -> int:
        days = days or self.cfg.history_days
        end_ms = int(time.time() * 1000)
        start_ms = end_ms - days * 86_400_000

        existing = self.store.load_funding(symbol, self.rest.cfg.category)
        if not existing.empty and not force:
            last = int(existing["ts"].max())
            if last >= end_ms - FUNDING_INTERVAL_MS:
                return 0
            start_ms = max(start_ms, last + 1)

        rows: list[dict] = []
        cursor = end_ms
        guard = 0
        while cursor > start_ms and guard < 200:
            guard += 1
            batch = self.rest.funding_history(symbol, start_ms=start_ms, end_ms=cursor, limit=200)
            if not batch:
                break
            for item in batch:
                rows.append(
                    {
                        "ts": int(item["fundingRateTimestamp"]),
                        "funding_rate": float(item["fundingRate"]),
                    }
                )
            oldest = min(int(i["fundingRateTimestamp"]) for i in batch)
            if oldest <= start_ms or len(batch) < 200:
                break
            cursor = oldest - 1
            time.sleep(0.12)

        if not rows:
            return 0
        df = pd.DataFrame(rows).drop_duplicates(subset="ts").sort_values("ts").reset_index(drop=True)
        self.store.upsert_funding(symbol, df, self.rest.cfg.category)
        return len(df)

    # ------------------------------------------------------------------ bundle
    def build_panel(self, symbols: list[str] | None = None, interval: str | None = None) -> dict[str, pd.DataFrame]:
        """Load cached klines for a set of symbols as {symbol: DataFrame}."""
        symbols = symbols or self.cfg.symbols
        interval = interval or self.cfg.interval
        out: dict[str, pd.DataFrame] = {}
        for sym in symbols:
            df = self.store.load_klines(sym, interval, self.rest.cfg.category)
            if df.empty:
                log.warning("no cached data for %s %s — run `alpha data download`", sym, interval)
                continue
            out[sym] = df
        return out


def _iso(ms: int) -> str:
    return dt.datetime.fromtimestamp(ms / 1000, tz=dt.UTC).strftime("%Y-%m-%d %H:%M")


def resample_ohlcv(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    """Resample lower-timeframe candles to a higher one, no lookahead.

    Open = first open, High/Low = extremes, Close = last close, Volume = sum.
    Timestamps stay as the *open* time of the aggregated bar.
    """
    if df.empty:
        return df.copy()
    indexed = df.copy()
    indexed["dt"] = pd.to_datetime(indexed["ts"], unit="ms", utc=True)
    indexed = indexed.set_index("dt")
    agg = {"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum", "turnover": "sum"}
    agg = {k: v for k, v in agg.items() if k in indexed.columns}
    out = indexed.resample(rule, label="left", closed="left").agg(agg).dropna(subset=["close"])
    out["ts"] = (out.index.asi8 // 1_000_000).astype("int64")
    return out.reset_index(drop=True)
