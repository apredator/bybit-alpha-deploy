"""High-level orchestration shared by the CLI, research notebooks and tests.

Keeping this in one place means the backtest a researcher runs and the one CI
runs on every commit are literally the same code path.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from alpha.backtest import metrics
from alpha.backtest.engine import BacktestEngine, BacktestResult
from alpha.config import Settings
from alpha.data.loader import INTERVAL_MS
from alpha.data.store import ParquetStore
from alpha.data.validation import clean_ohlcv
from alpha.features.indicators import bars_per_year
from alpha.log import get_logger
from alpha.risk.sizing import InstrumentSpec
from alpha.strategy.portfolio import PortfolioStrategy

log = get_logger("alpha.runner")


@dataclass
class ResearchRun:
    result: BacktestResult
    metrics: dict[str, float]
    weights: pd.DataFrame
    features: dict[str, pd.DataFrame]
    panels: dict[str, pd.DataFrame]

    @property
    def equity(self) -> pd.Series:
        return self.result.equity_curve


def load_panels(
    settings: Settings, symbols: list[str] | None = None, interval: str | None = None
) -> tuple[dict[str, pd.DataFrame], dict[str, pd.DataFrame]]:
    """Load cached data and pass it through QC.

    QC runs on read as well as on write: a cache written by an older version of
    the loader (or by hand) must not be able to smuggle bad bars into a backtest.
    """
    store = ParquetStore(settings.data.root)
    interval = interval or settings.data.interval
    symbols = symbols or settings.data.symbols
    expected_ms = INTERVAL_MS.get(interval, 3_600_000)
    panels: dict[str, pd.DataFrame] = {}
    fundings: dict[str, pd.DataFrame] = {}
    for sym in symbols:
        df = store.load_klines(sym, interval, settings.bybit.category)
        if df.empty:
            log.warning("missing cached klines for %s (%s) — run `alpha data download`", sym, interval)
            continue
        cleaned, report = clean_ohlcv(df, symbol=sym, expected_ms=expected_ms)
        if report.repaired:
            log.info("qc on load", extra={"extra_fields": {"detail": report.summary()}})
        panels[sym] = cleaned.drop(columns=["is_bad"], errors="ignore")
        fundings[sym] = store.load_funding(sym, settings.bybit.category)
    return panels, fundings


def run_backtest(
    settings: Settings,
    *,
    symbols: list[str] | None = None,
    interval: str | None = None,
    panels: dict[str, pd.DataFrame] | None = None,
    fundings: dict[str, pd.DataFrame] | None = None,
    params: dict | None = None,
    demean: bool = True,
    inverse_vol: bool = True,
    warmup_bars: int | None = None,
    specs: dict[str, InstrumentSpec] | None = None,
) -> ResearchRun:
    """Build weights from cached data and simulate them. Pure function of inputs."""
    interval = interval or settings.data.interval
    if panels is None or fundings is None:
        loaded_panels, loaded_fundings = load_panels(settings, symbols, interval)
        panels = panels or loaded_panels
        fundings = fundings if fundings is not None else loaded_fundings

    if not panels:
        raise RuntimeError(
            "no market data available. Run: alpha data download --symbols BTCUSDT,ETHUSDT"
        )

    merged_params = {**settings.strategy.params, **(params or {})}
    strategy = PortfolioStrategy(
        params=merged_params, demean=demean, inverse_vol=inverse_vol
    )
    weights, features = strategy.build_weight_matrix(panels, interval=interval, fundings=fundings)

    engine = BacktestEngine(settings, specs=specs)
    result = engine.run(weights, features, warmup_bars=warmup_bars)
    summary = metrics.summarize(
        result.equity_curve, result.returns, interval=interval, trades=result.trades
    )
    summary["funding_pnl"] = result.funding_paid
    summary["fees_paid"] = result.fees_paid
    return ResearchRun(
        result=result, metrics=summary, weights=weights, features=features, panels=panels
    )


#: Default in-sample grid. Deliberately small: a large grid fitted over a short
#: window is a machine for manufacturing overfitting, and the point of
#: walk-forward is to expose that, not to hide it behind compute.
DEFAULT_PARAM_GRID: list[dict] = [
    {"trend_fast": fast, "trend_slow": slow, "mr_entry_z": z, "adx_threshold": adx}
    for fast in (24, 48)
    for slow in (120, 200)
    for z in (1.4, 1.8)
    for adx in (18.0, 25.0)
]


@dataclass
class WalkForwardReport:
    folds: pd.DataFrame
    selected_params: pd.DataFrame
    train_bars: int
    test_bars: int
    interval: str
    optimized: bool

    # ------------------------------------------------------------- properties
    @property
    def n_folds(self) -> int:
        return len(self.folds)

    @property
    def oos_bars(self) -> int:
        return int(self.n_folds * self.test_bars)

    @property
    def oos_days(self) -> float:
        return self.oos_bars / (bars_per_year(self.interval) / 365.0)

    @property
    def win_rate(self) -> float:
        if self.folds.empty:
            return 0.0
        return float((self.folds["test_return"] > 0).mean())

    @property
    def mean_return(self) -> float:
        return float(self.folds["test_return"].mean()) if self.n_folds else 0.0

    @property
    def median_sharpe(self) -> float:
        return float(self.folds["test_sharpe"].median()) if self.n_folds else 0.0

    @property
    def halted_folds(self) -> int:
        """Folds in which the kill-switch fired during the test window.

        This matters more than it looks. A halted book is flat, and a flat window
        contributes a return of exactly 0.00% and a Sharpe of 0.00 — numbers that
        look like "no signal" but actually mean "the strategy was stopped by its own
        risk limits and the fold carries no information at all". Reporting those
        folds without flagging them silently drags every statistic toward zero, and
        the direction of the distortion depends on whether the halt was protecting
        against a loss or cutting off a recovery.
        """
        if self.folds.empty or "halted" not in self.folds:
            return 0
        return int(self.folds["halted"].sum())

    @property
    def t_stat(self) -> float:
        """One-sample t-statistic of the mean fold return.

        This is the number that decides whether "most folds were profitable" means
        anything. With five folds, a 100% win rate is entirely consistent with a
        strategy that has no edge at all — five coin flips come up heads one time
        in thirty-two. The t-statistic and the fold count are what separate a
        result from a coincidence.
        """
        if self.n_folds < 2:
            return 0.0
        r = self.folds["test_return"].to_numpy(dtype=float)
        sd = float(np.std(r, ddof=1))
        if sd <= 0:
            return float("inf") if float(np.mean(r)) > 0 else 0.0
        return float(np.mean(r) / (sd / np.sqrt(self.n_folds)))

    # ---------------------------------------------------------------- verdict
    def verdict(
        self,
        *,
        min_folds: int = 8,
        min_oos_days: float = 120.0,
        min_win_rate: float = 0.60,
        min_t: float = 2.0,
    ) -> tuple[str, str]:
        """Return `(status, explanation)`.

        Three outcomes, and the middle one is the point: a harness that can only
        say "passed" or "failed" will say "passed" on evidence too thin to support
        it. `INSUFFICIENT` exists so that "the strategy made money in 4 of 5
        ten-day windows" is reported as what it is — not evidence.
        """
        if self.n_folds == 0:
            return "INSUFFICIENT", "no folds could be formed from the available history"

        if self.halted_folds * 2 > self.n_folds:
            return "INSUFFICIENT", (
                f"the kill-switch fired in {self.halted_folds} of {self.n_folds} folds; a halted "
                f"book is flat, so those folds measure the risk limits, not the strategy"
            )

        thin: list[str] = []
        if self.n_folds < min_folds:
            thin.append(f"only {self.n_folds} folds (need >= {min_folds})")
        if self.oos_days < min_oos_days:
            thin.append(f"{self.oos_days:.0f} out-of-sample days (need >= {min_oos_days:.0f})")
        if self.halted_folds:
            thin.append(f"kill-switch fired in {self.halted_folds} fold(s)")

        if self.median_sharpe <= 0 or self.mean_return <= 0 or self.win_rate < 0.5:
            return "FAILED", (
                f"median fold Sharpe {self.median_sharpe:.2f}, mean fold return "
                f"{self.mean_return:.2%}, win rate {self.win_rate:.0%} — the edge does not "
                f"survive out of sample"
            )
        if thin:
            return "INSUFFICIENT", (
                f"{self.win_rate:.0%} of folds profitable, but " + " and ".join(thin) +
                f"; t-stat {self.t_stat:.2f}. This is consistent with luck."
            )
        if self.win_rate < min_win_rate:
            return "FAILED", f"win rate {self.win_rate:.0%} below the {min_win_rate:.0%} bar"
        if self.t_stat < min_t:
            return "FAILED", (
                f"mean fold return is not distinguishable from zero (t = {self.t_stat:.2f} < {min_t})"
            )
        return "CERTIFIED", (
            f"{self.win_rate:.0%} of {self.n_folds} folds profitable over {self.oos_days:.0f} "
            f"out-of-sample days, median Sharpe {self.median_sharpe:.2f}, t = {self.t_stat:.2f}"
        )


def walk_forward(
    settings: Settings,
    *,
    train_bars: int,
    test_bars: int,
    symbols: list[str] | None = None,
    interval: str | None = None,
    params: dict | None = None,
    optimize: bool = True,
    param_grid: list[dict] | None = None,
) -> WalkForwardReport:
    """Anchored walk-forward evaluation, optionally with in-sample re-optimisation.

    The training window is anchored at the start of history and the test window
    slides forward in disjoint `test_bars` chunks. When `optimize` is set, the
    strategy parameters for each fold are chosen by maximising the **in-sample**
    Sharpe on that fold's training data only; the test window is then evaluated
    with those frozen parameters. A parameter set that only works because it was
    chosen with hindsight therefore shows up as a losing fold, which is the entire
    purpose of the exercise.

    For every fold the backtest is run over `[0, test_end)` and only the trailing
    `test_bars` are scored — so the test slice is always preceded by exactly the
    history the strategy was allowed to see.
    """
    panels, fundings = load_panels(settings, symbols, interval)
    interval = interval or settings.data.interval
    grid = (param_grid if param_grid is not None else DEFAULT_PARAM_GRID) if optimize else [params or {}]

    reference = next(iter(panels.values()))
    total = len(reference)
    rows: list[dict] = []
    selections: list[dict] = []
    fold = 0
    start = 0

    while start + train_bars + test_bars <= total:
        test_start = start + train_bars
        test_end = test_start + test_bars
        end_ts = int(reference["ts"].iloc[test_end - 1])
        sliced_panels = {s: d.iloc[:test_end].reset_index(drop=True) for s, d in panels.items()}
        sliced_fundings = {s: d[d["ts"] <= end_ts] for s, d in fundings.items()}

        best_score = -np.inf
        best_run = None
        best_key: dict = {}
        for candidate in grid:
            merged = {**(params or {}), **candidate}
            run = run_backtest(
                settings,
                interval=interval,
                panels=sliced_panels,
                fundings=sliced_fundings,
                params=merged,
            )
            # Score strictly on the training slice, which ends where the test begins.
            train_equity = run.result.equity_curve.iloc[:test_start]
            if len(train_equity) < 30:
                continue
            score = metrics.sharpe(
                train_equity.pct_change().dropna(), bars_per_year(interval)
            )
            if score > best_score:
                best_score = score
                best_run = run
                best_key = candidate
        if best_run is None:
            break

        # The test window is this fold's out-of-sample slice. Slicing from
        # `train_bars` to the end (the obvious-looking thing) makes every fold
        # cumulative: fold k re-reports folds 0..k, returns march upward and the
        # report looks like a strategy that never loses. Disjoint windows only.
        equity = best_run.result.equity_curve.iloc[test_start:test_end]
        if len(equity) < 2:
            break
        segment = equity / float(equity.iloc[0])
        rows.append(
            {
                "fold": fold,
                "start": equity.index[0],
                "end": equity.index[-1],
                "test_return": float(segment.iloc[-1] - 1.0),
                "test_max_dd": metrics.max_drawdown(segment),
                "test_sharpe": metrics.sharpe(segment.pct_change().dropna(), bars_per_year(interval)),
                "train_sharpe": float(best_score),
                "halted": best_run.result.halted_at is not None,
            }
        )
        selections.append({"fold": fold, **best_key})
        fold += 1
        start += test_bars

    return WalkForwardReport(
        folds=pd.DataFrame(rows),
        selected_params=pd.DataFrame(selections),
        train_bars=train_bars,
        test_bars=test_bars,
        interval=interval,
        optimized=optimize,
    )
