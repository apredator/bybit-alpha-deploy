"""bybit-alpha — a systematic trading agent for Bybit USDT perpetuals.

Layers (each one independently testable):

    data/       market data ingestion + local parquet store
    features/   technical/statistical feature engineering
    strategy/   signal generation (target position per symbol)
    risk/       position sizing, exposure limits, kill-switch
    backtest/   event-driven simulator with honest cost modelling
    execution/  broker abstraction: paper + live Bybit V5
    live/       the agent loop wiring everything together
"""

__version__ = "0.1.0"
