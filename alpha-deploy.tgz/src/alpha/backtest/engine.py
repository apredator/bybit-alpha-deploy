"""Event-driven backtester for Bybit USDT perpetuals.

What makes this one honest
--------------------------
* **No lookahead.** Features are computed on bar `t`'s close; orders are filled
  at bar `t+1`'s *open*. The loop physically cannot use a price it has not
  reached yet.
* **Costs are modelled, not wished away.** Taker fee + a slippage term that grows
  with ATR (fast markets cost more), on every fill.
* **Funding is charged.** Perpetual funding is a real cash flow every 8 hours and
  is the difference between a "profitable" and a losing carry strategy.
* **Participation cap.** An order can only be a small fraction of a bar's volume,
  so the simulator cannot fill sizes the market never offered.
* **The same risk engine as live.** Sizing, limits and the kill-switch run inside
  the loop, not as a post-processing filter.

The output is intentionally rich (equity, returns, positions, trades, funding,
risk events) because the only way to trust a backtest is to look at its guts.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from alpha.config import Settings
from alpha.log import get_logger
from alpha.portfolio import PortfolioLedger
from alpha.risk.correlation import CorrelationView
from alpha.risk.engine import MarketSnapshot, RiskEngine
from alpha.risk.sizing import InstrumentSpec

log = get_logger("alpha.backtest")

FUNDING_INTERVAL_MS = 8 * 3_600_000
_EPS = 1e-12


@dataclass
class BacktestResult:
    equity_curve: pd.Series
    returns: pd.Series
    positions: pd.DataFrame
    weights: pd.DataFrame
    trades: pd.DataFrame
    funding_pnl: pd.Series
    fees_paid: float
    funding_paid: float
    turnover: float
    risk_events: list[str] = field(default_factory=list)
    halted_at: int | None = None
    initial_equity: float = 10_000.0

    @property
    def final_equity(self) -> float:
        return float(self.equity_curve.iloc[-1]) if len(self.equity_curve) else self.initial_equity


class BacktestEngine:
    def __init__(self, settings: Settings, specs: dict[str, InstrumentSpec] | None = None) -> None:
        self.settings = settings
        self.costs = settings.costs
        self.specs = specs or {}
        self.risk = RiskEngine(settings.risk, specs=specs)

    # ------------------------------------------------------------------- run
    def run(
        self,
        weights: pd.DataFrame,
        features: dict[str, pd.DataFrame],
        *,
        warmup_bars: int | None = None,
    ) -> BacktestResult:
        if weights.empty:
            raise ValueError("empty weight matrix — nothing to simulate")

        symbols = [s for s in weights.columns if s in features]
        if not symbols:
            raise ValueError("no symbol in the weight matrix has features")

        master = np.asarray(sorted(weights.index.unique()), dtype=np.int64)
        n = len(master)
        warmup = warmup_bars if warmup_bars is not None else int(
            self.settings.strategy.params.get("warmup_bars", 250)
        )

        # Align everything onto the master clock once, as numpy arrays.
        data: dict[str, dict[str, np.ndarray]] = {}
        for sym in symbols:
            f = features[sym].set_index("ts").reindex(master)
            data[sym] = {
                "open": f["open"].to_numpy(dtype=float),
                "close": f["close"].to_numpy(dtype=float),
                "atr": f["atr"].to_numpy(dtype=float),
                "atr_pct": f["atr_pct"].to_numpy(dtype=float),
                "vol": f["vol"].to_numpy(dtype=float),
                "volume": f["volume"].to_numpy(dtype=float),
                "funding_rate": f.get("funding_rate", pd.Series(0.0, index=f.index)).to_numpy(dtype=float),
            }

        wmat = weights.reindex(master).reindex(columns=symbols).fillna(0.0)
        warr = wmat.to_numpy(dtype=float)

        # Log-return matrix, used for a strictly-past correlation estimate. The
        # correlation matrix is what makes portfolio-level vol targeting possible,
        # and it must be built only from bars that have already closed.
        ret_matrix = np.full((n, len(symbols)), np.nan, dtype=float)
        for j, sym in enumerate(symbols):
            close = data[sym]["close"]
            with np.errstate(divide="ignore", invalid="ignore"):
                prev = np.roll(close, 1)
                prev[0] = np.nan
                ret_matrix[:, j] = np.where(
                    (close > 0) & (prev > 0) & np.isfinite(prev), np.log(close / prev), np.nan
                )
        corr_cache: CorrelationView | None = None
        corr_refresh = max(1, int(self.settings.risk.corr_refresh_bars))
        corr_lookback = max(60, int(self.settings.risk.corr_lookback_bars))

        book = PortfolioLedger(cash=float(self.settings.risk.initial_equity))
        equity_hist = np.zeros(n, dtype=float)
        funding_hist = np.zeros(n, dtype=float)
        pos_hist = np.zeros((n, len(symbols)), dtype=float)
        weight_hist = np.zeros((n, len(symbols)), dtype=float)

        trades: list[dict] = []
        risk_events: list[str] = []
        halted_at: int | None = None
        fees_total = 0.0
        funding_total = 0.0
        turnover = 0.0

        pending: dict[str, float] = {}
        slip_base_bps = self.costs.slippage_bps
        slip_atr_mult = self.costs.slippage_atr_mult
        fee_bps = self.costs.taker_fee_bps
        initial = float(self.settings.risk.initial_equity)

        for i in range(n):
            ts = int(master[i])

            # ---- 1. Execute orders decided on the previous bar, at this bar's open.
            for sym, target in pending.items():
                d = data[sym]
                px = d["open"][i]
                if not np.isfinite(px) or px <= 0:
                    continue
                held = book.positions[sym].qty if sym in book.positions else 0.0
                delta = target - held
                spec = self.specs.get(sym) or InstrumentSpec(symbol=sym)
                # Re-check at the actual fill price: the exchange's min-notional
                # rule applies to the fill, not to the intent.
                if abs(delta) * px < max(self.settings.risk.min_order_notional, spec.min_notional):
                    continue
                delta = spec.normalise(delta, px)
                if delta == 0.0:
                    continue

                atr_pct = d["atr_pct"][i]
                slip_bps = slip_base_bps + (
                    slip_atr_mult * atr_pct * 1e4 if np.isfinite(atr_pct) else 0.0
                )
                slip = slip_bps / 1e4
                fill_px = px * (1.0 + slip) if delta > 0 else px * (1.0 - slip)
                notional = abs(delta) * fill_px
                fee = notional * fee_bps / 1e4
                book.apply_fill(sym, delta, fill_px, fee)
                fees_total += fee
                turnover += notional
                trades.append(
                    {
                        "ts": ts,
                        "symbol": sym,
                        "qty": delta,
                        "price": fill_px,
                        "notional": notional,
                        "fee": fee,
                        "slippage_bps": slip_bps,
                        "side": "Buy" if delta > 0 else "Sell",
                    }
                )
            pending.clear()

            # ---- 2. Funding. `funding_rate` is the sum of settlements that fell
            # inside this bar, so this works for 1h/2h/4h/8h schedules alike.
            if self.costs.funding_enabled:
                for sym in symbols:
                    d = data[sym]
                    rate = d["funding_rate"][i]
                    if not np.isfinite(rate) or rate == 0.0:
                        continue
                    px = d["open"][i] if np.isfinite(d["open"][i]) else d["close"][i]
                    if not np.isfinite(px) or px <= 0:
                        continue
                    paid = book.apply_funding(sym, float(rate), float(px))
                    if paid != 0.0:
                        funding_total += paid
                        funding_hist[i] += paid

            # ---- 3. Mark to market at this bar's close.
            marks = {
                sym: float(data[sym]["close"][i])
                for sym in symbols
                if np.isfinite(data[sym]["close"][i])
            }
            equity = book.equity(marks)
            equity_hist[i] = equity
            for j, sym in enumerate(symbols):
                pos_hist[i, j] = book.positions[sym].qty if sym in book.positions else 0.0

            # ---- 4. Decide targets for this bar (features are known at its close).
            if i < warmup or i == n - 1:
                continue

            market = {
                sym: MarketSnapshot(
                    symbol=sym,
                    price=marks.get(sym, 0.0),
                    vol=float(data[sym]["vol"][i]) if np.isfinite(data[sym]["vol"][i]) else 0.0,
                    atr=float(data[sym]["atr"][i]) if np.isfinite(data[sym]["atr"][i]) else 0.0,
                    dollar_volume=float(data[sym]["volume"][i]) * marks.get(sym, 0.0),
                )
                for sym in symbols
                if np.isfinite(marks.get(sym, np.nan))
            }
            current_qty = {
                sym: (book.positions[sym].qty if sym in book.positions else 0.0) for sym in symbols
            }
            intended = {sym: float(warr[i, j]) for j, sym in enumerate(symbols)}

            # Correlations move slowly and are expensive to estimate, so refresh
            # them periodically. The window ends at bar i-1: bar i's return is not
            # known at decision time and must never enter the estimate.
            if i >= corr_lookback and (i - warmup) % corr_refresh == 0:
                window = ret_matrix[i - corr_lookback : i]
                if window.shape[0] >= 60 and len(symbols) >= 2:
                    corr_cache = CorrelationView.from_frame(
                        pd.DataFrame(window, columns=symbols).corr()
                    )

            decision = self.risk.evaluate(
                ts=ts,
                equity=equity,
                weights=intended,
                market=market,
                current_qty=current_qty,
                corr=corr_cache,
                last_data_ts=ts,
            )
            if decision.flattened and halted_at is None:
                halted_at = ts
                risk_events.append(f"{pd.to_datetime(ts, unit='ms', utc=True)}: {', '.join(decision.notes)}")
            elif decision.notes and halted_at is None:
                risk_events.extend(
                    f"{pd.to_datetime(ts, unit='ms', utc=True)}: {note}" for note in decision.notes[:2]
                )

            for j, sym in enumerate(symbols):
                weight_hist[i, j] = decision.target_weights.get(sym, 0.0)
                target = decision.target_qty.get(sym, current_qty[sym])
                if self.risk.needs_rebalance(
                    sym, target, current_qty[sym], marks.get(sym, 0.0), equity,
                    force=decision.flattened,
                ):
                    pending[sym] = target

        index = pd.to_datetime(master, unit="ms", utc=True)
        equity_series = pd.Series(equity_hist, index=index, name="equity")
        rets = (equity_series / equity_series.shift(1) - 1.0).fillna(0.0)
        if initial:
            rets.iloc[0] = equity_hist[0] / initial - 1.0

        positions_df = pd.DataFrame(pos_hist, index=index, columns=symbols)
        weights_df = pd.DataFrame(weight_hist, index=index, columns=symbols)
        trades_df = pd.DataFrame(trades)

        log.info(
            "backtest complete",
            extra={
                "extra_fields": {
                    "bars": n,
                    "symbols": len(symbols),
                    "trades": len(trades),
                    "final_equity": round(float(equity_series.iloc[-1]), 2),
                    "fees": round(fees_total, 2),
                    "funding": round(funding_total, 2),
                }
            },
        )

        return BacktestResult(
            equity_curve=equity_series,
            returns=rets,
            positions=positions_df,
            weights=weights_df,
            trades=trades_df,
            funding_pnl=pd.Series(funding_hist, index=index, name="funding"),
            fees_paid=fees_total,
            funding_paid=funding_total,
            turnover=turnover,
            risk_events=risk_events,
            halted_at=halted_at,
            initial_equity=initial,
        )
