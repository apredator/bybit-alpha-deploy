"""Tearsheet generation.

A backtest is not a number, it is a shape. These plots exist to make the failure
modes visible at a glance:

  * an equity curve that is one lucky step (a single regime, not an edge),
  * a drawdown that is deeper than the summary implies,
  * a rolling Sharpe that is positive only in one window,
  * gross exposure that drifts to the leverage cap and stays there.

Matplotlib is used with the Agg backend so this runs headless in CI.
"""

from __future__ import annotations

import os
from pathlib import Path

# Keep matplotlib's cache inside the project: the default (~/.matplotlib) is often
# read-only in containers and CI, which produces noisy warnings on every run.
os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parents[2] / ".mplcache"))

import matplotlib  # noqa: E402

matplotlib.use("Agg")

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from alpha.backtest.engine import BacktestResult  # noqa: E402
from alpha.backtest.metrics import drawdown_series  # noqa: E402
from alpha.features.indicators import bars_per_year  # noqa: E402


def rolling_sharpe(returns: pd.Series, window: int, interval: str) -> pd.Series:
    bpy = bars_per_year(interval)
    mean = returns.rolling(window, min_periods=max(20, window // 4)).mean()
    std = returns.rolling(window, min_periods=max(20, window // 4)).std(ddof=1)
    return (mean / std.replace(0.0, np.nan)) * np.sqrt(bpy)


def plot_tearsheet(
    result: BacktestResult,
    path: str | Path,
    *,
    interval: str = "60",
    title: str = "bybit-alpha backtest",
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    equity = result.equity_curve
    returns = result.returns
    dd = drawdown_series(equity)
    rs = rolling_sharpe(returns, int(24 * 30), interval)  # ~30 days at hourly bars
    gross = result.weights.abs().sum(axis=1)

    fig, axes = plt.subplots(4, 1, figsize=(12, 13), sharex=True)

    axes[0].plot(equity.index, equity.to_numpy(), lw=1.4, color="#1f77b4")
    axes[0].set_yscale("log")
    axes[0].set_title(f"{title} — equity (log scale)", loc="left", fontsize=11)
    axes[0].grid(alpha=0.25)

    axes[1].fill_between(dd.index, -dd.to_numpy() * 100, 0, color="#d62728", alpha=0.55)
    axes[1].set_title("drawdown (%)", loc="left", fontsize=11)
    axes[1].grid(alpha=0.25)

    axes[2].plot(rs.index, rs.to_numpy(), lw=1.1, color="#2ca02c")
    axes[2].axhline(0, color="black", lw=0.7)
    axes[2].axhline(1, color="grey", lw=0.7, ls="--")
    axes[2].set_title("rolling 30d Sharpe (annualised)", loc="left", fontsize=11)
    axes[2].grid(alpha=0.25)

    for col in result.weights.columns:
        axes[3].plot(result.weights.index, result.weights[col].to_numpy(), lw=0.9, label=col)
    axes[3].plot(gross.index, gross.to_numpy(), lw=1.4, color="black", label="gross")
    axes[3].set_title("target weights and gross exposure", loc="left", fontsize=11)
    axes[3].legend(loc="upper left", fontsize=8, ncol=4)
    axes[3].grid(alpha=0.25)

    fig.tight_layout()
    fig.savefig(path, dpi=110)
    plt.close(fig)
    return path


def equity_to_frame(result: BacktestResult) -> pd.DataFrame:
    """Flat export of everything a reviewer needs to audit a run."""
    frame = pd.DataFrame(
        {
            "equity": result.equity_curve,
            "drawdown": drawdown_series(result.equity_curve),
            "funding": result.funding_pnl.reindex(result.equity_curve.index).fillna(0.0),
        }
    )
    frame = frame.join(result.weights.add_prefix("w_"))
    frame = frame.join(result.positions.add_prefix("qty_"))
    return frame
