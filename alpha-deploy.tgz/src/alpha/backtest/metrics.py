"""Performance and risk metrics.

Every number here is computed from an equity curve plus a bar frequency, with no
hidden annualisation assumptions. Two deliberate choices:

* **Sortino uses downside deviation**, not total vol — traders care about the
  left tail, and a strategy that only goes up should not be penalised for it.
* **Max drawdown is reported with its duration**, because a 15% drawdown that
  lasted two days and one that lasted eight months are different products.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from alpha.features.indicators import bars_per_year


def _ann_factor(bars_per_year_value: float) -> float:
    return float(np.sqrt(bars_per_year_value))


def total_return(equity: pd.Series) -> float:
    if len(equity) < 2:
        return 0.0
    return float(equity.iloc[-1] / equity.iloc[0] - 1.0)


def cagr(equity: pd.Series, bars_per_year_value: float) -> float:
    n = len(equity)
    if n < 2 or equity.iloc[0] <= 0:
        return 0.0
    years = n / bars_per_year_value
    if years <= 0:
        return 0.0
    growth = equity.iloc[-1] / equity.iloc[0]
    if growth <= 0:
        return -1.0
    return float(growth ** (1.0 / years) - 1.0)


def sharpe(returns: pd.Series, bars_per_year_value: float, rf: float = 0.0) -> float:
    r = returns.to_numpy(dtype=float)
    r = r[np.isfinite(r)]
    if len(r) < 2:
        return 0.0
    excess = r - rf / bars_per_year_value
    mean = float(excess.mean())
    sd = float(excess.std(ddof=1))
    # Floating-point residue: std of a genuinely constant series is ~1e-18, not 0.
    # A bare `sd <= 0` check lets that residue through and produces either a
    # meaningless 1e17 or a spurious 0.0 depending on rounding. A monotone equity
    # curve has zero volatility and a positive mean, so its Sharpe is +inf — the
    # same convention `sortino` already uses for a missing downside.
    if not np.isfinite(sd) or sd <= 1e-12 * max(abs(mean), 1.0):
        return float("inf") if mean > 0 else 0.0
    return float(mean / sd * _ann_factor(bars_per_year_value))


def sortino(returns: pd.Series, bars_per_year_value: float) -> float:
    r = returns.to_numpy(dtype=float)
    r = r[np.isfinite(r)]
    if len(r) < 2:
        return 0.0
    downside = r[r < 0]
    if len(downside) == 0:
        return float("inf") if r.mean() > 0 else 0.0
    dd = np.sqrt((downside**2).mean())
    if dd <= 0:
        return 0.0
    return float(r.mean() / dd * _ann_factor(bars_per_year_value))


def max_drawdown(equity: pd.Series) -> float:
    if len(equity) < 2:
        return 0.0
    peak = equity.cummax()
    dd = 1.0 - equity / peak
    return float(dd.max())


def drawdown_series(equity: pd.Series) -> pd.Series:
    peak = equity.cummax()
    return 1.0 - equity / peak


def drawdown_duration_bars(equity: pd.Series) -> int:
    """Longest stretch (in bars) spent below a previous peak."""
    peak = equity.cummax()
    underwater = equity < peak * (1 - 1e-12)
    longest = current = 0
    for flag in underwater.to_numpy():
        current = current + 1 if flag else 0
        longest = max(longest, current)
    return int(longest)


def calmar(equity: pd.Series, bars_per_year_value: float) -> float:
    mdd = max_drawdown(equity)
    if mdd <= 0:
        return 0.0
    return float(cagr(equity, bars_per_year_value) / mdd)


def value_at_risk(returns: pd.Series, level: float = 0.05) -> float:
    r = returns.to_numpy(dtype=float)
    r = r[np.isfinite(r)]
    if len(r) < 20:
        return 0.0
    return float(np.quantile(r, level))


def expected_shortfall(returns: pd.Series, level: float = 0.05) -> float:
    r = returns.to_numpy(dtype=float)
    r = r[np.isfinite(r)]
    if len(r) < 20:
        return 0.0
    var = np.quantile(r, level)
    tail = r[r <= var]
    return float(tail.mean()) if len(tail) else 0.0


def profit_factor(trades: pd.DataFrame, pnl_column: str = "pnl") -> float:
    if trades.empty or pnl_column not in trades:
        return 0.0
    pnl = trades[pnl_column].to_numpy(dtype=float)
    gains = pnl[pnl > 0].sum()
    losses = -pnl[pnl < 0].sum()
    if losses <= 0:
        return float("inf") if gains > 0 else 0.0
    return float(gains / losses)


def hit_rate(trades: pd.DataFrame, pnl_column: str = "pnl") -> float:
    if trades.empty or pnl_column not in trades:
        return 0.0
    pnl = trades[pnl_column].to_numpy(dtype=float)
    pnl = pnl[np.isfinite(pnl)]
    if len(pnl) == 0:
        return 0.0
    return float((pnl > 0).mean())


def ulcer_index(equity: pd.Series) -> float:
    """RMS drawdown — penalises deep *and* long drawdowns in one number."""
    dd = drawdown_series(equity)
    if dd.empty:
        return 0.0
    return float(np.sqrt((dd**2).mean()))


def tail_ratio(returns: pd.Series) -> float:
    r = returns.to_numpy(dtype=float)
    r = r[np.isfinite(r)]
    if len(r) < 20:
        return 0.0
    q95, q05 = np.quantile(r, 0.95), np.quantile(r, 0.05)
    if abs(q05) < 1e-12:
        return 0.0
    return float(abs(q95 / q05))


def summarize(
    equity: pd.Series,
    returns: pd.Series,
    *,
    interval: str = "60",
    trades: pd.DataFrame | None = None,
    risk_free: float = 0.0,
) -> dict[str, float]:
    bpy = bars_per_year(interval)
    trades = trades if trades is not None else pd.DataFrame()
    out = {
        "initial_equity": float(equity.iloc[0]) if len(equity) else 0.0,
        "final_equity": float(equity.iloc[-1]) if len(equity) else 0.0,
        "total_return": total_return(equity),
        "cagr": cagr(equity, bpy),
        "sharpe": sharpe(returns, bpy, risk_free),
        "sortino": sortino(returns, bpy),
        "max_drawdown": max_drawdown(equity),
        "max_dd_duration_bars": float(drawdown_duration_bars(equity)),
        "calmar": calmar(equity, bpy),
        "annual_vol": float(returns.std(ddof=1) * _ann_factor(bpy)) if len(returns) > 2 else 0.0,
        "var_95": value_at_risk(returns, 0.05),
        "es_95": expected_shortfall(returns, 0.05),
        "tail_ratio": tail_ratio(returns),
        "ulcer_index": ulcer_index(equity),
        "bars": float(len(equity)),
    }
    if not trades.empty and "fee" in trades:
        out["trades"] = float(len(trades))
        out["fees_total"] = float(trades["fee"].sum())
        out["turnover"] = float(trades["notional"].sum()) if "notional" in trades else 0.0
    return out


def format_summary(metrics: dict[str, float]) -> str:
    pct = {
        "total_return", "cagr", "max_drawdown", "annual_vol", "var_95", "es_95",
    }
    lines = []
    for key, value in metrics.items():
        if key in pct:
            lines.append(f"  {key:<22} {value * 100:>10.2f}%")
        elif key == "max_dd_duration_bars" or key == "bars":
            lines.append(f"  {key:<22} {value:>11.0f}")
        elif key in ("trades", "fees_total", "turnover", "initial_equity", "final_equity"):
            lines.append(f"  {key:<22} {value:>11,.2f}")
        else:
            lines.append(f"  {key:<22} {value:>11.3f}")
    return "\n".join(lines)
