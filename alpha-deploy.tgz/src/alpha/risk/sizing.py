"""Position sizing.

The core idea, stated once so every other file can stay quiet about it:

    A strategy says **direction and relative conviction**.
    Sizing says **how much risk that conviction is worth**.

Risk is measured in currency per unit of time, not in contracts. Two symbols
with the same weight but different volatility are *not* the same bet, so the
conversion from weight to contracts always passes through a volatility estimate.

The vol-target formula is the standard one::

    scale = target_vol / realised_vol

with `realised_vol` floored, because dividing by a near-zero volatility estimate
is how a quiet Sunday turns into a 40x position on Monday.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

VOL_FLOOR = 0.05  # 5% annualised — below this, an estimate is noise, not information


@dataclass(frozen=True, slots=True)
class InstrumentSpec:
    """Exchange contract metadata. Defaults describe a 1x linear perp."""

    symbol: str
    qty_step: float = 0.001
    min_qty: float = 0.001
    max_qty: float = 1_000_000.0
    min_notional: float = 5.0
    contract_size: float = 1.0
    max_leverage: float = 25.0

    def round_qty(self, qty: float) -> float:
        """Round *toward zero* to the exchange step — never round up a position."""
        if self.qty_step <= 0:
            return qty
        steps = math.floor(abs(qty) / self.qty_step + 1e-9)
        return math.copysign(steps * self.qty_step, qty)

    def normalise(self, qty: float, price: float) -> float:
        """Apply step, min size and min notional. Returns 0.0 if untradeable."""
        q = self.round_qty(qty)
        if abs(q) < self.min_qty:
            return 0.0
        if abs(q) * price < max(self.min_notional, 1e-9):
            return 0.0
        return math.copysign(min(abs(q), self.max_qty), q)


def vol_target_scale(
    realised_vol: float,
    target_vol: float,
    *,
    risk_scale: float = 1.0,
    max_scale: float = 3.0,
) -> float:
    """Multiplier that converts a unit-weight signal into a vol-targeted weight."""
    if not math.isfinite(realised_vol) or realised_vol <= 0:
        return 0.0
    effective_vol = max(realised_vol, VOL_FLOOR)
    raw = target_vol / effective_vol
    return max(0.0, min(raw, max_scale)) * risk_scale


def weight_to_qty(
    weight: float,
    equity: float,
    price: float,
    spec: InstrumentSpec,
    *,
    contract_size: float | None = None,
) -> float:
    """Signed contract quantity for a target weight of equity."""
    if price <= 0 or equity <= 0 or not math.isfinite(weight):
        return 0.0
    cs = contract_size if contract_size is not None else spec.contract_size
    notional = weight * equity
    qty = notional / (price * cs)
    return spec.normalise(qty, price)


def kelly_fraction(win_rate: float, payoff_ratio: float, cap: float = 0.25) -> float:
    """Fractional Kelly, hard-capped.

    Full Kelly is optimal only if your edge estimate is exact — it never is.
    Quarter-Kelly costs ~25% of growth and removes most of the ruin path, which
    is the correct trade for anyone who wants to still be trading next year.
    """
    if payoff_ratio <= 0 or not (0.0 < win_rate < 1.0):
        return 0.0
    f = win_rate - (1.0 - win_rate) / payoff_ratio
    return max(0.0, min(f, cap))


def participation_cap(
    desired_qty: float, bar_dollar_volume: float, max_participation: float, price: float
) -> float:
    """Never let our order be more than `max_participation` of a bar's volume.

    Ignoring this is why backtests show fills that could never have happened:
    you are modelling yourself as the entire market.
    """
    if price <= 0 or bar_dollar_volume <= 0:
        return desired_qty
    max_notional = bar_dollar_volume * max_participation
    max_qty = max_notional / price
    if abs(desired_qty) <= max_qty:
        return desired_qty
    return math.copysign(max_qty, desired_qty)
