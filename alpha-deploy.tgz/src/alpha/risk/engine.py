"""The risk engine: the single gate every intended trade must pass through.

Pipeline per decision cycle::

    strategy weights
        -> vol targeting      (equalise risk across symbols)
        -> exposure limits    (cap leverage, net, concentration, correlation)
        -> kill-switch        (override everything, including flattening)
        -> contract sizing    (weights -> exchange quantities)
        -> participation cap  (do not become the market)
        -> rebalance filter   (skip trades too small to survive fees)

Nothing downstream of this file makes sizing decisions, and nothing upstream can
bypass it. If you change one thing about this codebase to make it more robust,
change this file.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from alpha.config import RiskConfig
from alpha.risk.correlation import CorrelationView, as_view
from alpha.risk.killswitch import KillSwitch, RiskState
from alpha.risk.limits import ExposureLimits
from alpha.risk.sizing import InstrumentSpec, participation_cap, vol_target_scale, weight_to_qty


@dataclass(frozen=True, slots=True)
class MarketSnapshot:
    symbol: str
    price: float
    vol: float  # annualised realised volatility
    atr: float = 0.0
    dollar_volume: float = 0.0


@dataclass
class RiskDecision:
    ts: int
    target_weights: dict[str, float] = field(default_factory=dict)
    target_qty: dict[str, float] = field(default_factory=dict)
    scale: float = 1.0
    state: RiskState = RiskState.ACTIVE
    notes: list[str] = field(default_factory=list)
    flattened: bool = False

    @property
    def gross(self) -> float:
        return sum(abs(w) for w in self.target_weights.values())

    @property
    def net(self) -> float:
        return sum(self.target_weights.values())


class RiskEngine:
    def __init__(
        self,
        cfg: RiskConfig,
        *,
        specs: dict[str, InstrumentSpec] | None = None,
        limits: ExposureLimits | None = None,
        kill_switch: KillSwitch | None = None,
    ) -> None:
        self.cfg = cfg
        self.specs = specs or {}
        self.limits = limits or ExposureLimits(
            max_gross_leverage=cfg.max_gross_leverage,
            max_net_exposure=cfg.max_net_exposure,
            max_symbol_weight=cfg.max_symbol_weight,
            max_concurrent_positions=cfg.max_concurrent_positions,
        )
        self.kill_switch = kill_switch or KillSwitch(
            max_drawdown=cfg.max_drawdown_kill,
            target_annual_vol=cfg.target_annual_vol,
            daily_loss_sigmas=cfg.daily_loss_sigmas,
            daily_loss_limit=cfg.daily_loss_limit,
            rolling_loss_sigmas=cfg.rolling_loss_sigmas,
            rolling_loss_limit=cfg.rolling_loss_limit,
            rolling_loss_days=cfg.rolling_loss_days,
            max_data_staleness_s=cfg.max_data_staleness_s,
            reduce_at_drawdown=cfg.reduce_at_drawdown,
        )

    def spec(self, symbol: str) -> InstrumentSpec:
        return self.specs.get(symbol) or InstrumentSpec(symbol=symbol)

    # ------------------------------------------------------------------ main
    def evaluate(
        self,
        *,
        ts: int,
        equity: float,
        weights: dict[str, float],
        market: dict[str, MarketSnapshot],
        current_qty: dict[str, float] | None = None,
        returns: pd.DataFrame | None = None,
        corr: CorrelationView | pd.DataFrame | None = None,
        last_data_ts: int | None = None,
    ) -> RiskDecision:
        current_qty = current_qty or {}
        notes: list[str] = []

        self.kill_switch.update_equity(equity, ts)
        state, risk_mult, ks_reasons = self.kill_switch.evaluate(ts, last_data_ts=last_data_ts)
        notes.extend(ks_reasons)

        if state is RiskState.HALTED:
            # Flatten everything. This is the one place that ignores strategy intent
            # completely, and it must.
            flat = {s: 0.0 for s in set(weights) | set(current_qty)}
            return RiskDecision(
                ts=ts,
                target_weights=flat,
                target_qty=dict.fromkeys(flat, 0.0),
                scale=0.0,
                state=state,
                notes=notes,
                flattened=True,
            )

        # 1) Vol targeting — this is where "weight" becomes "risk".
        vol_scaled: dict[str, float] = {}
        for symbol, weight in weights.items():
            snap = market.get(symbol)
            if snap is None:
                notes.append(f"{symbol}: no market snapshot, skipped")
                continue
            k = vol_target_scale(
                snap.vol,
                self.cfg.target_annual_vol,
                risk_scale=self.cfg.risk_scale * risk_mult,
                max_scale=max(1.0, self.cfg.max_gross_leverage),
            )
            vol_scaled[symbol] = weight * k
        if risk_mult < 1.0:
            notes.append(f"kill-switch de-risking multiplier {risk_mult:.2f}")

        # 2) Portfolio limits.
        report = self.limits.apply(
            vol_scaled, corr=corr, vol={s: m.vol for s, m in market.items()}
        )
        notes.extend(report.adjustments)
        approved = report.weights

        # 2b) Target *portfolio* volatility, not each asset in isolation.
        #
        # Per-asset vol scaling is only correct if the assets are uncorrelated.
        # On a cross-sectionally demeaned book it is badly wrong: hedging removes
        # most of the risk the per-asset step measured, so the realised portfolio
        # vol lands far below target — a book claiming a 25% target running at 5%
        # is not "safe", it is mis-specified, and its Sharpe looks inflated because
        # the denominator is an accident rather than a choice.
        if self.cfg.scale_to_target_vol and approved:
            vols = {s: market[s].vol for s in approved if s in market}
            ex_ante = self.portfolio_vol(approved, vols, corr)
            if ex_ante > 1e-6:
                k = min(self.cfg.target_annual_vol / ex_ante, self.cfg.max_portfolio_scale)
                if abs(k - 1.0) > 0.01:
                    approved = {s: v * k for s, v in approved.items()}
                    notes.append(
                        f"portfolio vol {ex_ante:.1%} -> {ex_ante * k:.1%} (x{k:.2f})"
                    )
                    # Scaling up can breach the hard limits, so re-apply them.
                    gross = sum(abs(v) for v in approved.values())
                    if gross > self.cfg.max_gross_leverage > 0:
                        shrink = self.cfg.max_gross_leverage / gross
                        approved = {s: v * shrink for s, v in approved.items()}
                        notes.append(
                            f"gross re-capped {gross:.2f} -> {self.cfg.max_gross_leverage:.2f}"
                        )

        # 3) Weights -> contracts, then participation cap on the *delta* only.
        target_qty: dict[str, float] = {}
        for symbol in set(approved) | set(current_qty):
            snap = market.get(symbol)
            if snap is None or snap.price <= 0:
                target_qty[symbol] = current_qty.get(symbol, 0.0)
                continue
            spec = self.spec(symbol)
            desired = weight_to_qty(approved.get(symbol, 0.0), equity, snap.price, spec)
            held = current_qty.get(symbol, 0.0)
            delta = desired - held
            if snap.dollar_volume > 0:
                delta = participation_cap(
                    delta, snap.dollar_volume, self.cfg.max_participation, snap.price
                )
            target_qty[symbol] = held + delta

        return RiskDecision(
            ts=ts,
            target_weights=approved,
            target_qty=target_qty,
            scale=risk_mult,
            state=state,
            notes=notes,
        )

    # --------------------------------------------------------------- helpers
    def needs_rebalance(
        self,
        symbol: str,
        target_qty: float,
        current_qty: float,
        price: float,
        equity: float,
        *,
        force: bool = False,
    ) -> bool:
        """Gate tiny trades: they pay full fees and move the needle by nothing.

        The threshold is a fraction of the **position**, not of equity. Comparing
        the adjustment to total equity is the intuitive thing to write and it is
        wrong for any book running below full investment: a $600 position on
        $10,000 of equity rebalances on a $200 move — a third of itself — so a
        modest book churns constantly and pays fees for nothing. Scaling the
        threshold to the position makes the rule size-invariant, which is what
        "don't trade for nothing" actually means.
        """
        if force:
            return abs(target_qty - current_qty) > 1e-12
        if price <= 0 or equity <= 0:
            return False
        delta_notional = abs(target_qty - current_qty) * price
        if delta_notional < self.cfg.min_order_notional:
            return False
        reference = max(abs(target_qty), abs(current_qty)) * price
        threshold = max(self.cfg.min_order_notional, self.cfg.rebalance_threshold * reference)
        return delta_notional >= threshold

    def stop_price(
        self, symbol: str, entry: float, direction: int, atr: float, mult: float = 3.0
    ) -> float | None:
        """ATR-based protective stop — the backstop when the signal layer lags."""
        if atr <= 0 or entry <= 0 or direction == 0:
            return None
        return float(entry - direction * mult * atr)

    @staticmethod
    def positions_to_weights(
        positions: dict[str, float], prices: dict[str, float], equity: float
    ) -> dict[str, float]:
        if equity <= 0:
            return dict.fromkeys(positions, 0.0)
        return {s: (q * prices.get(s, 0.0)) / equity for s, q in positions.items()}

    @staticmethod
    def correlation_matrix(returns: pd.DataFrame, lookback: int = 500) -> pd.DataFrame:
        if returns.empty:
            return pd.DataFrame()
        return returns.tail(lookback).corr()

    @staticmethod
    def portfolio_vol(
        weights: dict[str, float],
        vols: dict[str, float],
        corr: CorrelationView | pd.DataFrame | None = None,
    ) -> float:
        """Ex-ante annualised portfolio vol — the number that actually matters.

        `w' (D C D) w` with D = diag(vols). Integer-indexed numpy, because this
        runs on every decision bar.
        """
        syms = [s for s in weights if s in vols]
        if not syms:
            return 0.0
        w = np.fromiter((weights[s] for s in syms), dtype=float, count=len(syms))
        v = np.fromiter((vols[s] for s in syms), dtype=float, count=len(syms))
        view = as_view(corr)
        if view is None or len(syms) < 2:
            c = np.eye(len(syms))
        else:
            c = view.submatrix(syms)
            if c.shape[0] != len(syms):
                c = np.eye(len(syms))
        cov = np.outer(v, v) * c
        return float(np.sqrt(max(float(w @ cov @ w), 0.0)))
