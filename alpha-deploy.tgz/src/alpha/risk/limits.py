"""Portfolio exposure limits — the rules that survive when the model is wrong.

These are *hard* constraints applied after sizing and before any order is sent.
Each one exists because of a specific, well-documented way trading books die:

  gross leverage   -> a "diversified" book that is really one leveraged bet
  net exposure     -> accidental market beta you did not intend to hold
  per symbol       -> concentration in the one name that gaps
  max positions    -> death by a thousand small illiquid positions
  correlation      -> five alts that are all the same trade
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from alpha.risk.correlation import CorrelationView, as_view


@dataclass
class LimitReport:
    weights: dict[str, float]
    adjustments: list[str] = field(default_factory=list)

    @property
    def gross(self) -> float:
        return sum(abs(w) for w in self.weights.values())

    @property
    def net(self) -> float:
        return sum(self.weights.values())


class ExposureLimits:
    def __init__(
        self,
        *,
        max_gross_leverage: float = 2.0,
        max_net_exposure: float = 1.5,
        max_symbol_weight: float = 0.5,
        max_concurrent_positions: int = 4,
        correlation_threshold: float = 0.8,
        correlation_group_cap: float = 1.2,
    ) -> None:
        self.max_gross_leverage = max_gross_leverage
        self.max_net_exposure = max_net_exposure
        self.max_symbol_weight = max_symbol_weight
        self.max_concurrent_positions = max_concurrent_positions
        self.correlation_threshold = correlation_threshold
        self.correlation_group_cap = correlation_group_cap

    # ------------------------------------------------------------------ apply
    def apply(
        self,
        weights: dict[str, float],
        *,
        returns: pd.DataFrame | None = None,
        corr: pd.DataFrame | None = None,
        vol: dict[str, float] | None = None,
    ) -> LimitReport:
        """Apply every limit.

        `corr` takes precedence over `returns`: the caller usually already has the
        correlation matrix (the risk engine needs it for vol targeting), and
        recomputing it inside here on every bar is a real cost — it dominated the
        backtest runtime before this parameter existed.
        """
        w = {k: float(v) for k, v in weights.items() if np.isfinite(v)}
        notes: list[str] = []

        # 1) Per-symbol cap (scales down rather than clipping, which would distort
        #    the relative conviction the strategy expressed).
        capped = {}
        for sym, val in w.items():
            if abs(val) > self.max_symbol_weight:
                capped[sym] = float(np.sign(val) * self.max_symbol_weight)
                notes.append(f"{sym}: per-symbol cap {self.max_symbol_weight:.2f}")
            else:
                capped[sym] = val
        w = capped

        # 2) Concentration: keep the largest-|weight| names, flatten the rest.
        longs = sorted([s for s, v in w.items() if v > 0], key=lambda s: -abs(w[s]))
        shorts = sorted([s for s, v in w.items() if v < 0], key=lambda s: -abs(w[s]))
        keep = set(longs[: self.max_concurrent_positions]) | set(shorts[: self.max_concurrent_positions])
        for sym in list(w):
            if sym not in keep and abs(w[sym]) > 0:
                notes.append(f"{sym}: dropped, >{self.max_concurrent_positions} positions/side")
                w[sym] = 0.0

        # 3) Correlation groups: correlated names are one bet, so cap their sum.
        view = as_view(corr, list(w))
        if view is None and returns is not None and not returns.empty:
            view = as_view(returns.tail(500).corr(), list(w))
        if view is not None and len(view.symbols) > 1:
            w = self._apply_correlation_cap(w, view, notes)

        # 4) Gross leverage — a hard cap, so it must still hold at the end.
        gross = sum(abs(v) for v in w.values())
        if gross > self.max_gross_leverage and gross > 0:
            k = self.max_gross_leverage / gross
            w = {s: v * k for s, v in w.items()}
            notes.append(f"gross {gross:.2f} -> {self.max_gross_leverage:.2f} (scaled {k:.3f})")

        # 5) Net exposure — reduce the *dominant side* rather than shifting every
        #    weight by a constant.
        #
        #    The naive `w - excess/n` shift has two defects that a risk limit must
        #    never have: it can push a small long through zero (a long-only book
        #    silently acquires a short), and it can push gross leverage back above
        #    the cap it was just trimmed to. Scaling the dominant side fixes both,
        #    because it never changes the sign of any weight and can only reduce
        #    gross.
        #
        #    With P = sum(longs), N = sum(|shorts|), gross = P + N, net = P - N.
        #    To force net down to M we need P' = M + N, and since net > M implies
        #    P > M + N, P' < P: a pure scale-down of the long side.
        net = sum(w.values())
        if abs(net) > self.max_net_exposure and net != 0:
            longs = {s: v for s, v in w.items() if v > 0}
            shorts = {s: v for s, v in w.items() if v < 0}
            p_sum = sum(longs.values())
            n_sum = -sum(shorts.values())
            target = float(np.sign(net) * self.max_net_exposure)

            if net > target and p_sum > 0:
                new_p = max(target + n_sum, 0.0)
                k = new_p / p_sum
                w = {**{s: v * k for s, v in longs.items()}, **shorts}
                notes.append(f"net {net:.2f} -> {sum(w.values()):.2f} (longs scaled {k:.3f})")
            elif net < target and n_sum > 0:
                new_n = max(p_sum - target, 0.0)
                k = new_n / n_sum
                w = {**longs, **{s: v * k for s, v in shorts.items()}}
                notes.append(f"net {net:.2f} -> {sum(w.values()):.2f} (shorts scaled {k:.3f})")

        w = {s: float(v) for s, v in w.items() if abs(v) > 1e-9}
        return LimitReport(weights=w, adjustments=notes)

    def _apply_correlation_cap(
        self, w: dict[str, float], view: CorrelationView, notes: list[str]
    ) -> dict[str, float]:
        cols = [c for c in view.symbols if c in w and w[c] != 0]
        if len(cols) < 2:
            return w
        corr = pd.DataFrame(np.abs(view.submatrix(cols)), index=cols, columns=cols)
        # Greedy grouping: transitive closure over pairs above the threshold.
        groups: list[list[str]] = []
        assigned: set[str] = set()
        for sym in cols:
            if sym in assigned:
                continue
            group = [sym]
            assigned.add(sym)
            for other in cols:
                if other in assigned:
                    continue
                if corr.loc[sym, other] >= self.correlation_threshold:
                    group.append(other)
                    assigned.add(other)
            groups.append(group)

        out = dict(w)
        for group in groups:
            if len(group) < 2:
                continue
            exposure = sum(abs(out[s]) for s in group)
            if exposure > self.correlation_group_cap:
                k = self.correlation_group_cap / exposure
                for s in group:
                    out[s] *= k
                notes.append(
                    f"corr group {','.join(group)}: {exposure:.2f} -> {self.correlation_group_cap:.2f}"
                )
        return out
