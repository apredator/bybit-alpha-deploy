"""Kill-switch — the circuit breaker that ends the argument.

Every experienced desk has the same rule in some form: when the system hits a
pre-agreed loss, it stops. Not "reduces", not "waits for a bounce" — stops, and
a human decides whether to turn it back on.

The switch is **latched**: once tripped it stays tripped until an explicit
`reset()` from an operator. Un-latching automatically is how a bad day becomes a
bad year, because the code will happily re-enter the same losing trade.

Design note — why there is no "N losing days in a row" trigger
--------------------------------------------------------------
A streak counter is the most commonly implemented and most commonly wrong
circuit breaker. For a vol-targeted book, a single day's move is ~1/sqrt(365) of
annual volatility: five small down days in a row is statistically unremarkable
and says nothing about whether the edge is intact. Counting them halts healthy
strategies and teaches the operator to disable the switch, which is worse than
not having one.

Losses are therefore measured the way risk is actually managed: in magnitude and
relative to the book's own volatility.
  * peak-to-trough drawdown (the primary stop),
  * intraday loss versus the day's starting equity,
  * cumulative loss over a rolling window,
  * stale market data (a dead feed looks exactly like a quiet market).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import StrEnum


class RiskState(StrEnum):
    ACTIVE = "active"
    REDUCING = "reducing"
    HALTED = "halted"


@dataclass
class HaltRecord:
    reason: str
    ts: int
    equity: float
    drawdown: float


@dataclass
class KillSwitch:
    max_drawdown: float = 0.35
    #: The book's own annualised volatility target. Every loss limit below is
    #: expressed relative to it, because a fixed percentage means something
    #: completely different at different risk levels: a 12% loss over 20 days is a
    #: 2-sigma event for a 25%-vol book (it will happen roughly yearly by chance)
    #: and a 5-sigma event for a 10%-vol book (it means something broke).
    target_annual_vol: float = 0.25
    #: Daily loss limit, in standard deviations of a one-day move.
    daily_loss_sigmas: float = 4.0
    #: Absolute floor, to catch an operational disaster even on a very low-vol book.
    daily_loss_limit: float = 0.02
    #: Rolling-window loss limit, in standard deviations of that window's move.
    rolling_loss_sigmas: float = 3.0
    rolling_loss_days: int = 20
    #: Absolute floor for the rolling limit.
    rolling_loss_limit: float = 0.05
    max_data_staleness_s: int = 180
    #: Soft threshold that starts scaling risk down before the hard stop.
    reduce_at_drawdown: float = 0.12

    state: RiskState = RiskState.ACTIVE
    peak_equity: float = 0.0
    day_start_equity: float = 0.0
    current_day: int = -1
    last_equity: float = 0.0
    #: day index -> equity at the end of that day
    daily_close: dict[int, float] = field(default_factory=dict)
    history: list[HaltRecord] = field(default_factory=list)

    # -------------------------------------------------------------- lifecycle
    def reset(self, *, operator: str = "manual") -> None:
        """Operator-driven re-arm. Deliberately not automatic."""
        self.state = RiskState.ACTIVE
        self.peak_equity = max(self.last_equity, 0.0)
        self.daily_close.clear()
        self.history.append(HaltRecord(f"reset by {operator}", 0, self.last_equity, 0.0))

    def update_equity(self, equity: float, ts: int) -> None:
        day = ts // 86_400_000
        if day != self.current_day:
            if self.current_day >= 0:
                self.daily_close[self.current_day] = self.last_equity
            self.current_day = day
            self.day_start_equity = equity
        if self.peak_equity <= 0 or equity > self.peak_equity:
            self.peak_equity = equity
        self.last_equity = equity
        self.daily_close[day] = equity

    # ---------------------------------------------------- effective loss limits
    @property
    def effective_daily_limit(self) -> float:
        """Daily stop in risk units, floored by the absolute limit."""
        sigma_day = self.target_annual_vol / math.sqrt(365.0)
        return max(self.daily_loss_limit, self.daily_loss_sigmas * sigma_day)

    @property
    def effective_rolling_limit(self) -> float:
        sigma_window = self.target_annual_vol * math.sqrt(self.rolling_loss_days / 365.0)
        return max(self.rolling_loss_limit, self.rolling_loss_sigmas * sigma_window)

    # ----------------------------------------------------------------- signals
    @property
    def drawdown(self) -> float:
        if self.peak_equity <= 0:
            return 0.0
        return max(0.0, 1.0 - self.last_equity / self.peak_equity)

    @property
    def daily_pnl_frac(self) -> float:
        if self.day_start_equity <= 0:
            return 0.0
        return (self.last_equity - self.day_start_equity) / self.day_start_equity

    def rolling_loss_frac(self) -> float:
        """Return over the last `rolling_loss_days` calendar days."""
        if len(self.daily_close) < 2:
            return 0.0
        days = sorted(self.daily_close)
        past = [d for d in days if d <= self.current_day - self.rolling_loss_days]
        if not past:
            return 0.0
        base = self.daily_close[past[-1]]
        if base <= 0:
            return 0.0
        return self.last_equity / base - 1.0

    def check_data_staleness(self, ts: int, last_data_ts: int) -> str | None:
        if last_data_ts <= 0:
            return "no market data received"
        age_s = (ts - last_data_ts) / 1000.0
        if age_s > self.max_data_staleness_s:
            return f"stale market data: {age_s:.0f}s old (limit {self.max_data_staleness_s}s)"
        return None

    # ----------------------------------------------------------------- checks
    def evaluate(
        self, ts: int, *, last_data_ts: int | None = None
    ) -> tuple[RiskState, float, list[str]]:
        """Returns `(state, risk_multiplier, reasons)`.

        `risk_multiplier` lets the switch de-risk *gradually* on the way to a hard
        stop, which is usually better than a cliff edge: it keeps a bad week from
        becoming a catastrophic one without fully exiting a valid strategy.
        """
        if self.state is RiskState.HALTED:
            return self.state, 0.0, ["kill-switch latched"]

        reasons: list[str] = []
        dd = self.drawdown
        daily = self.daily_pnl_frac
        rolling = self.rolling_loss_frac()

        # Tolerance on the boundary: `1 - 80/100` is 0.19999999999999996, so a
        # textbook 20% drawdown would otherwise slip past a hard `>=` comparison.
        if dd >= self.max_drawdown - 1e-9:
            reasons.append(f"drawdown {dd:.1%} >= limit {self.max_drawdown:.1%}")
        if daily <= -self.effective_daily_limit:
            reasons.append(
                f"daily loss {daily:.1%} <= limit -{self.effective_daily_limit:.1%}"
            )
        if rolling <= -self.effective_rolling_limit:
            reasons.append(
                f"{self.rolling_loss_days}-day loss {rolling:.1%} <= "
                f"limit -{self.effective_rolling_limit:.1%}"
            )
        if last_data_ts is not None:
            stale = self.check_data_staleness(ts, last_data_ts)
            if stale:
                reasons.append(stale)

        if reasons:
            self.state = RiskState.HALTED
            self.history.append(HaltRecord("; ".join(reasons), ts, self.last_equity, dd))
            return self.state, 0.0, reasons

        multiplier = 1.0
        if self.reduce_at_drawdown > 0 and dd > self.reduce_at_drawdown:
            span = max(self.max_drawdown - self.reduce_at_drawdown, 1e-9)
            multiplier = max(0.0, 1.0 - (dd - self.reduce_at_drawdown) / span)
            reasons.append(f"de-risking: dd {dd:.1%} -> size x{multiplier:.2f}")
        return self.state, multiplier, reasons
