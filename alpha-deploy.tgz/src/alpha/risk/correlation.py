"""A pre-computed correlation matrix, indexed by symbol.

Why this exists as its own type
-------------------------------
The correlation matrix is needed on every decision bar by two consumers (the
exposure limits and the portfolio vol target). Doing `frame.loc[cols, cols]` in
that loop costs more than the entire rest of the risk engine: pandas label
indexing is ~200 µs per call and the loop runs thousands of times.

So the matrix is converted to numpy **once**, at the moment it is refreshed
(correlations move slowly, so that is every few dozen bars), and the hot path is
plain integer indexing.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class CorrelationView:
    symbols: tuple[str, ...]
    matrix: np.ndarray
    _index: dict[str, int]

    @classmethod
    def from_frame(cls, frame: pd.DataFrame) -> CorrelationView:
        symbols = tuple(str(c) for c in frame.columns)
        matrix = np.nan_to_num(frame.to_numpy(dtype=float), nan=0.0, posinf=1.0, neginf=-1.0)
        np.fill_diagonal(matrix, 1.0)
        return cls(symbols=symbols, matrix=matrix, _index={s: i for i, s in enumerate(symbols)})

    @classmethod
    def identity(cls, symbols: list[str]) -> CorrelationView:
        n = len(symbols)
        return cls(
            symbols=tuple(symbols),
            matrix=np.eye(n),
            _index={s: i for i, s in enumerate(symbols)},
        )

    def has(self, symbol: str) -> bool:
        return symbol in self._index

    def submatrix(self, symbols: list[str]) -> np.ndarray:
        """Correlation block for `symbols`, in the order given."""
        idx = [self._index[s] for s in symbols if s in self._index]
        if not idx:
            return np.zeros((0, 0))
        return self.matrix[np.ix_(idx, idx)]


def as_view(corr: CorrelationView | pd.DataFrame | None, symbols: list[str] | None = None) -> CorrelationView | None:
    """Normalise whatever the caller passed into a `CorrelationView`.

    Accepts a pre-built view (fast path, used in the backtest loop), a DataFrame
    (converted once here), or None.
    """
    if corr is None:
        return None
    if isinstance(corr, CorrelationView):
        return corr
    if isinstance(corr, pd.DataFrame):
        if corr.empty:
            return None
        return CorrelationView.from_frame(corr)
    raise TypeError(f"unsupported correlation type: {type(corr)!r}")
