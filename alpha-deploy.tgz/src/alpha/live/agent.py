"""The trading agent loop.

One cycle, in order, every time:

    fetch closed bars -> QC -> features -> signals -> marks -> equity
        -> risk engine (the only sizing authority) -> order plan -> submit
        -> reconcile -> status/heartbeat

Rules the loop enforces, each of which exists because its absence has blown up
real accounts:

* **Only closed bars.** The newest candle from the REST API is still forming;
  acting on it means acting on a price that does not exist yet. It is dropped.
* **Reconcile before trading.** The venue is the source of truth. If local and
  venue disagree, the venue wins and we log it loudly.
* **One decision per bar.** The cycle is idempotent within a bar: the same bar
  produces the same order client ids, so a restart mid-bar cannot double-trade.
* **The kill-switch overrides everything**, including an open position, and it
  stays engaged until a human resets it.
* **The agent never crashes silently.** Any exception is logged, the cycle is
  abandoned, and the loop continues; a single bad symbol cannot stop the book.
"""

from __future__ import annotations

import contextlib
import json
import signal
import time
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from alpha.config import Settings
from alpha.data.bybit_rest import BybitREST
from alpha.data.loader import INTERVAL_MS
from alpha.data.validation import clean_ohlcv
from alpha.execution.broker import plan_orders
from alpha.log import get_logger
from alpha.risk.engine import MarketSnapshot, RiskEngine
from alpha.risk.killswitch import RiskState
from alpha.risk.sizing import InstrumentSpec
from alpha.strategy.portfolio import PortfolioStrategy
from alpha.types import Order, OrderType

log = get_logger("alpha.agent")


@dataclass
class CycleReport:
    ts: int
    bar_ts: int
    equity: float
    target_weights: dict[str, float] = field(default_factory=dict)
    orders: list[Order] = field(default_factory=list)
    state: RiskState = RiskState.ACTIVE
    notes: list[str] = field(default_factory=list)
    #: Symbols the agent refused to touch this cycle, with the reason.
    excluded: dict[str, str] = field(default_factory=dict)
    skipped: str = ""


class TradingAgent:
    def __init__(
        self,
        settings: Settings,
        broker,
        rest: BybitREST,
        *,
        specs: dict[str, InstrumentSpec] | None = None,
        status_path: Path | None = None,
    ) -> None:
        self.settings = settings
        self.broker = broker
        self.rest = rest
        self.specs = specs or {}
        # Inside the data root, not its parent: two configurations that differ only
        # by data root (say `data/raw` and `data/recent`) were otherwise writing the
        # same heartbeat file, so `alpha health` could report on a different agent's
        # state than the one it was asked about.
        self.status_path = status_path or (settings.data.root / "live_status.json")
        self.risk = RiskEngine(settings.risk, specs=self.specs)
        self.strategy = PortfolioStrategy(params=settings.strategy.params)
        self.interval = settings.data.interval
        self.bar_ms = INTERVAL_MS[self.interval]
        self.last_bar_ts: int = 0
        self.cycles = 0
        self.error_count = 0
        self._stop = False
        #: symbol -> reason it was excluded from this cycle's book.
        self.quality_rejections: dict[str, str] = {}

        # A bar-based strategy is legitimately "stale" for up to a full bar: on an
        # hourly clock the newest closed candle is already ~1h old by the time we
        # read it. A fixed 180s staleness limit therefore trips the kill-switch on
        # every single cycle — a false positive that trains the operator to ignore
        # the switch. Scale the limit to the bar interval instead.
        bar_seconds = self.bar_ms / 1000.0
        self.risk.kill_switch.max_data_staleness_s = max(
            int(settings.risk.max_data_staleness_s), int(bar_seconds * 2.5)
        )

    # ---------------------------------------------------------------- signals
    def _fetch_closed_bars(self, symbol: str, need: int) -> pd.DataFrame:
        """Recent history, with the still-forming candle removed."""
        rows = self.rest.klines(symbol, self.interval, limit=min(max(need, 100), 1000))
        if not rows:
            return pd.DataFrame()
        from alpha.data.loader import _to_frame

        frame = _to_frame(rows)
        now_ms = int(time.time() * 1000)
        frame = frame[frame["ts"] + self.bar_ms <= now_ms]
        return frame.sort_values("ts").reset_index(drop=True)

    def _funding(self, symbol: str, days: int = 30) -> pd.DataFrame:
        end = int(time.time() * 1000)
        start = end - days * 86_400_000
        rows = self.rest.funding_history(symbol, start_ms=start, end_ms=end, limit=200)
        if not rows:
            return pd.DataFrame(columns=["ts", "funding_rate"])
        return pd.DataFrame(
            [
                {"ts": int(r["fundingRateTimestamp"]), "funding_rate": float(r["fundingRate"])}
                for r in rows
            ]
        )

    def _tradability_rejection(self, report) -> str | None:
        """Why this symbol must not be traded right now, or None if it is fine.

        This is the gate that turns the quality work into an actual safety control.
        Repairing a corrupt bar makes the *data* usable; it does not make the
        *price* trustworthy. When a feed is this degraded, the honest action is to
        stand aside, not to trade a cleaned-up guess.
        """
        max_bad = self.settings.data.max_bad_bar_fraction
        max_wick = self.settings.data.max_wick_fraction
        if report.bad_fraction > max_bad:
            return (
                f"{report.bad_fraction:.2%} of bars had a corrupt close "
                f"(limit {max_bad:.2%}) — the price path itself is unreliable"
            )
        if report.wick_fraction > max_wick:
            return (
                f"{report.wick_fraction:.1%} of wicks had to be clamped "
                f"(limit {max_wick:.0%}) — ATR, stops and sizing would be guesswork"
            )
        return None

    def build_signals(self) -> tuple[dict[str, pd.DataFrame], dict[str, float]]:
        """Features and target weights for every symbol that passes the data gate."""
        warmup = int(self.settings.strategy.params.get("warmup_bars", 300))
        need = warmup + 300
        panels: dict[str, pd.DataFrame] = {}
        fundings: dict[str, pd.DataFrame] = {}
        self.quality_rejections = {}

        for symbol in self.settings.data.symbols:
            try:
                raw = self._fetch_closed_bars(symbol, need)
                if raw.empty:
                    self.quality_rejections[symbol] = "no bars returned"
                    log.warning("no bars returned", extra={"extra_fields": {"symbol": symbol}})
                    continue
                cleaned, report = clean_ohlcv(raw, symbol=symbol, expected_ms=self.bar_ms)
                if report.repaired or report.wick_repairs:
                    log.warning("qc", extra={"extra_fields": {"detail": report.summary()}})

                rejection = self._tradability_rejection(report)
                if rejection:
                    self.quality_rejections[symbol] = rejection
                    log.error(
                        "refusing to trade symbol on this feed",
                        extra={"extra_fields": {"symbol": symbol, "reason": rejection}},
                    )
                    continue

                panels[symbol] = cleaned
                fundings[symbol] = self._funding(symbol)
            except Exception as exc:  # noqa: BLE001 - one bad symbol must not stop the book
                self.error_count += 1
                self.quality_rejections[symbol] = f"fetch failed: {exc}"
                log.error("data fetch failed", extra={"extra_fields": {"symbol": symbol, "err": str(exc)}})

        if not panels:
            return {}, {}

        aligned = self._align(panels)
        weights_matrix, features = self.strategy.build_weight_matrix(
            aligned, interval=self.interval, fundings=fundings
        )
        if weights_matrix.empty:
            return features, {}
        last_ts = weights_matrix.index.max()
        weights = {s: float(weights_matrix.loc[last_ts, s]) for s in weights_matrix.columns}
        return features, weights

    def _align(self, panels: dict[str, pd.DataFrame]) -> dict[str, pd.DataFrame]:
        """Trim every symbol to the same closing bar, so no symbol is ahead."""
        common_last = min(int(df["ts"].iloc[-1]) for df in panels.values())
        return {s: df[df["ts"] <= common_last].reset_index(drop=True) for s, df in panels.items()}

    # ------------------------------------------------------------------ cycle
    def run_once(self) -> CycleReport:
        now = int(time.time() * 1000)
        features, weights = self.build_signals()
        report = CycleReport(ts=now, bar_ts=0, equity=0.0)

        if not features:
            if self.quality_rejections and len(self.quality_rejections) >= len(self.settings.data.symbols):
                report.skipped = (
                    "every symbol failed the data-quality gate: "
                    + "; ".join(f"{s}: {r}" for s, r in self.quality_rejections.items())
                )
                log.error(
                    "no tradable symbols — standing aside entirely",
                    extra={"extra_fields": {"rejections": self.quality_rejections}},
                )
            else:
                report.skipped = "no market data"
            self._write_status(report)
            return report

        bar_ts = min(int(f["ts"].iloc[-1]) for f in features.values())
        report.bar_ts = bar_ts
        if bar_ts == self.last_bar_ts:
            report.skipped = f"bar {bar_ts} already processed"
            return report

        state = self.broker.account_state()
        report.equity = state.equity
        marks = self.broker.mark_prices(sorted(weights)) or self.broker.mark_prices(
            sorted(features)
        )

        market: dict[str, MarketSnapshot] = {}
        for symbol, f in features.items():
            row = f.iloc[-1]
            price = marks.get(symbol, float(row["close"]))
            market[symbol] = MarketSnapshot(
                symbol=symbol,
                price=price,
                vol=float(row["vol"]) if pd.notna(row["vol"]) else 0.0,
                atr=float(row["atr"]) if pd.notna(row["atr"]) else 0.0,
                dollar_volume=float(row["volume"]) * price if pd.notna(row["volume"]) else 0.0,
            )

        current_qty = {s: p.qty for s, p in self.broker.positions().items()}
        decision = self.risk.evaluate(
            ts=now,
            equity=state.equity,
            weights=weights,
            market=market,
            current_qty=current_qty,
            last_data_ts=bar_ts + self.bar_ms,
        )
        report.target_weights = decision.target_weights
        report.state = decision.state
        report.notes = decision.notes
        report.excluded = dict(self.quality_rejections)

        if decision.state is RiskState.HALTED:
            log.error(
                "KILL-SWITCH ENGAGED — flattening and stopping",
                extra={"extra_fields": {"reasons": decision.notes}},
            )
            flat = self.broker.flatten(sorted(set(current_qty) | set(weights)))
            report.orders = flat
            self.last_bar_ts = bar_ts
            self._write_status(report)
            self._stop = True
            return report

        order_type = OrderType(self.settings.execution.order_type)
        orders: list[Order] = []
        for symbol, target in decision.target_qty.items():
            spec = self.specs.get(symbol) or InstrumentSpec(symbol=symbol)
            price = marks.get(symbol, 0.0)
            if not self.risk.needs_rebalance(
                symbol, target, current_qty.get(symbol, 0.0), price, state.equity
            ):
                continue
            orders.extend(
                plan_orders(
                    symbol,
                    current_qty.get(symbol, 0.0),
                    target,
                    spec,
                    price,
                    ts=bar_ts,
                    namespace=self.settings.mode,
                    order_type=order_type,
                )
            )

        if orders:
            report.orders = self.broker.submit(orders, equity=state.equity, marks=marks)
        else:
            log.info("no rebalance needed", extra={"extra_fields": {"bar": bar_ts}})

        self.broker.reconcile()
        self.last_bar_ts = bar_ts
        self.cycles += 1
        self._write_status(report)
        return report

    # ------------------------------------------------------------------- loop
    def run(self, *, poll_seconds: float = 30.0, max_cycles: int | None = None) -> None:
        self._install_signal_handlers()
        log.info(
            "agent starting",
            extra={
                "extra_fields": {
                    "mode": self.settings.mode,
                    "symbols": self.settings.data.symbols,
                    "interval": self.interval,
                    "dry_run": self.settings.execution.dry_run,
                    "testnet": self.settings.bybit.testnet,
                }
            },
        )
        cycles = 0
        while not self._stop:
            try:
                self.run_once()
            except KeyboardInterrupt:
                break
            except Exception as exc:  # noqa: BLE001 - the loop must survive a bad cycle
                self.error_count += 1
                log.exception("cycle failed", extra={"extra_fields": {"err": str(exc)}})
            cycles += 1
            if max_cycles is not None and cycles >= max_cycles:
                break
            # Wake up slightly after the next bar close rather than tight-looping.
            time.sleep(poll_seconds)
        log.info("agent stopped", extra={"extra_fields": {"cycles": cycles, "errors": self.error_count}})

    def _install_signal_handlers(self) -> None:
        def _handler(signum, _frame):  # noqa: ANN001
            log.warning("shutdown signal received; finishing current cycle", extra={"extra_fields": {"signal": signum}})
            self._stop = True

        for sig in (signal.SIGINT, signal.SIGTERM):
            # signal() raises ValueError off the main thread (tests, embedded use).
            with contextlib.suppress(ValueError):
                signal.signal(sig, _handler)

    # ---------------------------------------------------------------- status
    def status(self) -> dict:
        return {
            "mode": self.settings.mode,
            "strategy": self.settings.strategy.name,
            "symbols": self.settings.data.symbols,
            "interval": self.interval,
            "last_bar_ts": self.last_bar_ts,
            "cycles": self.cycles,
            "errors": self.error_count,
            "risk_state": str(self.risk.kill_switch.state),
            "excluded_symbols": self.quality_rejections,
            "drawdown": self.risk.kill_switch.drawdown,
            "equity": self.risk.kill_switch.last_equity,
            "dry_run": self.settings.execution.dry_run,
        }

    def _write_status(self, report: CycleReport) -> None:
        payload = self.status()
        payload.update(
            {
                "ts": report.ts,
                "bar_ts": report.bar_ts,
                "skipped": report.skipped,
                "target_weights": {k: round(v, 5) for k, v in report.target_weights.items()},
                "notes": report.notes[:5],
                "orders": [
                    {
                        "symbol": o.symbol,
                        "side": o.side.value,
                        "qty": o.qty,
                        "reduce_only": o.reduce_only,
                        "status": o.status.value,
                        "client_id": o.client_id,
                    }
                    for o in report.orders
                ],
            }
        )
        try:
            self.status_path.parent.mkdir(parents=True, exist_ok=True)
            self.status_path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
        except OSError as exc:
            log.warning("cannot write status file", extra={"extra_fields": {"err": str(exc)}})
