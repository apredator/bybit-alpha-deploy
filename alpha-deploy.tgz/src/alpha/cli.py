"""Command-line interface.

    alpha data download      fetch and QC history into the local store
    alpha data status        what history do we actually have
    alpha data synth         generate a controlled synthetic market for testing
    alpha check              preflight: connectivity, data quality, credentials
    alpha backtest           simulate the strategy on cached history
    alpha walkforward        out-of-sample stability across consecutive windows
    alpha paper              run the live loop against mark prices, no money
    alpha live               run the live loop against Bybit (real money)
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import typer
from rich.console import Console
from rich.table import Table

from alpha.backtest import metrics
from alpha.config import APP_ROOT, Settings, load_settings
from alpha.data.bybit_rest import BybitError, BybitREST
from alpha.data.loader import INTERVAL_MS, MarketDataLoader
from alpha.data.store import ParquetStore
from alpha.data.validation import clean_ohlcv
from alpha.log import setup_logging

app = typer.Typer(add_completion=False, help="Systematic trading agent for Bybit USDT perpetuals.")
data_app = typer.Typer(help="Market data: download, inspect, synthesise.")
app.add_typer(data_app, name="data")

console = Console()
REPORTS_DIR = APP_ROOT / "reports"


DATA_ROOT_OPTION = typer.Option(
    None, "--data-root", help="Override the market-data directory (e.g. data/synth)."
)


def _settings(
    config: Path | None, mode: str | None = None, data_root: Path | None = None, **overrides
) -> Settings:
    kwargs = {k: v for k, v in overrides.items() if v is not None}
    if mode:
        kwargs["mode"] = mode
    s = load_settings(config, **kwargs)
    if data_root is not None:
        s.data.root = Path(data_root)
    return s


def _parse_symbols(symbols: str | None, settings: Settings) -> list[str]:
    if not symbols:
        return settings.data.symbols
    return [s.strip().upper() for s in symbols.split(",") if s.strip()]


# --------------------------------------------------------------------- data
@data_app.command("download")
def data_download(
    config: Path = typer.Option(None, "--config", "-c", help="YAML config path."),
    symbols: str = typer.Option(None, "--symbols", "-s", help="Comma-separated, e.g. BTCUSDT,ETHUSDT"),
    interval: str = typer.Option(None, "--interval", "-i", help="Bybit interval: 1,5,15,60,240,D"),
    days: int = typer.Option(None, "--days", "-d", help="History depth in days."),
    force: bool = typer.Option(False, "--force", help="Re-download from scratch."),
    data_root: Path = DATA_ROOT_OPTION,
) -> None:
    """Download candles and funding history into the local parquet store."""
    setup_logging()
    s = _settings(config, data_root=data_root)
    interval = interval or s.data.interval
    if interval not in INTERVAL_MS:
        raise typer.BadParameter(f"unsupported interval '{interval}'. Known: {sorted(INTERVAL_MS)}")
    syms = _parse_symbols(symbols, s)
    if days:
        s.data.history_days = days

    store = ParquetStore(s.data.root)
    with BybitREST(s.bybit) as rest:
        loader = MarketDataLoader(rest, store, s.data)
        table = Table(title=f"Downloaded {interval} klines")
        for col in ("symbol", "fetched", "total", "from", "to"):
            table.add_column(col)
        for sym in syms:
            try:
                rep = loader.download_klines(sym, interval=interval, force=force)
                loader.download_funding(sym, days=s.data.history_days, force=force)
                table.add_row(
                    sym,
                    str(rep.fetched),
                    str(rep.total),
                    _ts(rep.first_ts),
                    _ts(rep.last_ts),
                )
            except BybitError as exc:
                table.add_row(sym, "[red]error[/red]", str(exc)[:40], "-", "-")
        console.print(table)


@data_app.command("status")
def data_status(
    config: Path = typer.Option(None, "--config", "-c"), data_root: Path = DATA_ROOT_OPTION
) -> None:
    """Show what history is cached locally, plus a QC verdict per symbol."""
    setup_logging("WARNING")
    s = _settings(config, data_root=data_root)
    store = ParquetStore(s.data.root)
    inv = store.inventory()
    if inv.empty:
        console.print("[yellow]No cached data. Run: alpha data download[/yellow]")
        return
    console.print(inv.to_string(index=False))

    table = Table(title="Data quality")
    for col in ("symbol", "bars", "bad bars", "bad %", "wick %", "verdict"):
        table.add_column(col)
    for sym in s.data.symbols:
        df = store.load_klines(sym, s.data.interval, s.bybit.category)
        if df.empty:
            continue
        expected = INTERVAL_MS.get(s.data.interval, 3_600_000)
        _, report = clean_ohlcv(df, symbol=sym, expected_ms=expected)
        table.add_row(
            sym,
            str(report.rows),
            str(report.repaired),
            f"{report.bad_fraction:.3%}",
            f"{report.wick_fraction:.2%}",
            _verdict(report),
        )
    console.print(table)
    console.print(
        "[dim]bad bars = corrupt closes (untradeable). wick %% = bad high/low only, "
        "clamped on read; a clean close path is preserved.[/dim]"
    )


@data_app.command("synth")
def data_synth(
    config: Path = typer.Option(None, "--config", "-c"),
    symbols: str = typer.Option("BTCUSDT,ETHUSDT,SOLUSDT", "--symbols", "-s"),
    bars: int = typer.Option(8760, "--bars", "-n"),
    interval: str = typer.Option("60", "--interval", "-i"),
    seed: int = typer.Option(7, "--seed"),
    common_factor: float = typer.Option(0.5, "--common-factor"),
    data_root: Path = DATA_ROOT_OPTION,
) -> None:
    """Generate a controlled synthetic market with known statistical properties.

    Use it to validate the machinery end-to-end, not to claim profitability.
    """
    setup_logging()
    s = _settings(config, data_root=data_root or (APP_ROOT / "data" / "synth"))
    from alpha.data.synthetic import generate_panel

    interval_ms = INTERVAL_MS[interval]
    syms = _parse_symbols(symbols, s)
    store = ParquetStore(s.data.root)
    # Aligned to the hour *and* the 8h funding grid, so settlements land on bars.
    panels, fundings = generate_panel(
        syms,
        bars=bars,
        interval_ms=interval_ms,
        seed=seed,
        common_factor=common_factor,
        start_ts=1_700_006_400_000,
    )
    table = Table(title=f"Synthetic market written to {s.data.root}")
    for col in ("symbol", "bars", "annual vol", "funding rows", "first close", "last close"):
        table.add_column(col)
    for sym in syms:
        df = panels[sym]
        store.save_klines(sym, interval, df, s.bybit.category)
        store.save_funding(sym, fundings[sym], s.bybit.category)
        # Report the *realised* vol, so the table states what was generated rather
        # than what was requested — the two should agree, and if they do not we
        # want to see it.
        log_ret = np.log(df["close"] / df["close"].shift(1)).dropna()
        realised = float(log_ret.std(ddof=0)) * np.sqrt(365 * 24 * 3_600_000 / INTERVAL_MS[interval])
        table.add_row(
            sym,
            str(len(df)),
            f"{realised:.0%}",
            str(len(fundings[sym])),
            f"{df['close'].iloc[0]:,.2f}",
            f"{df['close'].iloc[-1]:,.2f}",
        )
    console.print(table)
    console.print(
        "[dim]Synthetic data validates the machinery against known ground truth. "
        "It is NOT evidence of real-world profitability.[/dim]"
    )


# -------------------------------------------------------------------- check
@app.command()
def check(
    config: Path = typer.Option(None, "--config", "-c"),
    live: bool = typer.Option(
        False,
        "--live",
        help="Also fetch a recent window from the exchange and run the agent's tradability gate on it.",
    ),
    data_root: Path = DATA_ROOT_OPTION,
) -> None:
    """Preflight the whole system: connectivity, data, credentials, risk config."""
    setup_logging("WARNING")
    s = _settings(config, data_root=data_root)
    ok = True

    console.print(f"[bold]Mode:[/bold] {s.mode}   [bold]Testnet:[/bold] {s.bybit.testnet}")

    try:
        with BybitREST(s.bybit) as rest:
            server_ms = rest.server_time_ms()
            skew = abs(int(time.time() * 1000) - server_ms)
            console.print(f"[green]OK[/green]  Bybit REST reachable ({s.bybit.rest_url}), clock skew {skew} ms")
            if skew > 5_000:
                console.print("[yellow]WARN[/yellow] clock skew > 5s — signed requests may be rejected")
    except Exception as exc:  # noqa: BLE001
        ok = False
        console.print(f"[red]FAIL[/red] Bybit REST unreachable: {exc}")

    if s.bybit.has_credentials:
        try:
            with BybitREST(s.bybit) as rest:
                balance = rest.wallet_balance()
            equity = float(balance.get("list", [{}])[0].get("totalEquity", 0) or 0)
            console.print(f"[green]OK[/green]  Credentials valid, account equity {equity:,.2f} USDT")
        except BybitError as exc:
            ok = False
            console.print(f"[red]FAIL[/red] Credentials rejected: {exc}")
    else:
        console.print("[yellow]WARN[/yellow] No API credentials — paper/backtest only")

    store = ParquetStore(s.data.root)
    expected = INTERVAL_MS.get(s.data.interval, 3_600_000)
    for sym in s.data.symbols:
        df = store.load_klines(sym, s.data.interval, s.bybit.category)
        if df.empty:
            console.print(f"[yellow]WARN[/yellow] no cached data for {sym}")
            continue
        _, report = clean_ohlcv(df, symbol=sym, expected_ms=expected)
        if report.bad_fraction > 0.02:
            console.print(
                f"[red]FAIL[/red] {sym}: {report.bad_fraction:.2%} of bars have a corrupt CLOSE — "
                f"the price path itself is untrustworthy; do not trade this symbol on this feed"
            )
            ok = False
        elif report.wick_fraction > 0.25:
            console.print(
                f"[red]FAIL[/red] {sym}: {report.wick_fraction:.1%} of bars need wick clamping — "
                f"ATR and therefore position sizing would be built on noise"
            )
            ok = False
        elif report.wick_fraction > 0.05:
            console.print(
                f"[yellow]WARN[/yellow] {sym}: {report.rows} bars, closes clean, "
                f"{report.wick_fraction:.1%} of wicks clamped (ATR slightly degraded)"
            )
        else:
            console.print(
                f"[green]OK[/green]  {sym}: {report.rows} bars, "
                f"{report.bad_fraction:.3%} bad closes, {report.wick_fraction:.2%} clamped wicks"
            )

        # The stored candles are already repaired, so the numbers above describe
        # what we will trade on. The manifest describes what the *feed* delivered —
        # without it, a preflight on cleaned data can never fail, which would make
        # it a rubber stamp.
        manifest = store.load_qc(sym, s.data.interval, s.bybit.category)
        if manifest:
            raw_bad = float(manifest.get("bad_fraction") or 0.0)
            raw_wick = float(manifest.get("wick_fraction") or 0.0)
            age = time.strftime("%Y-%m-%d %H:%M", time.gmtime((manifest.get("checked_at_ms") or 0) / 1000))
            line = (
                f"      feed at ingestion ({age} UTC): "
                f"{raw_bad:.2%} bad closes, {raw_wick:.1%} clamped wicks"
            )
            if raw_bad > 0.02 or raw_wick > 0.25:
                console.print(f"[yellow]WARN[/yellow]{line} — degraded upstream feed")
            else:
                console.print(f"[dim]{line}[/dim]")

    r = s.risk
    if r.max_gross_leverage <= 1.0:
        console.print("[yellow]WARN[/yellow] max_gross_leverage <= 1.0 — the strategy will be very small")
    if r.max_drawdown_kill >= 0.5:
        console.print("[red]FAIL[/red] max_drawdown_kill >= 50% is not a risk limit, it is a hope")
        ok = False
    # The drawdown stop and the volatility target are not independent choices: the
    # expected worst drawdown of a vol-targeted book over a year is roughly
    # 1.5-2x its annual volatility. A stop set below the vol target sits inside
    # normal noise and will close a healthy strategy.
    if r.max_drawdown_kill < 1.2 * r.target_annual_vol:
        console.print(
            f"[red]FAIL[/red] max_drawdown_kill {r.max_drawdown_kill:.0%} is inside the normal "
            f"drawdown band of a {r.target_annual_vol:.0%}-vol book — this stop will fire on a "
            f"healthy strategy. Use >= {1.2 * r.target_annual_vol:.0%}, or lower the vol target."
        )
        ok = False
    if r.target_annual_vol > 0.6:
        console.print("[yellow]WARN[/yellow] target_annual_vol > 60% — expect deep drawdowns")
    console.print(f"[green]OK[/green]  risk: vol target {r.target_annual_vol:.0%}, "
                  f"gross cap {r.max_gross_leverage}x, kill at {r.max_drawdown_kill:.0%} DD")

    if live:
        # The cached-data section above cannot catch a bad *live* feed, and on a
        # fresh server there is no cache at all — so a preflight without this flag
        # passes without ever having looked at the data the agent will trade on.
        console.print("\n[bold]Live feed (same gate the agent applies at runtime)[/bold]")
        from alpha.execution.paper import PaperBroker
        from alpha.live.agent import TradingAgent

        broker = PaperBroker(s, lambda syms: {})
        with BybitREST(s.bybit) as live_rest:
            agent = TradingAgent(s, broker, live_rest, specs={})
            agent.build_signals()
        if not agent.quality_rejections:
            console.print("[green]OK[/green]  every configured symbol is tradable")
        dropped = len(agent.quality_rejections)
        total = len(s.data.symbols)
        all_dropped = dropped >= total
        for sym, reason in agent.quality_rejections.items():
            colour = "red" if all_dropped else "yellow"
            console.print(
                f"[{colour}]{'FAIL' if all_dropped else 'WARN'}[/{colour}] {sym}: {reason}"
            )
        if all_dropped:
            ok = False
        elif dropped * 2 > total:
            console.print(
                f"[yellow]WARN[/yellow] {dropped} of {total} symbols dropped — the book is no "
                f"longer diversified, and the strategy will still trade the remainder"
            )

    console.print("\n[bold green]Preflight passed[/bold green]" if ok else "\n[bold red]Preflight FAILED[/bold red]")
    if not ok:
        raise typer.Exit(code=1)


# ----------------------------------------------------------------- backtest
@app.command()
def backtest(
    config: Path = typer.Option(None, "--config", "-c"),
    symbols: str = typer.Option(None, "--symbols", "-s"),
    interval: str = typer.Option(None, "--interval", "-i"),
    out: Path = typer.Option(None, "--out", "-o", help="Report prefix (default: reports/backtest)."),
    tearsheet: bool = typer.Option(True, "--tearsheet/--no-tearsheet"),
    no_demean: bool = typer.Option(False, "--no-demean", help="Keep the common market factor."),
    no_risk: bool = typer.Option(
        False, "--no-risk", help="Disable the kill-switch (research only: shows raw signal behaviour)."
    ),
    warmup: int = typer.Option(None, "--warmup"),
    data_root: Path = DATA_ROOT_OPTION,
) -> None:
    """Run the strategy over cached history."""
    setup_logging("WARNING")
    s = _settings(config, data_root=data_root)
    if no_risk:
        s.risk.max_drawdown_kill = 1.0
        s.risk.rolling_loss_limit = 1.0
        s.risk.daily_loss_limit = 1.0
        s.risk.reduce_at_drawdown = 0.0
        console.print("[yellow]kill-switch disabled — this is a research run, not a tradable result[/yellow]")

    from alpha.runner import run_backtest

    syms = _parse_symbols(symbols, s)
    try:
        run = run_backtest(
            s, symbols=syms, interval=interval, demean=not no_demean, warmup_bars=warmup
        )
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc

    console.print(metrics.format_summary(run.metrics))
    res = run.result
    console.print(f"\nfunding P&L: {res.funding_paid:,.2f}   fees: {res.fees_paid:,.2f}   turnover: {res.turnover:,.0f}")
    if res.halted_at:
        ts = time.strftime("%Y-%m-%d %H:%M", time.gmtime(res.halted_at / 1000))
        console.print(f"[red]kill-switch engaged at {ts} UTC — results after this point are flat[/red]")
    for note in res.risk_events[:5]:
        console.print(f"  [dim]{note}[/dim]")

    prefix = Path(out) if out else REPORTS_DIR / "backtest"
    prefix.parent.mkdir(parents=True, exist_ok=True)
    (prefix.with_suffix(".json")).write_text(
        json.dumps({"metrics": run.metrics, "risk_events": res.risk_events[:50]}, indent=2, default=str),
        encoding="utf-8",
    )
    from alpha.backtest.report import equity_to_frame

    equity_to_frame(res).to_csv(prefix.with_suffix(".csv"))
    if tearsheet:
        from alpha.backtest.report import plot_tearsheet

        path = plot_tearsheet(res, prefix.with_suffix(".png"), interval=interval or s.data.interval)
        console.print(f"tearsheet: {path}")
    console.print(f"metrics:   {prefix.with_suffix('.json')}")


@app.command()
def walkforward(
    config: Path = typer.Option(None, "--config", "-c"),
    symbols: str = typer.Option(None, "--symbols", "-s"),
    interval: str = typer.Option(None, "--interval", "-i"),
    train: int = typer.Option(2160, "--train", help="In-sample bars per fold (2160h ≈ 90 days)."),
    test: int = typer.Option(720, "--test", help="Out-of-sample bars per fold (720h ≈ 30 days)."),
    optimize: bool = typer.Option(
        True,
        "--optimize/--fixed",
        help="Re-select parameters in-sample per fold, or hold one fixed rule set.",
    ),
    min_folds: int = typer.Option(8, "--min-folds", help="Folds required before a verdict is possible."),
    min_oos_days: float = typer.Option(120.0, "--min-oos-days", help="Out-of-sample days required."),
    data_root: Path = DATA_ROOT_OPTION,
) -> None:
    """Out-of-sample stability across disjoint windows, with a significance verdict.

    Reports whether the strategy is profitable in *most* folds — and, just as
    importantly, whether there are enough folds for that statement to mean
    anything.
    """
    setup_logging("WARNING")
    s = _settings(config, data_root=data_root)
    from alpha.runner import walk_forward

    report = walk_forward(
        s,
        train_bars=train,
        test_bars=test,
        symbols=_parse_symbols(symbols, s),
        interval=interval,
        optimize=optimize,
    )
    if report.folds.empty:
        console.print("[yellow]Not enough history for the requested window sizes.[/yellow]")
        raise typer.Exit(code=1)

    table = Table(title=f"Walk-forward ({'re-optimised in-sample' if optimize else 'fixed parameters'})")
    for col in ("fold", "start", "end", "test return", "test maxDD", "test Sharpe", "train Sharpe"):
        table.add_column(col)
    for _, row in report.folds.iterrows():
        table.add_row(
            str(int(row["fold"])),
            str(row["start"])[:16],
            str(row["end"])[:16],
            f"{row['test_return']:+.2%}",
            f"{row['test_max_dd']:.2%}",
            f"{row['test_sharpe']:.2f}",
            f"{row.get('train_sharpe', float('nan')):.2f}",
        )
    console.print(table)

    if optimize and not report.selected_params.empty:
        console.print("[dim]parameters selected in-sample per fold:[/dim]")
        console.print(report.selected_params.to_string(index=False))

    console.print(
        f"\nprofitable folds: {report.win_rate:.0%}   "
        f"median OOS Sharpe: {report.median_sharpe:.2f}   "
        f"mean fold return: {report.mean_return:+.2%}   "
        f"t-stat: {report.t_stat:.2f}   "
        f"folds: {report.n_folds} over {report.oos_days:.0f} OOS days"
        + (f"   [red]kill-switch fired in {report.halted_folds} fold(s)[/red]" if report.halted_folds else "")
    )

    status, explanation = report.verdict(min_folds=min_folds, min_oos_days=min_oos_days)
    colour = {"CERTIFIED": "green", "FAILED": "red", "INSUFFICIENT": "yellow"}[status]
    console.print(f"\n[bold {colour}]VERDICT: {status}[/bold {colour}] — {explanation}")
    if status == "INSUFFICIENT":
        console.print(
            "[dim]Not evidence of an edge, and not evidence against one. The harness "
            "refuses to certify on thin data — that is the point of it.[/dim]"
        )
        raise typer.Exit(code=2)
    if status == "FAILED":
        raise typer.Exit(code=1)


# --------------------------------------------------------------- live modes
def _run_agent(
    config: Path | None,
    cycles: int | None,
    poll: float,
    mode: str,
    dry_run: bool,
    data_root: Path | None = None,
) -> None:
    setup_logging()
    s = _settings(config, mode=mode, data_root=data_root)
    s.execution.dry_run = dry_run

    from alpha.execution.paper import PaperBroker
    from alpha.live.agent import TradingAgent

    with BybitREST(s.bybit) as rest:
        if mode == "live":
            from alpha.execution.bybit_broker import BybitBroker, fetch_specs

            broker = BybitBroker(s, rest, dry_run=dry_run)
            specs = fetch_specs(rest, s.data.symbols)
            broker.specs = specs
            broker.reconcile()
            state = broker.account_state()
            console.print(f"[bold]Live[/bold] equity {state.equity:,.2f} USDT, dry_run={dry_run}")
        else:
            def price_source(symbols: list[str]) -> dict[str, float]:
                return {
                    sym: float(t.get("markPrice") or t.get("lastPrice") or 0.0)
                    for sym in symbols
                    if (t := rest.ticker(sym))
                }

            broker = PaperBroker(s, price_source)
            specs = {}

        agent = TradingAgent(s, broker, rest, specs=specs)
        agent.run(poll_seconds=poll, max_cycles=cycles)


@app.command()
def paper(
    config: Path = typer.Option(None, "--config", "-c"),
    cycles: int = typer.Option(None, "--cycles", help="Stop after N cycles (default: run forever)."),
    poll: float = typer.Option(30.0, "--poll", help="Seconds between cycles."),
    data_root: Path = DATA_ROOT_OPTION,
) -> None:
    """Run the full agent loop against live mark prices with no money at risk."""
    _run_agent(config, cycles, poll, mode="paper", dry_run=True, data_root=data_root)


@app.command()
def live(
    config: Path = typer.Option(None, "--config", "-c"),
    cycles: int = typer.Option(None, "--cycles"),
    poll: float = typer.Option(30.0, "--poll"),
    i_know_this_trades_real_money: bool = typer.Option(
        False, "--i-understand", help="Required confirmation for live trading."
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Send nothing; log exactly what would be sent."
    ),
    data_root: Path = DATA_ROOT_OPTION,
) -> None:
    """Run against Bybit with real funds. Requires explicit confirmation."""
    if not i_know_this_trades_real_money and not dry_run:
        console.print(
            "[red]Refusing to trade real money without --i-understand.[/red]\n"
            "Run `alpha live --dry-run` first, then paper for weeks, then decide."
        )
        raise typer.Exit(code=2)
    _run_agent(config, cycles, poll, mode="live", dry_run=dry_run, data_root=data_root)


@app.command()
def health(
    config: Path = typer.Option(None, "--config", "-c"),
    max_age: float = typer.Option(300.0, "--max-age", help="Seconds before a heartbeat is stale."),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Also fail when only some symbols are tradable (use this for alerting).",
    ),
    data_root: Path = DATA_ROOT_OPTION,
) -> None:
    """Machine-readable liveness check. Exits non-zero when the agent is unhealthy.

    Used by the Docker healthcheck, by systemd, and by whatever is watching the box.
    Three ways an agent is unhealthy while its process is still alive: it stopped
    heartbeating, its risk state is halted, or it has been standing aside because
    it cannot trust the feed. All three must fail the check — a running process is
    not a working agent.
    """
    s = _settings(config, data_root=data_root)
    path = s.data.root / "live_status.json"
    if not path.exists():
        console.print("[red]UNHEALTHY[/red] no status file — the agent has never completed a cycle")
        raise typer.Exit(code=1)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        console.print(f"[red]UNHEALTHY[/red] unreadable status file: {exc}")
        raise typer.Exit(code=1) from exc

    age = time.time() - float(payload.get("ts", 0)) / 1000.0
    problems: list[str] = []
    if age > max_age:
        problems.append(f"last heartbeat {age:.0f}s ago (limit {max_age:.0f}s)")
    if str(payload.get("risk_state")) == "halted":
        problems.append("kill-switch is engaged — a human must reset it")
    excluded = payload.get("excluded_symbols") or {}
    configured = payload.get("symbols") or []
    if excluded and configured and len(excluded) >= len(configured):
        problems.append("every symbol failed the data-quality gate")

    if problems:
        console.print("[red]UNHEALTHY[/red] " + "; ".join(problems))
        raise typer.Exit(code=1)

    # Partial degradation is its own state. Dropping two of three symbols turns a
    # diversified portfolio into a single-name bet, and calling that "healthy"
    # because the process is alive is how a degraded book goes unnoticed for weeks.
    summary = (
        f"mode={payload.get('mode')} cycles={payload.get('cycles')} "
        f"equity={payload.get('equity')} heartbeat {age:.0f}s ago"
    )
    if excluded:
        detail = "; ".join(f"{sym}: {why}" for sym, why in excluded.items())
        if strict:
            console.print(f"[red]DEGRADED[/red] {summary} — excluded: {detail}")
            raise typer.Exit(code=2)
        console.print(f"[yellow]DEGRADED[/yellow] {summary} — excluded: {detail}")
        return
    console.print(f"[green]HEALTHY[/green] {summary}")


@app.command()
def status(
    config: Path = typer.Option(None, "--config", "-c"),
) -> None:
    """Show the last heartbeat written by a running agent."""
    s = _settings(config)
    path = s.data.root.parent / "live_status.json"
    if not path.exists():
        console.print("[yellow]No agent status file found.[/yellow]")
        raise typer.Exit(code=1)
    console.print_json(path.read_text(encoding="utf-8"))


def _verdict(report) -> str:
    """One-line tradability verdict from a QualityReport."""
    if report.bad_fraction > 0.02:
        return "[red]UNTRADEABLE — corrupt closes[/red]"
    if report.wick_fraction > 0.25:
        return "[red]UNTRADEABLE — ATR built on noise[/red]"
    if report.wick_fraction > 0.05:
        return "[yellow]usable, noisy wicks[/yellow]"
    return "[green]OK[/green]"


def _ts(ms: int | None) -> str:
    if not ms:
        return "-"
    return time.strftime("%Y-%m-%d %H:%M", time.gmtime(ms / 1000))


if __name__ == "__main__":
    app()
