"""Typed configuration: YAML file for structure, environment for secrets.

Precedence (highest first): explicit init kwargs -> ALPHA_* env vars -> YAML -> defaults.
Nested env override uses a double underscore, e.g.
    ALPHA_BYBIT__API_KEY=...  ALPHA_RISK__MAX_GROSS_LEVERAGE=1.5
Secrets are `SecretStr`, so they never leak through repr/str or structured logs.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, ClassVar

import yaml
from pydantic import BaseModel, Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict

#: Where the *running* application lives: its data, reports and config. This is
#: the working directory, not the source tree, because in a container or a
#: `pip install` deployment there is no source tree — and deriving it from
#: `__file__` produced paths inside site-packages, which are read-only and
#: config-less.
APP_ROOT = Path.cwd()
#: Where this package's own files live, for locating a bundled default config.
PACKAGE_ROOT = Path(__file__).resolve().parent


def default_config_path() -> Path:
    """Find `default.yaml`, in order of how explicit the answer is.

    The order matters. Deriving the path from `__file__` alone silently disabled
    the configuration for every non-editable install: the file was looked for
    inside site-packages, not found, and the settings quietly fell back to the
    Python defaults — including an empty `strategy.params` and a different risk
    profile. Silent fallback to a *different* configuration is worse than a crash,
    so when nothing is found we say so loudly (see `load_settings`).
    """
    env = os.getenv("ALPHA_CONFIG")
    candidates = [
        Path(env).expanduser() if env else None,
        APP_ROOT / "config" / "default.yaml",          # deployment layout
        PACKAGE_ROOT / "config" / "default.yaml",      # bundled inside the wheel
        PACKAGE_ROOT.parents[1] / "config" / "default.yaml",  # source checkout
    ]
    for candidate in candidates:
        if candidate is not None and candidate.exists():
            return candidate
    return APP_ROOT / "config" / "default.yaml"


DEFAULT_CONFIG_PATH = default_config_path()


class BybitConfig(BaseModel):
    category: str = "linear"
    testnet: bool = True
    api_key: SecretStr = SecretStr("")
    api_secret: SecretStr = SecretStr("")
    recv_window: int = 5000
    timeout_s: float = 15.0
    max_retries: int = 4
    #: Injected for tests; when None the URL is derived from `testnet`.
    base_url_override: str | None = None

    @property
    def rest_url(self) -> str:
        if self.base_url_override:
            return self.base_url_override.rstrip("/")
        return "https://api-testnet.bybit.com" if self.testnet else "https://api.bybit.com"

    @property
    def ws_public_url(self) -> str:
        return "wss://stream-testnet.bybit.com/v5/public/linear" if self.testnet else "wss://stream.bybit.com/v5/public/linear"

    @property
    def ws_private_url(self) -> str:
        return "wss://stream-testnet.bybit.com/v5/private" if self.testnet else "wss://stream.bybit.com/v5/private"

    @property
    def has_credentials(self) -> bool:
        return bool(self.api_key.get_secret_value()) and bool(self.api_secret.get_secret_value())


class DataConfig(BaseModel):
    root: Path = APP_ROOT / "data" / "raw"
    symbols: list[str] = Field(default_factory=lambda: ["BTCUSDT", "ETHUSDT"])
    interval: str = "60"  # Bybit V5 interval string: 1,5,15,60,240,D
    history_days: int = 365
    #: A symbol whose live feed exceeds this share of corrupt *closes* is not
    #: traded at all. Cleaning is not a licence to trade: repaired data is an
    #: estimate, and sizing real positions on estimates of the price is how a bad
    #: feed becomes a bad position. The agent skips the symbol instead.
    max_bad_bar_fraction: float = 0.02
    #: Beyond this share of clamped wicks the ATR — and therefore every stop and
    #: every position size — is guesswork, so the symbol is skipped too.
    max_wick_fraction: float = 0.25


class CostsConfig(BaseModel):
    """Cost model. Wrong costs are the #1 reason a backtest lies."""

    taker_fee_bps: float = 5.5
    maker_fee_bps: float = 2.0
    #: Base slippage applied to every fill, in bps of traded notional.
    slippage_bps: float = 2.0
    #: Extra slippage proportional to ATR/price — hurts in fast markets, like reality.
    slippage_atr_mult: float = 0.05
    #: Apply funding payments on perpetual positions.
    funding_enabled: bool = True


class RiskConfig(BaseModel):
    initial_equity: float = 10_000.0
    #: Annualised portfolio volatility target. The single most important knob.
    target_annual_vol: float = 0.25
    vol_lookback_bars: int = 240
    #: Scale the *whole book* to the vol target, not just each asset individually.
    #: Per-asset scaling undershoots badly on a cross-sectionally demeaned book,
    #: because hedging cancels most of the risk the per-asset scaling measured.
    scale_to_target_vol: bool = True
    #: Cap on that portfolio-level multiplier, so a temporarily calm estimate
    #: cannot lever the book up without limit.
    max_portfolio_scale: float = 3.0
    #: Bars of returns used for the ex-ante correlation estimate (strictly past data).
    corr_lookback_bars: int = 500
    #: Recompute the correlation matrix every N bars (it is a slow-moving quantity).
    corr_refresh_bars: int = 24
    max_gross_leverage: float = 2.0
    max_net_exposure: float = 1.5
    max_symbol_weight: float = 0.5
    max_concurrent_positions: int = 4
    #: Fraction of the vol-targeted size actually taken (fractional Kelly discipline).
    risk_scale: float = 1.0
    #: Skip trades smaller than this fraction of the *position being adjusted*.
    #: Deliberately not a fraction of equity: an equity-relative threshold means
    #: different things at different book sizes, so a small book churns while a
    #: fully-invested one sits still, for no reason anyone chose.
    rebalance_threshold: float = 0.10
    min_order_notional: float = 20.0
    #: Hard stop: flatten everything at this drawdown from peak equity.
    #:
    #: This MUST be set relative to `target_annual_vol`, not picked as a round
    #: number. The expected worst drawdown of a vol-targeted book over a year is
    #: roughly 1.5-2x its annual volatility, so a 20% stop on a 25%-vol strategy
    #: sits *inside* the normal noise band and will stop a perfectly healthy book —
    #: we measured exactly that: a driftless random walk halted the strategy after
    #: 28 days. `alpha check` enforces the relationship.
    max_drawdown_kill: float = 0.35
    #: Start scaling risk down linearly once drawdown passes this level.
    reduce_at_drawdown: float = 0.15
    #: Daily stop, in standard deviations of a one-day move (see killswitch.py).
    daily_loss_sigmas: float = 4.0
    #: Absolute floor for the daily stop.
    daily_loss_limit: float = 0.02
    #: Rolling-window stop, in standard deviations of that window's move.
    rolling_loss_sigmas: float = 3.0
    #: Absolute floor for the rolling stop.
    rolling_loss_limit: float = 0.05
    rolling_loss_days: int = 20
    #: Flatten if market data is older than this (seconds) — protects against dead feeds.
    max_data_staleness_s: int = 180
    #: Cap on how much of a bar's traded volume one order may represent.
    max_participation: float = 0.001


class ExecutionConfig(BaseModel):
    dry_run: bool = True
    order_type: str = "Market"
    post_only_would_cross_bps: float = 0.0


class StrategyConfig(BaseModel):
    name: str = "ensemble"
    params: dict[str, Any] = Field(default_factory=dict)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="ALPHA_",
        env_nested_delimiter="__",
        extra="ignore",
        case_sensitive=False,
    )

    _yaml_path: ClassVar[Path | None] = None

    mode: str = "backtest"  # backtest | paper | live
    bybit: BybitConfig = Field(default_factory=BybitConfig)
    data: DataConfig = Field(default_factory=DataConfig)
    costs: CostsConfig = Field(default_factory=CostsConfig)
    risk: RiskConfig = Field(default_factory=RiskConfig)
    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)
    strategy: StrategyConfig = Field(default_factory=StrategyConfig)

    @model_validator(mode="after")
    def _guard_live_mode(self) -> Settings:
        if self.mode == "live":
            if self.bybit.testnet and self.execution.dry_run:
                # Live mode against testnet with dry_run is a contradiction worth flagging.
                pass
            if not self.bybit.has_credentials:
                raise ValueError(
                    "mode=live requires ALPHA_BYBIT__API_KEY and ALPHA_BYBIT__API_SECRET"
                )
        return self

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (init_settings, env_settings, _YamlSettingsSource(settings_cls), dotenv_settings)


class _YamlSettingsSource(PydanticBaseSettingsSource):
    def __init__(self, settings_cls: type[BaseSettings]) -> None:
        super().__init__(settings_cls)
        path = Settings._yaml_path
        if path is None:
            path = default_config_path()
        self._path = Path(path)
        self._data: dict[str, Any] = {}
        if self._path.exists():
            raw = yaml.safe_load(self._path.read_text(encoding="utf-8")) or {}
            if not isinstance(raw, dict):
                raise ValueError(f"config {self._path} must be a YAML mapping")
            self._data = raw

    def get_field_value(self, field, field_name):  # noqa: ANN001, ANN201 - pydantic hook
        return self._data.get(field_name), field_name, False

    def __call__(self) -> dict[str, Any]:
        return self._data


def load_settings(config_path: str | Path | None = None, **overrides: Any) -> Settings:
    """Build Settings from YAML + env. `overrides` win over everything.

    Emits a loud warning when no config file could be located. Running on Python
    defaults is occasionally correct (tests, a quick experiment) and usually a
    mistake (a deployment that silently lost its risk limits), and the difference
    is invisible unless someone says it out loud.
    """
    resolved = Path(config_path) if config_path is not None else default_config_path()
    if not resolved.exists():
        logging.getLogger("alpha.config").warning(
            "no config file found (looked for %s and ALPHA_CONFIG); running on built-in "
            "defaults — strategy params will be EMPTY and the risk profile may differ "
            "from the one you validated",
            resolved,
        )
    Settings._yaml_path = resolved
    try:
        return Settings(**overrides)
    finally:
        Settings._yaml_path = None
