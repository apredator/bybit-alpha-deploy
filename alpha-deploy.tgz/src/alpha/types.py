"""Core domain types shared by every layer.

Kept deliberately small and dependency-free (except pandas/Decimal-free floats)
so that strategy, risk, backtest and execution all speak the same language.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum


class Side(StrEnum):
    BUY = "Buy"
    SELL = "Sell"

    @property
    def sign(self) -> int:
        return 1 if self is Side.BUY else -1

    def opposite(self) -> Side:
        return Side.SELL if self is Side.BUY else Side.BUY


class OrderType(StrEnum):
    MARKET = "Market"
    LIMIT = "Limit"


class OrderStatus(StrEnum):
    NEW = "New"
    PARTIALLY_FILLED = "PartiallyFilled"
    FILLED = "Filled"
    CANCELLED = "Cancelled"
    REJECTED = "Rejected"


@dataclass(frozen=True, slots=True)
class Bar:
    """A single OHLCV candle. `ts` is the candle OPEN time, in ms UTC."""

    ts: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    turnover: float = 0.0

    @property
    def typical(self) -> float:
        return (self.high + self.low + self.close) / 3.0


@dataclass(slots=True)
class Order:
    """An intent to trade. `client_id` is the idempotency key (Bybit orderLinkId)."""

    symbol: str
    side: Side
    qty: float
    order_type: OrderType = OrderType.MARKET
    price: float | None = None
    client_id: str = ""
    reduce_only: bool = False
    status: OrderStatus = OrderStatus.NEW
    filled_qty: float = 0.0
    avg_price: float = 0.0
    fee: float = 0.0
    ts: int = 0
    broker_id: str = ""


@dataclass(slots=True)
class Fill:
    symbol: str
    side: Side
    qty: float
    price: float
    fee: float
    ts: int
    client_id: str = ""
    slippage_bps: float = 0.0


@dataclass(slots=True)
class Position:
    """Net position in one symbol. `qty` is signed (negative = short)."""

    symbol: str
    qty: float = 0.0
    avg_price: float = 0.0
    realized_pnl: float = 0.0
    fees_paid: float = 0.0

    @property
    def is_flat(self) -> bool:
        return abs(self.qty) < 1e-12

    @property
    def notional(self) -> float:
        return self.qty * self.avg_price

    @property
    def direction(self) -> int:
        if self.qty > 0:
            return 1
        if self.qty < 0:
            return -1
        return 0

    def unrealized(self, mark: float) -> float:
        return self.qty * (mark - self.avg_price)


@dataclass(slots=True)
class TargetPosition:
    """What a strategy wants to hold at a point in time.

    `weight` is a signed fraction of equity (e.g. 0.35 = long 35% of equity,
    -0.20 = short 20%). Strategies emit *weights*, risk converts to contracts —
    this is what keeps sizing in one place instead of scattered across strategies.
    """

    symbol: str
    weight: float
    ts: int
    reason: str = ""
    stop_price: float | None = None
    meta: dict[str, float] = field(default_factory=dict)


@dataclass(slots=True)
class AccountState:
    equity: float
    cash: float
    peak_equity: float
    ts: int
    positions: dict[str, Position] = field(default_factory=dict)
    day_start_equity: float = 0.0

    @property
    def drawdown(self) -> float:
        if self.peak_equity <= 0:
            return 0.0
        return 1.0 - self.equity / self.peak_equity
