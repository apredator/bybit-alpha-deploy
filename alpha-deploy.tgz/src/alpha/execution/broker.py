"""Broker abstraction and the order-planning logic shared by paper and live.

The single most dangerous piece of code in a trading system is the one that turns
"target position" into "order". Get it wrong and you can double a position, open
one when you meant to close, or fire a duplicate after a timeout. So the planning
is a pure function, unit-testable, with the safety rules written down:

  * **Reduce-only** is used whenever an order shrinks an existing position, so a
    mis-signed size can never flip you into an accidental new direction.
  * **Flips are two orders**, not one. Close first, then open. A single oversized
    order that crosses zero is the classic way to trade twice the intended size.
  * **Idempotency**: every order carries a deterministic client id derived from
    (strategy, symbol, target, bar). A retry after a timeout is a no-op rather
    than a second position.
  * **Rounding is toward zero**, so exchange step-size rounding never increases
    exposure.
"""

from __future__ import annotations

import hashlib
import time
from abc import ABC, abstractmethod

from alpha.log import get_logger
from alpha.risk.sizing import InstrumentSpec
from alpha.types import AccountState, Order, OrderStatus, OrderType, Position, Side

log = get_logger("alpha.execution")


def make_client_id(namespace: str, symbol: str, target_qty: float, ts: int, seq: int = 0) -> str:
    """Deterministic idempotency key.

    Bybit deduplicates on `orderLinkId`, so deriving it from the *intent* rather
    than a random uuid means a network retry cannot create a second position.
    """
    raw = f"{namespace}|{symbol}|{target_qty:.10f}|{ts}|{seq}"
    digest = hashlib.sha1(raw.encode()).hexdigest()[:20]
    return f"{namespace[:8]}-{digest}"


class Broker(ABC):
    """Everything the agent is allowed to do to the outside world."""

    name: str = "broker"

    @abstractmethod
    def account_state(self) -> AccountState: ...

    @abstractmethod
    def positions(self) -> dict[str, Position]: ...

    @abstractmethod
    def mark_prices(self, symbols: list[str]) -> dict[str, float]: ...

    @abstractmethod
    def submit(
        self,
        orders: list[Order],
        *,
        equity: float | None = None,
        marks: dict[str, float] | None = None,
        wait: bool = True,
    ) -> list[Order]: ...

    @abstractmethod
    def cancel_all(self, symbol: str) -> None: ...

    def reconcile(self) -> list[str]:
        """Compare local expectations with the venue. Overridden where meaningful."""
        return []

    def flatten(self, symbols: list[str]) -> list[Order]:
        """Emergency flatten — the kill-switch path.

        Defined once, in terms of `positions()` and `submit()`, so paper and live
        cannot diverge on the one code path that runs when things are already bad.
        Every order is reduce-only: an emergency exit must never be able to open a
        new position, whatever the state of our local view.
        """
        positions = self.positions()
        orders: list[Order] = []
        marker = f"flat-{int(time.time())}"
        for symbol in symbols:
            pos = positions.get(symbol)
            if pos is None or pos.qty == 0:
                continue
            orders.append(
                Order(
                    symbol=symbol,
                    side=Side.SELL if pos.qty > 0 else Side.BUY,
                    qty=abs(pos.qty),
                    reduce_only=True,
                    client_id=f"{marker}-{symbol}",
                    status=OrderStatus.NEW,
                )
            )
        if not orders:
            return []
        marks = self.mark_prices(symbols)
        return self.submit(orders, marks=marks)


def plan_orders(
    symbol: str,
    current_qty: float,
    target_qty: float,
    spec: InstrumentSpec,
    price: float,
    *,
    ts: int,
    namespace: str = "alpha",
    order_type: OrderType = OrderType.MARKET,
    eps: float = 1e-12,
) -> list[Order]:
    """Turn a position change into the minimal set of safe orders.

    Returns a list because flipping a position is deliberately two orders.
    """
    delta = target_qty - current_qty
    if abs(delta) <= eps or price <= 0:
        return []

    orders: list[Order] = []
    seq = 0

    def _order(qty: float, reduce_only: bool) -> Order | None:
        nonlocal seq
        normalised = spec.normalise(abs(qty), price)
        if normalised == 0.0:
            return None
        seq += 1
        return Order(
            symbol=symbol,
            side=Side.BUY if qty > 0 else Side.SELL,
            qty=normalised,
            order_type=order_type,
            client_id=make_client_id(namespace, symbol, target_qty, ts, seq),
            reduce_only=reduce_only,
        )

    closing = current_qty != 0.0 and (delta * current_qty < 0)
    if closing:
        # Step 1: shrink or close the existing exposure, reduce-only.
        close_qty = min(abs(delta), abs(current_qty))
        closing_order = _order(close_qty if delta > 0 else -close_qty, reduce_only=True)
        if closing_order:
            orders.append(closing_order)
        # Step 2: if we crossed through zero, the remainder is a genuine new position.
        if abs(delta) > abs(current_qty):
            remainder = delta - (close_qty if delta > 0 else -close_qty)
            opening_order = _order(remainder, reduce_only=False)
            if opening_order:
                orders.append(opening_order)
    else:
        single = _order(delta, reduce_only=False)
        if single:
            orders.append(single)

    return orders


def validate_order(order: Order, spec: InstrumentSpec, price: float, equity: float, max_leverage: float) -> str | None:
    """Pre-trade sanity check. Returns a rejection reason, or None if the order is fine.

    Cheap checks like these catch the embarrassing bugs (a wrong decimal, a unit
    mix-up) before the exchange does — or before it does not.
    """
    if order.qty <= 0:
        return "non-positive quantity"
    if price <= 0:
        return "non-positive price"
    notional = order.qty * price
    if notional < spec.min_notional:
        return f"notional {notional:.2f} below exchange minimum {spec.min_notional:.2f}"
    if order.qty < spec.min_qty:
        return f"qty {order.qty} below exchange minimum {spec.min_qty}"
    if abs(order.qty - spec.round_qty(order.qty)) > 1e-9:
        return f"qty {order.qty} is not aligned to step {spec.qty_step}"
    if not order.reduce_only and notional > equity * max_leverage:
        return f"notional {notional:.2f} exceeds {max_leverage}x equity {equity:.2f}"
    return None
