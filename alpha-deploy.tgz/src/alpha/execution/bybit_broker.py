"""Live broker for Bybit V5.

The rules this file exists to enforce:

1. **Reconcile before you trade.** The exchange is the source of truth for
   positions. A local view that has drifted (a fill we never saw, a manual
   intervention, a liquidation) must be detected and used, not overwritten.
2. **Idempotent orders.** Every order carries a deterministic `orderLinkId`;
   a retry after a timeout cannot open a second position.
3. **Reduce-only when reducing.** Never a mis-signed size in the wrong direction.
4. **Confirm fills.** Placing an order is not the same as being filled. We poll
   the order status and report the real average price and fee.
5. **Dry run is a first-class mode.** `dry_run` does everything except send.

Nothing in this file contains a strategy decision. It executes what the risk
engine approved, and it refuses to guess.
"""

from __future__ import annotations

import time

from alpha.config import Settings
from alpha.data.bybit_rest import DUPLICATE_ORDER_CODES, BybitError, BybitREST
from alpha.execution.broker import Broker, validate_order
from alpha.log import get_logger
from alpha.portfolio import PortfolioLedger
from alpha.risk.sizing import InstrumentSpec
from alpha.types import AccountState, Order, OrderStatus, Position

log = get_logger("alpha.execution.bybit")

FILL_TIMEOUT_S = 10.0
FILL_POLL_INTERVAL_S = 0.35


def fetch_specs(rest: BybitREST, symbols: list[str]) -> dict[str, InstrumentSpec]:
    """Build `InstrumentSpec`s from the exchange's own contract metadata.

    Hardcoding tick sizes is a classic self-inflicted outage: the exchange changes
    a step size and every order starts being rejected, or worse, silently rounds.
    """
    specs: dict[str, InstrumentSpec] = {}
    for symbol in symbols:
        try:
            info = rest.instruments_info(symbol)
        except BybitError as exc:
            log.warning("cannot load instrument info", extra={"extra_fields": {"symbol": symbol, "err": str(exc)}})
            continue
        lot = info.get("lotSizeFilter", {})
        price_filter = info.get("priceFilter", {})
        specs[symbol] = InstrumentSpec(
            symbol=symbol,
            qty_step=float(lot.get("qtyStep", 0.001) or 0.001),
            min_qty=float(lot.get("minOrderQty", 0.001) or 0.001),
            max_qty=float(lot.get("maxOrderQty", 1_000_000) or 1_000_000),
            min_notional=float(lot.get("minNotionalValue", 5.0) or 5.0),
            contract_size=1.0,
            max_leverage=float(info.get("leverageFilter", {}).get("maxLeverage", 25) or 25),
        )
        _ = price_filter  # tick size is only needed for limit pricing; kept for future use
    return specs


def _signed_position(item: dict) -> float:
    size = float(item.get("size", 0) or 0)
    if size == 0:
        return 0.0
    return size if str(item.get("side", "")).lower() == "buy" else -size


class BybitBroker(Broker):
    name = "bybit"

    def __init__(self, settings: Settings, rest: BybitREST, *, dry_run: bool | None = None) -> None:
        self.settings = settings
        self.rest = rest
        self.dry_run = settings.execution.dry_run if dry_run is None else dry_run
        self.ledger = PortfolioLedger(cash=0.0)
        self.specs: dict[str, InstrumentSpec] = {}
        self.last_reconcile_notes: list[str] = []

    # ----------------------------------------------------------------- setup
    def prepare(self, symbols: list[str]) -> None:
        self.specs = fetch_specs(self.rest, symbols)
        log.info(
            "instrument specs loaded",
            extra={"extra_fields": {"symbols": sorted(self.specs), "dry_run": self.dry_run}},
        )

    def spec(self, symbol: str) -> InstrumentSpec:
        return self.specs.get(symbol) or InstrumentSpec(symbol=symbol)

    # ------------------------------------------------------------- read side
    def mark_prices(self, symbols: list[str]) -> dict[str, float]:
        marks: dict[str, float] = {}
        for symbol in symbols:
            try:
                ticker = self.rest.ticker(symbol)
            except BybitError as exc:
                log.warning("ticker failed", extra={"extra_fields": {"symbol": symbol, "err": str(exc)}})
                continue
            price = ticker.get("markPrice") or ticker.get("lastPrice")
            if price:
                marks[symbol] = float(price)
        return marks

    def positions(self) -> dict[str, Position]:
        out: dict[str, Position] = {}
        for item in self.rest.positions():
            qty = _signed_position(item)
            if qty == 0:
                continue
            out[item["symbol"]] = Position(
                symbol=item["symbol"],
                qty=qty,
                avg_price=float(item.get("avgPrice", 0) or 0),
                realized_pnl=float(item.get("cumRealisedPnl", 0) or 0),
            )
        return out

    def account_state(self) -> AccountState:
        balance = self.rest.wallet_balance()
        equity = 0.0
        for account in balance.get("list", []):
            equity = float(account.get("totalEquity", 0) or 0)
            break
        positions = self.positions()
        marks = self.mark_prices(sorted(positions))
        self.ledger.cash = equity  # treat exchange equity as the cash base for reporting
        self.ledger.positions = dict(positions)
        return self.ledger.snapshot(int(time.time() * 1000), marks)

    # ----------------------------------------------------------- reconcile
    def reconcile(self) -> list[str]:
        """Compare local expectations against the venue and return drift notes."""
        notes: list[str] = []
        try:
            venue = self.positions()
        except BybitError as exc:
            return [f"reconcile failed: {exc}"]

        local = {s: p for s, p in self.ledger.positions.items() if p.qty != 0.0}
        for symbol in set(venue) | set(local):
            venue_pos = venue.get(symbol)
            local_pos = local.get(symbol)
            v_qty = venue_pos.qty if venue_pos else 0.0
            l_qty = local_pos.qty if local_pos else 0.0
            if abs(v_qty - l_qty) > 1e-9:
                notes.append(f"{symbol}: local {l_qty} != venue {v_qty} — adopting venue state")
                self.ledger.positions[symbol] = venue_pos or Position(symbol=symbol)

        # Orders we think are open but that the venue does not know about.
        try:
            open_orders = self.rest.open_orders()
        except BybitError:
            open_orders = []
        if open_orders:
            notes.append(f"{len(open_orders)} order(s) still open at the venue: {[o.get('orderLinkId') for o in open_orders[:5]]}")

        self.last_reconcile_notes = notes
        for note in notes:
            log.warning("reconcile", extra={"extra_fields": {"detail": note}})
        return notes

    # ------------------------------------------------------------ write side
    def submit(
        self,
        orders: list[Order],
        *,
        equity: float | None = None,
        marks: dict[str, float] | None = None,
        wait: bool = True,
    ) -> list[Order]:
        results: list[Order] = []
        marks = marks or {}
        max_lev = self.settings.risk.max_gross_leverage

        for order in orders:
            spec = self.spec(order.symbol)
            price = marks.get(order.symbol) or self.mark_prices([order.symbol]).get(order.symbol, 0.0)
            problem = validate_order(order, spec, price, equity or 0.0, max_lev)
            if problem:
                order.status = OrderStatus.REJECTED
                log.error(
                    "pre-trade check failed — order NOT sent",
                    extra={"extra_fields": {"symbol": order.symbol, "reason": problem}},
                )
                results.append(order)
                continue

            if self.dry_run:
                log.info(
                    "DRY RUN — order not sent",
                    extra={
                        "extra_fields": {
                            "symbol": order.symbol,
                            "side": order.side.value,
                            "qty": order.qty,
                            "reduce_only": order.reduce_only,
                            "client_id": order.client_id,
                        }
                    },
                )
                order.status = OrderStatus.NEW
                results.append(order)
                continue

            try:
                response = self.rest.place_order(
                    symbol=order.symbol,
                    side=order.side.value,
                    qty=order.qty,
                    order_type=order.order_type.value,
                    price=order.price,
                    reduce_only=order.reduce_only,
                    client_id=order.client_id,
                )
            except BybitError as exc:
                if exc.code in DUPLICATE_ORDER_CODES:
                    log.warning("duplicate order ignored", extra={"extra_fields": {"client_id": order.client_id}})
                    order.status = OrderStatus.NEW
                    results.append(order)
                    continue
                order.status = OrderStatus.REJECTED
                log.error("order rejected", extra={"extra_fields": {"symbol": order.symbol, "err": str(exc)}})
                results.append(order)
                continue

            order.broker_id = str(response.get("orderId", ""))
            if wait:
                order = self._await_fill(order)
            results.append(order)
        return results

    def _await_fill(self, order: Order) -> Order:
        """Poll until the order is filled or we give up. Never assume a fill."""
        deadline = time.time() + FILL_TIMEOUT_S
        while time.time() < deadline:
            try:
                orders = self.rest.open_orders(order.symbol)
            except BybitError:
                time.sleep(FILL_POLL_INTERVAL_S)
                continue
            match = next((o for o in orders if o.get("orderLinkId") == order.client_id), None)
            if match is None:
                # No longer open: either filled or cancelled. We cannot tell from
                # here without a history call, so we report it as filled-with-unknown
                # price and let reconciliation settle the truth.
                order.status = OrderStatus.FILLED
                order.filled_qty = order.qty
                log.info("order left the book", extra={"extra_fields": {"client_id": order.client_id}})
                return order
            status = str(match.get("orderStatus", ""))
            if status in ("Filled", "PartiallyFilled"):
                order.status = OrderStatus(status)
                order.filled_qty = float(match.get("cumExecQty", 0) or 0)
                order.avg_price = float(match.get("avgPrice", 0) or 0)
                order.fee = float(match.get("cumExecFee", 0) or 0)
                return order
            if status in ("Cancelled", "Rejected", "Deactivated"):
                order.status = OrderStatus(status) if status in ("Cancelled", "Rejected") else OrderStatus.CANCELLED
                return order
            time.sleep(FILL_POLL_INTERVAL_S)

        log.error(
            "order not confirmed within timeout — reconcile before the next cycle",
            extra={"extra_fields": {"client_id": order.client_id, "symbol": order.symbol}},
        )
        order.status = OrderStatus.NEW
        return order

    def cancel_all(self, symbol: str) -> None:
        if self.dry_run:
            return
        try:
            self.rest.cancel_all(symbol)
        except BybitError as exc:
            log.warning("cancel_all failed", extra={"extra_fields": {"symbol": symbol, "err": str(exc)}})
