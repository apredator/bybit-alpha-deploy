"""Paper broker — the same agent loop, no money at risk.

Runs the identical decision path as live but fills against mark prices with the
simulator's cost model. This is what you run for weeks before going live, and it
is the only cheap way to catch the operational bugs (bad symbols, wrong order
sizes, a loop that trades every bar, clock skew) that have nothing to do with the
strategy's edge.

It intentionally shares `PortfolioLedger` and the cost model with the backtester:
if paper results and backtest results disagree, the difference is execution
timing and market conditions, not two divergent implementations of arithmetic.
"""

from __future__ import annotations

from collections.abc import Callable

from alpha.config import Settings
from alpha.execution.broker import Broker
from alpha.log import get_logger
from alpha.portfolio import PortfolioLedger
from alpha.types import AccountState, Order, OrderStatus, Position

log = get_logger("alpha.execution.paper")

#: A price source is anything that can answer "what is the mark for these symbols".
PriceSource = Callable[[list[str]], dict[str, float]]


class PaperBroker(Broker):
    name = "paper"

    def __init__(
        self,
        settings: Settings,
        price_source: PriceSource,
        *,
        ledger: PortfolioLedger | None = None,
        initial_equity: float | None = None,
    ) -> None:
        self.settings = settings
        self.price_source = price_source
        self.ledger = ledger or PortfolioLedger(
            cash=float(initial_equity if initial_equity is not None else settings.risk.initial_equity)
        )
        self.fills: list[dict] = []

    # ------------------------------------------------------------- read side
    def mark_prices(self, symbols: list[str]) -> dict[str, float]:
        return self.price_source(symbols)

    def positions(self) -> dict[str, Position]:
        return {s: p for s, p in self.ledger.positions.items() if p.qty != 0.0}

    def account_state(self) -> AccountState:
        marks = self.mark_prices(sorted(self.ledger.positions))
        return self.ledger.snapshot(0, marks)

    # ------------------------------------------------------------ write side
    def submit(
        self,
        orders: list[Order],
        *,
        equity: float | None = None,
        marks: dict[str, float] | None = None,
        wait: bool = True,
    ) -> list[Order]:
        if not orders:
            return []
        marks = marks or self.mark_prices(sorted({o.symbol for o in orders}))
        costs = self.settings.costs
        filled: list[Order] = []

        for order in orders:
            price = marks.get(order.symbol, 0.0)
            if price <= 0:
                order.status = OrderStatus.REJECTED
                log.warning("paper order rejected: no mark price", extra={"extra_fields": {"symbol": order.symbol}})
                filled.append(order)
                continue

            atr_frac = 0.0
            slip_bps = costs.slippage_bps + costs.slippage_atr_mult * atr_frac * 1e4
            slip = slip_bps / 1e4
            signed = order.qty if order.side.value == "Buy" else -order.qty

            # Honour reduce-only the same way the exchange would: never let such an
            # order increase exposure.
            held = self.ledger.qty(order.symbol)
            if order.reduce_only and held != 0 and signed * held > 0:
                signed = 0.0

            fill_price = price * (1.0 + slip) if signed > 0 else price * (1.0 - slip)
            notional = abs(signed) * fill_price
            fee = notional * costs.taker_fee_bps / 1e4 if signed else 0.0

            if signed:
                self.ledger.apply_fill(order.symbol, signed, fill_price, fee)
                self.fills.append(
                    {
                        "symbol": order.symbol,
                        "qty": signed,
                        "price": fill_price,
                        "fee": fee,
                        "client_id": order.client_id,
                    }
                )

            order.status = OrderStatus.FILLED if signed else OrderStatus.CANCELLED
            order.filled_qty = abs(signed)
            order.avg_price = fill_price
            order.fee = fee
            filled.append(order)
            log.info(
                "paper fill",
                extra={
                    "extra_fields": {
                        "symbol": order.symbol,
                        "qty": round(signed, 8),
                        "price": round(fill_price, 4),
                        "fee": round(fee, 4),
                        "reduce_only": order.reduce_only,
                    }
                },
            )
        return filled

    def cancel_all(self, symbol: str) -> None:
        return None

    def apply_funding(self, rate_by_symbol: dict[str, float]) -> float:
        """Paper books must pay funding too, or they flatter a carry strategy."""
        total = 0.0
        marks = self.mark_prices(sorted(rate_by_symbol))
        for symbol, rate in rate_by_symbol.items():
            total += self.ledger.apply_funding(symbol, rate, marks.get(symbol, 0.0))
        return total
