#!/usr/bin/env bash
#
# Install and start the agent from a single pasted command, with no SSH.
#
#   curl -fsSL <INSTALLER_URL> | sudo bash
#
# For hosts whose network cannot sustain an interactive SSH session (the console
# works, plain TCP works, but the SSH handshake stalls). The agent is fetched as
# an archive, unpacked, built and started in PAPER mode.
#
# Idempotent: re-running it re-fetches, rebuilds and restarts.

set -euo pipefail

# Mirrors, tried in order. Plain HTTPS file hosts; the archive contains no secrets.
ARCHIVE_URLS=(
  "__ARCHIVE_URL_A__"
)
APP_DIR="${APP_DIR:-/opt/alpha/bybit-alpha}"
CONTAINER_UID=10001            # matches the USER in the Dockerfile

say()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[33mWARN\033[0m %s\n' "$*"; }
die()  { printf '\033[31mFAIL\033[0m %s\n' "$*" >&2; exit 1; }

[[ "$(id -u)" -eq 0 ]] || die "run as root:  curl -fsSL <url> | sudo bash"

# Validate the *shape* of the URL rather than comparing it to a placeholder.
# The previous version used a sentinel string in this very line, so whatever
# mechanism substituted the URL also rewrote the check — the guard then compared
# the URL with itself and always failed.
for _u in "${ARCHIVE_URLS[@]}"; do
  [[ "$_u" =~ ^https?:// ]] || die "archive URL is not a valid http(s) URL: ${_u}"
done

# ------------------------------------------------------------------ 1. docker
say "1/6 Docker"
if command -v docker >/dev/null 2>&1; then
  echo "  present: $(docker --version)"
else
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq ca-certificates curl tar >/dev/null
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc 2>/dev/null || true
  chmod a+r /etc/apt/keyrings/docker.asc 2>/dev/null || true
  CODENAME=$(. /etc/os-release && echo "${VERSION_CODENAME:-}")
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
https://download.docker.com/linux/ubuntu ${CODENAME} stable" > /etc/apt/sources.list.d/docker.list
  # New Ubuntu releases are often absent from Docker's repository for weeks.
  if apt-get update -qq 2>/dev/null \
     && apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin >/dev/null 2>&1; then
    echo "  installed from the official repository"
  else
    warn "no Docker build for ${CODENAME:-this release}; falling back"
    rm -f /etc/apt/sources.list.d/docker.list
    apt-get update -qq
    if apt-get install -y -qq docker.io docker-compose-v2 >/dev/null 2>&1; then
      echo "  installed from the Ubuntu archive"
    else
      curl -fsSL https://get.docker.com | sh
    fi
  fi
  echo "  installed: $(docker --version)"
fi
systemctl enable --now docker >/dev/null 2>&1 || true
docker compose version >/dev/null 2>&1 || die "docker compose plugin is unavailable"

# ----------------------------------------------------------------- 2. timezone
say "2/6 Clock"
timedatectl set-timezone UTC 2>/dev/null || true
timedatectl set-ntp true 2>/dev/null || true
echo "  timezone: $(timedatectl show -p Timezone --value 2>/dev/null || echo UTC)"

# ---------------------------------------------------------------- 3. download
say "3/6 Fetching the agent"
mkdir -p "${APP_DIR}"
TMP=$(mktemp -d)
trap 'rm -rf "${TMP}"' EXIT
fetched=0
for _u in "${ARCHIVE_URLS[@]}"; do
  for _try in 1 2 3; do
    echo "  ${_u}  (attempt ${_try}/3)"
    if curl -fsSL --connect-timeout 20 -m 240 "${_u}" -o "${TMP}/agent.tgz" \
       && tar tzf "${TMP}/agent.tgz" >/dev/null 2>&1; then
      echo "  $(du -h "${TMP}/agent.tgz" | cut -f1) downloaded and verified"
      fetched=1
      break 2
    fi
    sleep $(( _try * 5 ))
  done
done
if [[ "$fetched" != "1" ]]; then
  die "could not download the agent from ${ARCHIVE_URLS[*]}.
     The server may be unable to reach that host. Check with:
       curl -sI ${ARCHIVE_URLS[0]}
     and tell whoever gave you this command — another transport can be arranged."
fi
tar xzf "${TMP}/agent.tgz" -C "${APP_DIR}"
echo "  unpacked to ${APP_DIR}"

# ------------------------------------------------------------------ 4. layout
say "4/6 Runtime directories"
mkdir -p "${APP_DIR}/data/raw" "${APP_DIR}/reports"
# The image runs as uid ${CONTAINER_UID}; bind-mounted volumes must be writable by it.
chown -R "${CONTAINER_UID}:${CONTAINER_UID}" "${APP_DIR}/data" "${APP_DIR}/reports"
chmod 755 "${APP_DIR}/data" "${APP_DIR}/reports"
if [[ ! -f "${APP_DIR}/.env" ]]; then
  cp "${APP_DIR}/.env.example" "${APP_DIR}/.env"
  chmod 600 "${APP_DIR}/.env"
  echo "  created .env from the template (paper mode needs no exchange keys)"
else
  echo "  .env already present, left alone"
fi

# -------------------------------------------------------------- 5. build/run
say "5/6 Building and starting in PAPER mode"
cd "${APP_DIR}"
docker compose build
docker compose up -d

# -------------------------------------------------------------- 6. verify
say "6/6 Verifying"
for i in $(seq 1 12); do
  sleep 10
  if docker compose exec -T agent alpha health 2>/dev/null; then
    echo
    echo "Agent is running in PAPER mode. Nothing here can place a real order."
    exit 0
  fi
  echo "  waiting for the first cycle ($i/12)..."
done
warn "health is not green yet — inspect the logs:"
docker compose logs --tail 40 agent || true
exit 1
