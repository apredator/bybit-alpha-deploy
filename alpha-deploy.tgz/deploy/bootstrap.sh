#!/usr/bin/env bash
#
# One-time server preparation for the trading agent.
# Run ON the server, as root (or with sudo):
#
#   ssh user@HOST 'sudo bash -s' < deploy/bootstrap.sh
#
# This script deliberately does NOT install the application code, does not start
# the agent, and never touches real money. It prepares the machine; `deploy.sh`
# ships the code and starts it in paper mode. Keeping the two apart means server
# preparation is idempotent and can be re-run at any time without consequences.

set -euo pipefail

APP_DIR="${APP_DIR:-/opt/alpha/bybit-alpha}"
APP_USER="${APP_USER:-alpha}"
ENV_DIR="/etc/alpha"
ENV_FILE="${ENV_DIR}/agent.env"

say() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[33mWARN\033[0m %s\n' "$*"; }
die() { printf '\033[31mFAIL\033[0m %s\n' "$*" >&2; exit 1; }

[[ "$(id -u)" -eq 0 ]] || die "must run as root (use: ssh user@HOST 'sudo bash -s' < deploy/bootstrap.sh)"

# ---------------------------------------------------------------- 1. platform
say "1/7 Checking the platform"
if [[ -r /etc/os-release ]]; then
  # shellcheck disable=SC1091
  . /etc/os-release
  echo "  ${PRETTY_NAME:-unknown}"
  [[ "${ID:-}" == "ubuntu" || "${ID_LIKE:-}" == *debian* ]] \
    || warn "expected Ubuntu/Debian, got ${ID:-unknown} — continuing anyway"
else
  warn "cannot identify the OS"
fi

TOTAL_MEM_MB=$(awk '/MemTotal/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 0)
if (( TOTAL_MEM_MB < 900 )); then
  warn "only ${TOTAL_MEM_MB} MB RAM. The agent is lightweight, but the Docker build"
  warn "may be killed by the OOM killer. 2 GB is comfortable."
fi

# ------------------------------------------------------------------- 2. clock
say "2/7 Timezone and clock synchronisation"
# These are not cosmetic. Bar boundaries and funding settlements are UTC, and
# Bybit rejects signed requests whose timestamp is outside the receive window —
# so a drifting clock silently stops the agent from trading at all.
timedatectl set-timezone UTC
timedatectl set-ntp true || warn "could not enable NTP via timedatectl"
apt-get update -qq
apt-get install -y -qq systemd-timesyncd >/dev/null 2>&1 || true
systemctl enable --now systemd-timesyncd >/dev/null 2>&1 || true
echo "  timezone : $(timedatectl show -p Timezone --value)"
echo "  NTP sync : $(timedatectl show -p NTPSynchronized --value)"
timedatectl show -p NTPSynchronized --value | grep -q yes \
  || warn "clock not yet synchronised — signed API requests may be rejected until it is"

# ------------------------------------------------------------------ 3. docker
say "3/7 Installing Docker"
if command -v docker >/dev/null 2>&1; then
  echo "  docker already present: $(docker --version)"
else
  # Docker's apt repository lags new Ubuntu releases: on a fresh 26.04 the
  # `$VERSION_CODENAME` entry often does not exist yet, `apt-get update` fails and
  # a naive install dies with a 404 on a Release file. Try the official repo first
  # because it gives the newer compose plugin, then fall back to the distribution
  # packages, then to Docker's own convenience script.
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc 2>/dev/null || true
  chmod a+r /etc/apt/keyrings/docker.asc 2>/dev/null || true
  CODENAME=$(. /etc/os-release && echo "${VERSION_CODENAME:-}")
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
https://download.docker.com/linux/ubuntu ${CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list

  if apt-get update -qq 2>/dev/null \
     && apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin >/dev/null 2>&1; then
    echo "  installed from the official Docker repository"
  else
    warn "official Docker repo has no build for ${CODENAME:-this release}; falling back"
    rm -f /etc/apt/sources.list.d/docker.list
    apt-get update -qq
    if apt-get install -y -qq docker.io docker-compose-v2 >/dev/null 2>&1; then
      echo "  installed from the Ubuntu archive (docker.io + docker-compose-v2)"
    else
      warn "distribution packages failed too; using Docker's convenience script"
      curl -fsSL https://get.docker.com | sh
    fi
  fi
  echo "  installed: $(docker --version)"
fi
systemctl enable --now docker >/dev/null 2>&1 || true
docker compose version >/dev/null 2>&1 || die "docker compose plugin is not available"

# ------------------------------------------------------------- 4. user & dirs
say "4/7 Creating the service account and directories"
if id "${APP_USER}" >/dev/null 2>&1; then
  echo "  user ${APP_USER} already exists"
else
  useradd --create-home --shell /usr/sbin/nologin "${APP_USER}"
  echo "  created user ${APP_USER} (no login shell)"
fi
usermod -aG docker "${APP_USER}"
mkdir -p "${APP_DIR}" "${APP_DIR}/data" "${APP_DIR}/reports" "${ENV_DIR}"
chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}"
chmod 750 "${ENV_DIR}"

# ----------------------------------------------------------------- 5. secrets
say "5/7 Preparing the environment file"
if [[ -f "${ENV_FILE}" ]]; then
  echo "  ${ENV_FILE} already exists — leaving it alone"
else
  umask 077
  cat > "${ENV_FILE}" <<'EOF'
# bybit-alpha secrets and runtime configuration. Root-owned, mode 0600.
# NEVER commit this file, never bake it into an image, never paste it into chat.

# Start on testnet. Only ever set this to false deliberately, after the go-live
# gates in docs/OPERATIONS.md have been met.
ALPHA_BYBIT__TESTNET=true

# Create keys at https://testnet.bybit.com/app/user/api-management
# Permissions: read + trade ONLY. Never enable withdrawals.
ALPHA_BYBIT__API_KEY=
ALPHA_BYBIT__API_SECRET=

ALPHA_MODE=paper
ALPHA_LOG_JSON=1
EOF
  chown root:root "${ENV_FILE}"
  chmod 600 "${ENV_FILE}"
  echo "  created ${ENV_FILE} (mode 600)"
  warn "fill in ALPHA_BYBIT__API_KEY and ALPHA_BYBIT__API_SECRET before going live:"
  warn "  sudo nano ${ENV_FILE}"
fi

# ------------------------------------------------------------ 6. systemd unit
say "6/7 Installing the systemd unit (used by the non-Docker path)"
if [[ -f "${APP_DIR}/deploy/alpha-agent.service" ]]; then
  sed -e "s#/opt/alpha/bybit-alpha#${APP_DIR}#g" -e "s#^User=.*#User=${APP_USER}#" \
      -e "s#^Group=.*#Group=${APP_USER}#" \
      "${APP_DIR}/deploy/alpha-agent.service" > /etc/systemd/system/alpha-agent.service
  systemctl daemon-reload
  echo "  installed /etc/systemd/system/alpha-agent.service"
  echo "  (not enabled — the Docker path is the default; see docs/OPERATIONS.md)"
else
  echo "  application code not present yet; skipped"
fi

# ----------------------------------------------------------------- 7. summary
say "7/7 Done"
cat <<EOF

Server is prepared. Next, from your local machine:

  1. Ship the code:
       ./deploy/deploy.sh ${APP_USER}@\$(hostname -I | awk '{print \$1}')

  2. Or directly on the server:
       cd ${APP_DIR} && docker compose up -d

The agent starts in PAPER mode. It will not place a real order until you
explicitly run:  alpha live --i-understand

Health once running:
       docker compose ps
       docker compose exec agent alpha health --strict

EOF
