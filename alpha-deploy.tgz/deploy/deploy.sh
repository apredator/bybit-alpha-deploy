#!/usr/bin/env bash
#
# Ship the agent to a prepared server and (re)start it in paper mode.
#
#   ./deploy/deploy.sh alpha@203.0.113.10
#
# Two gates, both deliberate:
#   1. The test suite must pass locally — do not ship code you have not run.
#   2. `alpha check --live` must pass on the server — do not restart an agent on a
#      machine that cannot reach the exchange, has an inconsistent risk config, or
#      whose feed the agent would refuse to trade.
#
# Neither gate starts real trading. The container's default command is `paper`.

set -euo pipefail

REMOTE="${1:-}"
REMOTE_DIR="${REMOTE_DIR:-/opt/alpha/bybit-alpha}"
FORCE="${ALLOW_FAILED_PREFLIGHT:-0}"

[[ -n "${REMOTE}" ]] || { echo "usage: $0 user@host" >&2; exit 2; }

say() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
die() { printf '\033[31mFAIL\033[0m %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- 1. local
say "1/6 Test suite (gate 1)"
PYTEST_BIN="${PYTEST_BIN:-.venv/bin/python}"
[[ -x "${PYTEST_BIN}" ]] || die "cannot find ${PYTEST_BIN} — run from the project root"
"${PYTEST_BIN}" -m pytest -o addopts="" -q || die "tests failed — not deploying"

# -------------------------------------------------------------- 2. reach it
say "2/6 Checking ${REMOTE}"
ssh -o BatchMode=yes -o ConnectTimeout=10 "${REMOTE}" true \
  || die "cannot ssh to ${REMOTE} non-interactively. Is this machine's public key in the server's authorized_keys?"
ssh "${REMOTE}" "command -v docker >/dev/null || { echo 'docker missing — run deploy/bootstrap.sh first' >&2; exit 1; }"

# ---------------------------------------------------------------- 3. sync
say "3/6 Syncing code to ${REMOTE}:${REMOTE_DIR}"
ssh "${REMOTE}" "mkdir -p ${REMOTE_DIR}"
# --delete keeps the remote tree honest; runtime state is never uploaded.
#
# Every exclusion is anchored with a leading slash. An unanchored `--exclude data`
# also matches `src/alpha/data` — the package that talks to the exchange — and the
# deployment then installs a project that cannot import its own data layer. The
# failure surfaces as `ModuleNotFoundError: No module named 'alpha.data'` on the
# server, which looks nothing like an rsync problem.
rsync -az --delete \
  --exclude '/.venv' --exclude '/.git' --exclude '/.uv-cache' --exclude '/.mplcache' \
  --exclude '__pycache__' --exclude '/.pytest_cache' --exclude '/.ruff_cache' \
  --exclude '/data' --exclude '/reports' --exclude '/.env' \
  --exclude '/.timeweb-token' --exclude '*.pyc' \
  ./ "${REMOTE}:${REMOTE_DIR}/"

# ------------------------------------------------- 3a. writable host volumes
# The image runs as uid 10001, and compose bind-mounts ./data and ./reports into
# it. If those directories are root-owned (they will be — rsync runs as root) the
# agent cannot write its parquet cache or its heartbeat, and fails at the first
# cycle with a permission error that looks nothing like a permissions problem.
ssh "${REMOTE}" "mkdir -p ${REMOTE_DIR}/data ${REMOTE_DIR}/reports && chown -R 10001:10001 ${REMOTE_DIR}/data ${REMOTE_DIR}/reports && chmod 755 ${REMOTE_DIR}/data ${REMOTE_DIR}/reports"

# --------------------------------------------------- 3b. runtime env file
# docker-compose declares `env_file: .env`, and a missing env file is a hard error
# there. On a fresh server it does not exist yet, so create it from the template:
# paper mode needs no exchange keys at all, only public market data.
ssh "${REMOTE}" "cd ${REMOTE_DIR} && if [ ! -f .env ]; then cp .env.example .env && chmod 600 .env && echo 'created .env from .env.example (paper needs no keys)'; else echo '.env already present, left alone'; fi"

# ------------------------------------------------------------- 4. build
say "4/6 Building the image on the server"
ssh "${REMOTE}" "cd ${REMOTE_DIR} && docker compose build"

# ------------------------------------------------- 5. preflight (gate 2)
say "5/6 Preflight on the server (gate 2)"
if ! ssh "${REMOTE}" "cd ${REMOTE_DIR} && docker compose run --rm --no-deps agent check --live"; then
  echo
  if [[ "${FORCE}" == "1" ]]; then
    printf '\033[33mWARN\033[0m preflight failed, but ALLOW_FAILED_PREFLIGHT=1 — continuing.\n'
    printf '\033[33mWARN\033[0m You are starting an agent the machine itself says is not ready.\n'
  else
    die "preflight FAILED on the server — leaving anything already running untouched.
     Fix the reported problem, or set ALLOW_FAILED_PREFLIGHT=1 to override deliberately."
  fi
fi

# --------------------------------------------------------------- 6. start
say "6/6 Starting in PAPER mode"
# `up -d` is idempotent: it recreates the container only if the image changed.
ssh "${REMOTE}" "cd ${REMOTE_DIR} && docker compose up -d"
sleep 20

say "Status"
ssh "${REMOTE}" "cd ${REMOTE_DIR} && docker compose ps"
if ssh "${REMOTE}" "cd ${REMOTE_DIR} && docker compose exec -T agent alpha health --strict"; then
  echo
  echo "Deployed and healthy in paper mode."
else
  echo
  printf '\033[33mWARN\033[0m health is not green yet — the first cycle fetches history and can take a minute.\n'
  ssh "${REMOTE}" "cd ${REMOTE_DIR} && docker compose logs --tail 25 agent" || true
fi

cat <<EOF

Useful next commands (on the server, in ${REMOTE_DIR}):

  docker compose logs -f agent                  # follow the agent
  docker compose exec agent alpha status        # last heartbeat
  docker compose exec agent alpha health --strict
  docker compose exec agent alpha check --live  # re-run the preflight by hand

It is in PAPER mode. Nothing here can place a real order.
EOF
