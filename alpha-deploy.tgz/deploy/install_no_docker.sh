#!/usr/bin/env bash
#
# Install the agent on a heavily filtered host: no Docker, no PyPI, no reachable
# file host. Everything arrives from one GitHub repository over plain HTTPS.
#
#   curl -fsSL <REPO>/install.sh | bash -s -- <REPO>
#
# where <REPO> is the raw base URL, e.g.
#   https://raw.githubusercontent.com/user/bybit-alpha/main
#
# Why no Docker: on this class of host Docker Hub and download.docker.com are
# unreachable, so the base image cannot be pulled and the engine cannot even be
# installed. A plain directory of wheels plus the system python needs neither.
#
# Why no venv: `python3 -m venv` needs the python3-venv package, which may itself
# be unavailable. Installing into a target directory and pointing PYTHONPATH at it
# achieves the same isolation with nothing but the stdlib.

set -euo pipefail

REPO_RAW="${1:-}"
APP_DIR="${APP_DIR:-/opt/alpha/bybit-alpha}"
LIB_DIR="${LIB_DIR:-/opt/alpha/lib}"
WH_DIR="${WH_DIR:-/opt/alpha/wheelhouse}"
PIPBOOT="${PIPBOOT:-/opt/alpha/pipboot}"
SERVICE=alpha-agent

say()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[33mWARN\033[0m %s\n' "$*"; }
die()  { printf '\033[31mFAIL\033[0m %s\n' "$*" >&2; exit 1; }

PY=$(command -v python3) || die "python3 not found"
PV=$("$PY" -c 'import sys; print("%d.%d" % sys.version_info[:2])')

[[ "$(id -u)" -eq 0 ]] || die "run as root"
[[ "$REPO_RAW" =~ ^https?:// ]] || die "usage: curl -fsSL <repo>/install.sh | bash -s -- <repo-raw-url>"
REPO_RAW="${REPO_RAW%/}"

# Fail fast and clearly if GitHub is not reachable — everything depends on it.
curl -fsSI --connect-timeout 15 -m 30 "${REPO_RAW}/install.sh" >/dev/null 2>&1 \
  || die "cannot reach ${REPO_RAW} — is the repository public and the path right?"

say "1/7 Fetching the agent  (python ${PV})"
TMP=$(mktemp -d); trap 'rm -rf "${TMP}"' EXIT
mkdir -p "${APP_DIR}"
curl -fsSL --retry 3 --retry-delay 3 -m 300 "${REPO_RAW}/alpha-deploy.tgz" -o "${TMP}/agent.tgz" \
  || die "could not download alpha-deploy.tgz"
tar tzf "${TMP}/agent.tgz" >/dev/null 2>&1 || die "alpha-deploy.tgz is not a valid archive"
tar xzf "${TMP}/agent.tgz" -C "${APP_DIR}"
echo "  unpacked to ${APP_DIR}"

say "2/7 Fetching the Python packages"
mkdir -p "${WH_DIR}" "${TMP}/wh"
for part in wheelhouse.part-aa wheelhouse.part-ab; do
  echo "  ${part}"
  curl -fsSL --retry 3 --retry-delay 3 -m 600 "${REPO_RAW}/${part}" -o "${TMP}/${part}" \
    || die "could not download ${part}"
done
cat "${TMP}"/wheelhouse.part-* > "${TMP}/wheelhouse.tar.gz"
tar xzf "${TMP}/wheelhouse.tar.gz" -C "${WH_DIR}"
echo "  $(ls "${WH_DIR}" | wc -l | tr -d ' ') wheels in ${WH_DIR}"

say "3/7 Bootstrapping pip (the host has none)"
rm -rf "${PIPBOOT}"; mkdir -p "${PIPBOOT}"
PIP_WHL=$(ls "${WH_DIR}"/pip-*.whl 2>/dev/null | head -1) || true
[[ -n "${PIP_WHL}" ]] || die "the pip wheel is missing from the wheelhouse"
"$PY" -m zipfile -e "${PIP_WHL}" "${PIPBOOT}/"
PYTHONPATH="${PIPBOOT}" "$PY" -m pip --version >/dev/null \
  || die "pip bootstrap failed"
echo "  $(PYTHONPATH="${PIPBOOT}" "$PY" -m pip --version)"

say "4/7 Installing dependencies into ${LIB_DIR}"
rm -rf "${LIB_DIR}"; mkdir -p "${LIB_DIR}"
PYTHONPATH="${PIPBOOT}" "$PY" -m pip install \
  --quiet --no-index --find-links "${WH_DIR}" --target "${LIB_DIR}" \
  numpy pandas httpx pydantic pydantic-settings pyyaml typer rich tenacity \
  || die "dependency installation failed"
echo "  $(ls "${LIB_DIR}" | wc -l | tr -d ' ') packages installed"

say "5/7 Verifying the agent imports"
APP_PYTHONPATH="${LIB_DIR}:${APP_DIR}/src"
PYTHONPATH="${APP_PYTHONPATH}" "$PY" -c "
import alpha.cli, alpha.live.agent, alpha.risk.engine, alpha.execution.paper, alpha.data.validation
import numpy, pandas, httpx, pydantic
print('  pandas', pandas.__version__, '| numpy', numpy.__version__, '| httpx', httpx.__version__)
" || die "the agent does not import — see the traceback above"

say "6/7 Configuring"
mkdir -p "${APP_DIR}/data/raw" "${APP_DIR}/reports"
[[ -f "${APP_DIR}/.env" ]] || { cp "${APP_DIR}/.env.example" "${APP_DIR}/.env"; chmod 600 "${APP_DIR}/.env"; }
cat > /etc/systemd/system/${SERVICE}.service <<EOF
[Unit]
Description=bybit-alpha trading agent (paper)
After=network-online.target time-sync.target
Wants=network-online.target time-sync.target

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
Environment=PYTHONPATH=${APP_PYTHONPATH}
Environment=TZ=UTC
Environment=ALPHA_LOG_JSON=1
Environment=ALPHA_CONFIG=${APP_DIR}/config/default.yaml
ExecStart=${PY} -m alpha.cli paper --poll 30
Restart=always
RestartSec=15
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${SERVICE}

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now ${SERVICE}
echo "  systemd unit installed and started"

say "7/7 First cycle"
# Bybit itself must be reachable, or the agent has nothing to work with.
if curl -fsS --connect-timeout 15 -m 30 "https://api.bybit.com/v5/market/time" >/dev/null 2>&1; then
  echo "  Bybit API: reachable"
else
  warn "Bybit API does not answer — the agent will stand aside. Check:"
  warn "  curl -sI https://api.bybit.com/v5/market/time"
fi

for i in $(seq 1 12); do
  sleep 10
  if PYTHONPATH="${APP_PYTHONPATH}" "$PY" -m alpha.cli health --data-root "${APP_DIR}/data/raw" 2>/dev/null; then
    echo
    echo "Agent is running in PAPER mode under systemd. Nothing can place a real order."
    echo
    echo "  systemctl status ${SERVICE}"
    echo "  journalctl -u ${SERVICE} -f"
    exit 0
  fi
  echo "  waiting for the first cycle (${i}/12)..."
done

warn "health is not green yet. Recent logs:"
journalctl -u ${SERVICE} -n 40 --no-pager || true
exit 1
