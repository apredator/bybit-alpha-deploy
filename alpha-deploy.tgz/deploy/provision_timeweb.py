#!/usr/bin/env python
"""Provision a VPS for the trading agent via the Timeweb Cloud API.

    TIMEWEB_API_TOKEN=... python deploy/provision_timeweb.py --dry-run
    TIMEWEB_API_TOKEN=... python deploy/provision_timeweb.py --yes

Design notes
------------
* **Discovery, not hardcoded ids.** Preset, OS image, location and SSH-key ids
  differ per account and change over time. The script asks the API what exists and
  picks from the answers, so a schema or catalogue change produces a readable
  error instead of a server created with someone else's preset id.
* **Dry run by default is not enough** — creating a server costs money, so the
  script prints exactly what it would buy, with the price, and waits for `--yes`.
* **The token is never printed.** It is read from the environment or a file and
  passed straight into request headers.
* **cloud-init does the first-boot setup**, so the machine arrives with UTC, NTP
  and Docker already in place — and with the agent's user created. That way the
  server is never reachable-and-unconfigured for longer than it takes to boot.

The agent itself is NOT started here. This script only produces a machine; the
code is shipped and started in paper mode by `deploy/deploy.sh`.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

try:
    import httpx
except ImportError:  # pragma: no cover - deployment-only helper
    print("httpx is required: use the project venv (.venv/bin/python)", file=sys.stderr)
    raise SystemExit(2) from None

API = "https://api.timeweb.cloud/api/v1"

#: What the agent actually needs: one vCPU, 2 GB. Anything more is wasted — the
#: workload is one REST poll per bar.
MIN_RAM_MB = 2048
PREFERRED_OS = ("ubuntu 24.04", "ubuntu 24", "ubuntu 22.04", "ubuntu 22")
SERVER_NAME = "alpha-agent"

CLOUD_INIT = """#cloud-config
# First-boot setup for the trading agent. Deliberately minimal: enough that the
# machine is safe to leave running, and nothing that touches money.
timezone: UTC
package_update: true
packages:
  - ca-certificates
  - curl
  - rsync
  - chrony
write_files:
  - path: /etc/docker/daemon.json
    content: |
      {"log-driver": "json-file", "log-opts": {"max-size": "20m", "max-file": "5"}}
runcmd:
  - [ systemctl, enable, --now, chrony ]
  - [ timedatectl, set-timezone, UTC ]
  - [ sh, -c, "curl -fsSL https://get.docker.com | sh" ]
  - [ systemctl, enable, --now, docker ]
  - [ useradd, -m, -s, /usr/sbin/nologin, alpha ]
  - [ usermod, -aG, docker, alpha ]
  - [ mkdir, -p, /opt/alpha/bybit-alpha ]
  - [ chown, -R, "alpha:alpha", /opt/alpha/bybit-alpha ]
  - [ sh, -c, "echo 'cloud-init finished' > /var/log/alpha-ready" ]
"""


class Timeweb:
    def __init__(self, token: str) -> None:
        self._client = httpx.Client(
            base_url=API,
            timeout=30.0,
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        )

    def close(self) -> None:
        self._client.close()

    def get(self, path: str, **params) -> dict:
        r = self._client.get(path, params=params or None)
        return self._json(r, path)

    def post(self, path: str, payload: dict) -> dict:
        r = self._client.post(path, json=payload)
        return self._json(r, path)

    @staticmethod
    def _json(response: httpx.Response, path: str) -> dict:
        if response.status_code == 401:
            raise SystemExit(
                "Timeweb rejected the token (401). Check that it is an API token "
                "(не пароль) and that it has the 'servers' scope."
            )
        if response.status_code >= 400:
            raise SystemExit(f"{path} -> HTTP {response.status_code}: {response.text[:400]}")
        try:
            return response.json()
        except ValueError as exc:
            raise SystemExit(f"{path} returned non-JSON: {response.text[:200]}") from exc


def pick_os(images: list[dict]) -> dict:
    for needle in PREFERRED_OS:
        for image in images:
            name = f"{image.get('name', '')} {image.get('version', '')}".lower()
            if needle in name:
                return image
    raise SystemExit(
        "no Ubuntu image found. Available: "
        + ", ".join(f"{i.get('name')} {i.get('version')}" for i in images[:15])
    )


def pick_preset(presets: list[dict]) -> dict:
    """Cheapest preset that meets the memory requirement, preferring more CPU on ties."""
    usable = [p for p in presets if float(p.get("ram", 0) or 0) >= MIN_RAM_MB and p.get("price") is not None]
    if not usable:
        usable = [p for p in presets if float(p.get("ram", 0) or 0) >= MIN_RAM_MB]
    if not usable:
        raise SystemExit(f"no preset with >= {MIN_RAM_MB} MB RAM is available")
    return sorted(usable, key=lambda p: (float(p.get("price", 0) or 0), -float(p.get("cpu", 0) or 0)))[0]


def main() -> int:
    parser = argparse.ArgumentParser(description="Provision a Timeweb VPS for the agent.")
    parser.add_argument("--token-file", type=Path, default=Path(".timeweb-token"))
    parser.add_argument("--name", default=SERVER_NAME)
    parser.add_argument("--location", default=None, help="Location code, e.g. ru-1. Default: first available.")
    parser.add_argument("--ssh-pubkey", type=Path, default=Path.home() / ".ssh" / "id_ed25519.pub")
    parser.add_argument("--yes", action="store_true", help="Actually create the server.")
    parser.add_argument("--dry-run", action="store_true", help="Show the plan only (default).")
    parser.add_argument("--wait", action="store_true", help="Wait until the server is running and print its IP.")
    args = parser.parse_args()

    token = os.getenv("TIMEWEB_API_TOKEN")
    if not token and args.token_file.exists():
        token = args.token_file.read_text(encoding="utf-8").strip()
    if not token:
        print(
            f"no token. Set TIMEWEB_API_TOKEN, or write it to {args.token_file}\n"
            "Create one at: Timeweb Cloud -> Настройки -> API-токены (scope: servers).",
            file=sys.stderr,
        )
        return 2

    tw = Timeweb(token)
    try:
        account = tw.get("/account/status")
        print(f"account      : {account.get('status', 'unknown')}")
        try:
            finances = tw.get("/account/finances")
            print(f"balance      : {finances.get('balance', '?')} {finances.get('currency', '')}")
        except SystemExit:
            pass

        locations = tw.get("/locations").get("locations", [])
        if not locations:
            raise SystemExit("no locations returned")
        location = args.location or locations[0].get("code")
        codes = ", ".join(str(loc.get("code", "?")) for loc in locations[:6])
        print(f"location     : {location} (of {codes})")

        images = tw.get("/os/servers").get("servers", [])
        image = pick_os(images)
        print(f"os image     : {image.get('name')} {image.get('version')} (id={image.get('id')})")

        presets = tw.get("/presets/servers").get("servers", [])
        preset = pick_preset(presets)
        print(
            f"preset       : {preset.get('description', preset.get('id'))} — "
            f"{preset.get('cpu')} vCPU / {preset.get('ram')} MB / {preset.get('disk')} GB, "
            f"{preset.get('price')} {preset.get('price_currency', '')}/mo"
        )

        pubkey = args.ssh_pubkey.read_text(encoding="utf-8").strip() if args.ssh_pubkey.exists() else ""
        if not pubkey:
            raise SystemExit(f"no public key at {args.ssh_pubkey} — it is what lets us log in afterwards")
        print(f"ssh key      : {pubkey.split()[0]} ... {pubkey.split()[-1]}")

        print("\n--- plan ---")
        print(f"  create server '{args.name}' in {location}")
        print("  cloud-init   : UTC, chrony (NTP), Docker, user 'alpha'")
        print("  NOT created  : no firewall rules, no inbound ports, no exchange keys")
        print("------------\n")

        if not args.yes or args.dry_run:
            print("dry run — nothing was created. Re-run with --yes to provision.")
            return 0

        existing = tw.get("/servers").get("servers", [])
        if any(s.get("name") == args.name for s in existing):
            raise SystemExit(f"a server named '{args.name}' already exists — refusing to create a second")

        key = tw.post("/ssh-keys", {"name": f"{args.name}-key", "body": pubkey})
        key_id = (key.get("ssh_key") or {}).get("id")
        print(f"registered ssh key id={key_id}")

        payload = {
            "name": args.name,
            "os_id": image.get("id"),
            "preset_id": preset.get("id"),
            "location": location,
            "is_cloud": True,
            "comment": "bybit-alpha paper-trading agent",
            "ssh_keys": [key_id] if key_id else [],
            "cloud_init": CLOUD_INIT,
        }
        created = tw.post("/servers", payload)
        server = created.get("server", created)
        server_id = server.get("id")
        print(f"created server id={server_id}")

        if args.wait:
            for _ in range(60):
                current = tw.get(f"/servers/{server_id}").get("server", {})
                status = current.get("status")
                ip = _ipv4(current)
                print(f"  status={status} ip={ip or '-'}")
                if status == "on" and ip:
                    print(f"\nready: ssh alpha@{ip}")
                    print(f"next : ./deploy/deploy.sh alpha@{ip}")
                    return 0
                time.sleep(10)
            print("timed out waiting for the server; check the panel", file=sys.stderr)
            return 1
        return 0
    finally:
        tw.close()


def _ipv4(server: dict) -> str | None:
    for net in server.get("networks", []) or []:
        for addr in net.get("ips", []) or []:
            if addr.get("type") == "ipv4" and addr.get("is_main"):
                return addr.get("ip")
    for net in server.get("networks", []) or []:
        for addr in net.get("ips", []) or []:
            if addr.get("type") == "ipv4":
                return addr.get("ip")
    return None


if __name__ == "__main__":
    raise SystemExit(main())
